export interface AITool {
  id: string;
  name: string;
  category: string;
  description: string;
  url: string;
  logo_url: string;
  suggested_prompt: string;
  color: 'cyan' | 'purple' | 'green' | 'orange';
}

export const CATEGORIES = [
  'Coding',
  'Design',
  'Writing',
  'Education',
  'Fitness',
  'Cooking',
  'Business',
  'Video',
  'Audio',
  'Marketing',
  'Productivity',
  'Social Media',
  'Gaming',
  'Health',
  'Finance',
  'Legal',
  'Travel',
  'Real Estate',
  'HR',
  'Sales',
  'Customer Support',
  'Data Science',
  'Security',
  'DevOps',
  'Logistics',
  'Energy',
  'Agriculture',
  'Manufacturing',
  'Retail',
  'Automotive',
  'Space',
  'Robotics',
  'Environment',
  'Social',
  'Media',
  'Music',
  'Collaboration',
  'Communication',
  'Analytics'
];

export const AI_TOOLS: AITool[] = [
  {
    id: '1',
    name: 'ChatGPT',
    category: 'Writing',
    description: 'The world\'s most popular AI assistant for writing, coding, and general tasks.',
    url: 'https://chat.openai.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=chatgpt',
    suggested_prompt: 'Write a professional email to a client explaining a project delay...',
    color: 'cyan'
  },
  {
    id: '2',
    name: 'GitHub Copilot',
    category: 'Coding',
    description: 'Your AI pair programmer that helps you write code faster with less work.',
    url: 'https://github.com/features/copilot',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=copilot',
    suggested_prompt: 'Create a React component for a responsive navigation bar using Tailwind CSS...',
    color: 'purple'
  },
  {
    id: '3',
    name: 'Midjourney',
    category: 'Design',
    description: 'Create stunning, high-fidelity images from simple text descriptions.',
    url: 'https://www.midjourney.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=midjourney',
    suggested_prompt: 'A futuristic cyberpunk city skyline at night, neon lights, cinematic lighting, 8k...',
    color: 'cyan'
  },
  {
    id: '4',
    name: 'Claude',
    category: 'Writing',
    description: 'A helpful, harmless, and honest AI assistant from Anthropic.',
    url: 'https://claude.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=claude',
    suggested_prompt: 'Analyze this document and summarize the key findings in bullet points...',
    color: 'purple'
  },
  {
    id: '5',
    name: 'Duolingo Max',
    category: 'Education',
    description: 'AI-powered language learning with personalized feedback and roleplay.',
    url: 'https://www.duolingo.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=duolingo',
    suggested_prompt: 'Practice a conversation about ordering food in a French restaurant...',
    color: 'cyan'
  },
  {
    id: '6',
    name: 'Fitbod',
    category: 'Fitness',
    description: 'AI-driven workout plans that adapt to your progress and equipment.',
    url: 'https://fitbod.me',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fitbod',
    suggested_prompt: 'Generate a 45-minute upper body workout for someone with only dumbbells...',
    color: 'purple'
  },
  {
    id: '7',
    name: 'Perplexity',
    category: 'Education',
    description: 'An AI-powered search engine that provides direct answers with citations.',
    url: 'https://www.perplexity.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=perplexity',
    suggested_prompt: 'Explain the concept of quantum entanglement in simple terms with recent research...',
    color: 'cyan'
  },
  {
    id: '8',
    name: 'Jasper',
    category: 'Business',
    description: 'AI content platform that helps teams create high-quality marketing copy.',
    url: 'https://www.jasper.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=jasper',
    suggested_prompt: 'Write a 500-word blog post about the benefits of remote work for tech startups...',
    color: 'purple'
  },
  {
    id: '9',
    name: 'Canva Magic Studio',
    category: 'Design',
    description: 'AI-powered design tools to create presentations, videos, and social media posts.',
    url: 'https://www.canva.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=canva',
    suggested_prompt: 'Design a modern Instagram post for a new AI product launch...',
    color: 'cyan'
  },
  {
    id: '10',
    name: 'Runway Gen-2',
    category: 'Video',
    description: 'Generate realistic videos from text, images, or video clips.',
    url: 'https://runwayml.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=runway',
    suggested_prompt: 'A cinematic shot of a golden retriever flying through a nebula...',
    color: 'green'
  },
  {
    id: '11',
    name: 'ElevenLabs',
    category: 'Audio',
    description: 'The most realistic AI speech software for creators and publishers.',
    url: 'https://elevenlabs.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=elevenlabs',
    suggested_prompt: 'Narrate this short story in a warm, professional British voice...',
    color: 'orange'
  },
  {
    id: '12',
    name: 'Notion AI',
    category: 'Productivity',
    description: 'Write faster, think bigger, and augment your creativity inside Notion.',
    url: 'https://www.notion.so/product/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=notion',
    suggested_prompt: 'Summarize these meeting notes and extract the next steps for each team member...',
    color: 'cyan'
  },
  {
    id: '13',
    name: 'Grammarly GO',
    category: 'Writing',
    description: 'Personalized AI writing assistance that understands your context and goals.',
    url: 'https://www.grammarly.com/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=grammarly',
    suggested_prompt: 'Rewrite this paragraph to sound more confident and persuasive...',
    color: 'purple'
  },
  {
    id: '14',
    name: 'Luma Dream Machine',
    category: 'Video',
    description: 'High-quality, realistic video generation from text and images.',
    url: 'https://lumalabs.ai/dream-machine',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=luma',
    suggested_prompt: 'A close-up of a futuristic robot eye reflecting a digital city...',
    color: 'green'
  },
  {
    id: '15',
    name: 'Suno AI',
    category: 'Audio',
    description: 'Generate full songs with vocals and instrumentation from text prompts.',
    url: 'https://suno.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=suno',
    suggested_prompt: 'A high-energy synthwave track about exploring the digital frontier...',
    color: 'orange'
  },
  {
    id: '16',
    name: 'Copy.ai',
    category: 'Marketing',
    description: 'AI-powered copywriting for all your business and marketing needs.',
    url: 'https://www.copy.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=copyai',
    suggested_prompt: 'Generate 10 catchy headlines for a new sustainable fashion brand...',
    color: 'purple'
  },
  {
    id: '17',
    name: 'Cursor',
    category: 'Coding',
    description: 'The AI-first code editor built for pair programming with AI.',
    url: 'https://cursor.sh',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cursor',
    suggested_prompt: 'Refactor this function to be more efficient and add TypeScript types...',
    color: 'cyan'
  },
  {
    id: '18',
    name: 'Figma AI',
    category: 'Design',
    description: 'New AI features in Figma to help you design faster and more creatively.',
    url: 'https://www.figma.com/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=figma',
    suggested_prompt: 'Generate a mobile app UI for a plant tracking and care application...',
    color: 'purple'
  },
  {
    id: '19',
    name: 'Otter.ai',
    category: 'Productivity',
    description: 'AI meeting assistant that records audio, writes notes, and captures slides.',
    url: 'https://otter.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=otter',
    suggested_prompt: 'Transcribe this 30-minute interview and highlight the most important quotes...',
    color: 'cyan'
  },
  {
    id: '20',
    name: 'Gamma',
    category: 'Business',
    description: 'Create beautiful presentations, websites, and documents with AI.',
    url: 'https://gamma.app',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gamma',
    suggested_prompt: 'Create a 10-slide pitch deck for a new AI-powered educational platform...',
    color: 'purple'
  },
  {
    id: '21',
    name: 'Replicate',
    category: 'Coding',
    description: 'Run machine learning models in the cloud with a simple API.',
    url: 'https://replicate.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=replicate',
    suggested_prompt: 'Deploy a Llama 3 model and create an API endpoint for text generation...',
    color: 'cyan'
  },
  {
    id: '22',
    name: 'Leonardo.ai',
    category: 'Design',
    description: 'Generate production-quality assets for your creative projects.',
    url: 'https://leonardo.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=leonardo',
    suggested_prompt: 'A detailed 3D character model of a space explorer in a sleek white suit...',
    color: 'purple'
  },
  {
    id: '23',
    name: 'Descript',
    category: 'Video',
    description: 'The only tool you need to write, record, transcribe, edit, and share videos.',
    url: 'https://www.descript.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=descript',
    suggested_prompt: 'Edit this podcast episode by removing filler words and adding background music...',
    color: 'green'
  },
  {
    id: '24',
    name: 'HeyGen',
    category: 'Video',
    description: 'Create professional business videos with AI avatars in minutes.',
    url: 'https://www.heygen.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=heygen',
    suggested_prompt: 'Create a 1-minute training video with a realistic avatar explaining company policy...',
    color: 'green'
  },
  {
    id: '25',
    name: 'Udio',
    category: 'Audio',
    description: 'Discover and create amazing music with AI.',
    url: 'https://www.udio.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=udio',
    suggested_prompt: 'A soulful jazz track with a female vocalist singing about a rainy day...',
    color: 'orange'
  },
  {
    id: '26',
    name: 'Tome',
    category: 'Business',
    description: 'AI-powered storytelling for work.',
    url: 'https://tome.app',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tome',
    suggested_prompt: 'Create a visual story about the future of sustainable energy in cities...',
    color: 'purple'
  },
  {
    id: '27',
    name: 'Phind',
    category: 'Coding',
    description: 'The AI search engine for developers.',
    url: 'https://www.phind.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=phind',
    suggested_prompt: 'Explain how to implement a custom hook in React for handling window resize...',
    color: 'cyan'
  },
  {
    id: '28',
    name: 'Krea AI',
    category: 'Design',
    description: 'Real-time AI image generation and enhancement.',
    url: 'https://www.krea.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=krea',
    suggested_prompt: 'Enhance this low-resolution photo and add realistic textures and lighting...',
    color: 'purple'
  },
  {
    id: '29',
    name: 'Perplexity Pages',
    category: 'Writing',
    description: 'Create beautiful, informative pages on any topic with AI.',
    url: 'https://www.perplexity.ai/pages',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=perplexitypages',
    suggested_prompt: 'Create a comprehensive guide on the history of artificial intelligence...',
    color: 'cyan'
  },
  {
    id: '30',
    name: 'Vercel V0',
    category: 'Coding',
    description: 'Generate UI components with text prompts using React and Tailwind.',
    url: 'https://v0.dev',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=v0',
    suggested_prompt: 'Create a modern dashboard layout with a sidebar and a data table...',
    color: 'cyan'
  },
  {
    id: '31',
    name: 'Tabnine',
    category: 'Coding',
    description: 'AI code completion for developers that learns your style.',
    url: 'https://www.tabnine.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tabnine',
    suggested_prompt: 'Complete this Python function for calculating Fibonacci numbers...',
    color: 'purple'
  },
  {
    id: '32',
    name: 'Adobe Firefly',
    category: 'Design',
    description: 'Generative AI for creative expression, integrated into Creative Cloud.',
    url: 'https://www.adobe.com/firefly',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=firefly',
    suggested_prompt: 'Generate a realistic texture of brushed aluminum for a product design...',
    color: 'cyan'
  },
  {
    id: '33',
    name: 'Quillbot',
    category: 'Writing',
    description: 'AI-powered paraphrasing tool that helps you rewrite and enhance your text.',
    url: 'https://quillbot.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=quillbot',
    suggested_prompt: 'Paraphrase this academic abstract to be more accessible to a general audience...',
    color: 'purple'
  },
  {
    id: '34',
    name: 'Khanmigo',
    category: 'Education',
    description: 'AI tutor and teaching assistant from Khan Academy.',
    url: 'https://www.khanacademy.org/khanmigo',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=khanmigo',
    suggested_prompt: 'Help me understand the steps to solve a quadratic equation...',
    color: 'cyan'
  },
  {
    id: '35',
    name: 'Freeletics',
    category: 'Fitness',
    description: 'AI-powered personal trainer for bodyweight and gym workouts.',
    url: 'https://www.freeletics.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=freeletics',
    suggested_prompt: 'Create a 15-minute HIIT workout for a small living space...',
    color: 'purple'
  },
  {
    id: '36',
    name: 'Fireflies.ai',
    category: 'Business',
    description: 'AI meeting assistant that records, transcribes, and searches voice conversations.',
    url: 'https://fireflies.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fireflies',
    suggested_prompt: 'Summarize the key decisions made during the last product sync meeting...',
    color: 'cyan'
  },
  {
    id: '37',
    name: 'Synthesia',
    category: 'Video',
    description: 'Create professional videos with AI avatars in over 120 languages.',
    url: 'https://www.synthesia.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=synthesia',
    suggested_prompt: 'Create a welcome video for new employees using a professional avatar...',
    color: 'green'
  },
  {
    id: '38',
    name: 'Adobe Podcast',
    category: 'Audio',
    description: 'AI-powered audio recording and editing for high-quality podcasts.',
    url: 'https://podcast.adobe.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=adobepodcast',
    suggested_prompt: 'Enhance this voice recording to sound like it was recorded in a studio...',
    color: 'orange'
  },
  {
    id: '39',
    name: 'Mutiny',
    category: 'Marketing',
    description: 'AI platform that helps B2B companies personalize their website for every visitor.',
    url: 'https://www.mutinyhq.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mutiny',
    suggested_prompt: 'Personalize the homepage headline for visitors from the healthcare industry...',
    color: 'purple'
  },
  {
    id: '40',
    name: 'Mem',
    category: 'Productivity',
    description: 'AI-powered workspace that organizes your notes and information automatically.',
    url: 'https://mem.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mem',
    suggested_prompt: 'Find all my notes related to the "Project X" launch strategy...',
    color: 'cyan'
  },
  {
    id: '41',
    name: 'Buffer AI',
    category: 'Social Media',
    description: 'AI assistant for social media scheduling and content generation.',
    url: 'https://buffer.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=buffer',
    suggested_prompt: 'Generate 5 LinkedIn posts about the future of AI in small business...',
    color: 'purple'
  },
  {
    id: '42',
    name: 'Unity Muse',
    category: 'Gaming',
    description: 'AI-powered tools to accelerate game development in Unity.',
    url: 'https://unity.com/products/muse',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=unitymuse',
    suggested_prompt: 'Generate a C# script for a character controller with double jump...',
    color: 'cyan'
  },
  {
    id: '43',
    name: 'Babylon Health',
    category: 'Health',
    description: 'AI-powered health assessment and virtual consultations.',
    url: 'https://www.babylonhealth.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=babylon',
    suggested_prompt: 'Check my symptoms for a persistent cough and mild fever...',
    color: 'purple'
  },
  {
    id: '44',
    name: 'Cleo',
    category: 'Finance',
    description: 'AI financial assistant that helps you save, budget, and manage money.',
    url: 'https://www.meetcleo.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cleo',
    suggested_prompt: 'Analyze my spending for the last month and suggest where I can save...',
    color: 'cyan'
  },
  {
    id: '45',
    name: 'Casetext',
    category: 'Legal',
    description: 'AI legal research assistant for lawyers and legal professionals.',
    url: 'https://casetext.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=casetext',
    suggested_prompt: 'Find relevant case law for a contract dispute involving force majeure...',
    color: 'purple'
  },
  {
    id: '46',
    name: 'Roam Around',
    category: 'Travel',
    description: 'AI-powered travel planner that creates custom itineraries.',
    url: 'https://www.roamaround.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=roamaround',
    suggested_prompt: 'Create a 3-day itinerary for a food-focused trip to Tokyo...',
    color: 'cyan'
  },
  {
    id: '47',
    name: 'Zillow AI',
    category: 'Real Estate',
    description: 'AI features for home search, valuation, and virtual tours.',
    url: 'https://www.zillow.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zillow',
    suggested_prompt: 'Find homes with a modern kitchen and large backyard in Seattle...',
    color: 'purple'
  },
  {
    id: '48',
    name: 'Eightfold.ai',
    category: 'HR',
    description: 'AI platform for talent acquisition, management, and retention.',
    url: 'https://eightfold.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=eightfold',
    suggested_prompt: 'Identify internal candidates with the skills for a Senior Product Manager role...',
    color: 'cyan'
  },
  {
    id: '49',
    name: 'Clari',
    category: 'Sales',
    description: 'AI-powered revenue platform for sales forecasting and execution.',
    url: 'https://www.clari.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=clari',
    suggested_prompt: 'Predict the revenue for the current quarter based on the sales pipeline...',
    color: 'purple'
  },
  {
    id: '50',
    name: 'Intercom Fin',
    category: 'Customer Support',
    description: 'AI chatbot that provides instant, accurate answers to customer queries.',
    url: 'https://www.intercom.com/fin',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=intercom',
    suggested_prompt: 'Answer a customer question about our refund policy using the help center...',
    color: 'cyan'
  },
  {
    id: '51',
    name: 'DataRobot',
    category: 'Data Science',
    description: 'AI platform that automates the end-to-end machine learning process.',
    url: 'https://www.datarobot.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=datarobot',
    suggested_prompt: 'Build a predictive model for customer churn using historical data...',
    color: 'purple'
  },
  {
    id: '52',
    name: 'Darktrace',
    category: 'Security',
    description: 'AI-powered cybersecurity platform that detects and responds to threats.',
    url: 'https://www.darktrace.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=darktrace',
    suggested_prompt: 'Detect unusual network activity that might indicate a data breach...',
    color: 'cyan'
  },
  {
    id: '53',
    name: 'PagerDuty AI',
    category: 'DevOps',
    description: 'AI-powered incident response and operations platform.',
    url: 'https://www.pagerduty.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pagerduty',
    suggested_prompt: 'Analyze incident patterns to identify the root cause of recurring outages...',
    color: 'purple'
  },
  {
    id: '54',
    name: 'Codeium',
    category: 'Coding',
    description: 'Free AI code completion and search for over 70 languages.',
    url: 'https://codeium.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=codeium',
    suggested_prompt: 'Explain this complex SQL query and suggest optimizations...',
    color: 'cyan'
  },
  {
    id: '55',
    name: 'Uizard',
    category: 'Design',
    description: 'AI-powered design tool for creating wireframes and prototypes.',
    url: 'https://uizard.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=uizard',
    suggested_prompt: 'Convert this hand-drawn sketch into a digital UI mockup...',
    color: 'purple'
  },
  {
    id: '56',
    name: 'Writesonic',
    category: 'Writing',
    description: 'AI writing tool for blog posts, ads, and product descriptions.',
    url: 'https://writesonic.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=writesonic',
    suggested_prompt: 'Write a 1000-word article about the impact of AI on digital marketing...',
    color: 'cyan'
  },
  {
    id: '57',
    name: 'Socratic',
    category: 'Education',
    description: 'AI-powered learning app from Google that helps students with homework.',
    url: 'https://socratic.org',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=socratic',
    suggested_prompt: 'Explain the process of photosynthesis with a diagram...',
    color: 'purple'
  },
  {
    id: '58',
    name: 'FitnessAI',
    category: 'Fitness',
    description: 'AI-powered weightlifting app that creates personalized workouts.',
    url: 'https://www.fitnessai.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fitnessai',
    suggested_prompt: 'Suggest a progression for my bench press based on my last 5 sessions...',
    color: 'cyan'
  },
  {
    id: '59',
    name: 'Gong',
    category: 'Business',
    description: 'AI platform that analyzes customer interactions to improve sales performance.',
    url: 'https://www.gong.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gong',
    suggested_prompt: 'Analyze the sentiment of this sales call and identify potential objections...',
    color: 'purple'
  },
  {
    id: '60',
    name: 'InVideo',
    category: 'Video',
    description: 'AI-powered video editor for creating professional videos quickly.',
    url: 'https://invideo.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=invideo',
    suggested_prompt: 'Create a 30-second video ad for a new fitness app using stock footage...',
    color: 'green'
  },
  {
    id: '61',
    name: 'Hootsuite OwlyWriter',
    category: 'Social Media',
    description: 'AI content generator for social media posts and captions.',
    url: 'https://www.hootsuite.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hootsuite',
    suggested_prompt: 'Write a series of tweets about the benefits of sustainable living...',
    color: 'purple'
  },
  {
    id: '62',
    name: 'Scenario',
    category: 'Gaming',
    description: 'AI-powered asset generation for game developers.',
    url: 'https://www.scenario.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=scenario',
    suggested_prompt: 'Generate a set of fantasy-themed potion icons for a mobile RPG...',
    color: 'cyan'
  },
  {
    id: '63',
    name: 'Ada Health',
    category: 'Health',
    description: 'AI-powered symptom checker and health management tool.',
    url: 'https://ada.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=adahealth',
    suggested_prompt: 'Assess my symptoms of fatigue and joint pain...',
    color: 'purple'
  },
  {
    id: '64',
    name: 'Digit',
    category: 'Finance',
    description: 'AI-powered savings app that automates your financial goals.',
    url: 'https://digit.co',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=digit',
    suggested_prompt: 'Set up a savings goal for a new laptop and automate small daily transfers...',
    color: 'cyan'
  },
  {
    id: '65',
    name: 'Harvey AI',
    category: 'Legal',
    description: 'AI platform for elite law firms to automate legal research and drafting.',
    url: 'https://www.harvey.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=harvey',
    suggested_prompt: 'Draft a non-disclosure agreement for a tech partnership...',
    color: 'purple'
  },
  {
    id: '66',
    name: 'GuideGeek',
    category: 'Travel',
    description: 'AI travel assistant that provides personalized recommendations on WhatsApp.',
    url: 'https://guidegeek.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=guidegeek',
    suggested_prompt: 'Find the best hidden gem coffee shops in Rome...',
    color: 'cyan'
  },
  {
    id: '67',
    name: 'Redfin AI',
    category: 'Real Estate',
    description: 'AI-powered home recommendations and market analysis.',
    url: 'https://www.redfin.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=redfin',
    suggested_prompt: 'Compare the market value of homes in this neighborhood over the last year...',
    color: 'purple'
  },
  {
    id: '68',
    name: 'Phenom',
    category: 'HR',
    description: 'AI-powered talent experience platform for recruitment and retention.',
    url: 'https://www.phenom.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=phenom',
    suggested_prompt: 'Match candidates from our database to this new job description...',
    color: 'cyan'
  },
  {
    id: '69',
    name: 'People.ai',
    category: 'Sales',
    description: 'AI platform that provides insights into sales activity and pipeline health.',
    url: 'https://people.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=peopleai',
    suggested_prompt: 'Identify the most effective sales activities for closing enterprise deals...',
    color: 'purple'
  },
  {
    id: '70',
    name: 'Zendesk AI',
    category: 'Customer Support',
    description: 'AI-powered tools for customer service automation and agent assistance.',
    url: 'https://www.zendesk.com/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zendesk',
    suggested_prompt: 'Automatically categorize incoming support tickets by sentiment and urgency...',
    color: 'cyan'
  },
  {
    id: '71',
    name: 'H2O.ai',
    category: 'Data Science',
    description: 'Open-source AI platform for building and deploying machine learning models.',
    url: 'https://h2o.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=h2o',
    suggested_prompt: 'Train a gradient boosting model on this dataset for fraud detection...',
    color: 'purple'
  },
  {
    id: '72',
    name: 'CrowdStrike Falcon',
    category: 'Security',
    description: 'AI-powered endpoint protection and threat intelligence.',
    url: 'https://www.crowdstrike.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=crowdstrike',
    suggested_prompt: 'Identify and isolate a compromised endpoint in real-time...',
    color: 'cyan'
  },
  {
    id: '73',
    name: 'Splunk AI',
    category: 'DevOps',
    description: 'AI-powered data platform for observability and security.',
    url: 'https://www.splunk.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=splunk',
    suggested_prompt: 'Analyze log data to identify the source of a performance bottleneck...',
    color: 'purple'
  },
  {
    id: '74',
    name: 'Amazon CodeWhisperer',
    category: 'Coding',
    description: 'AI code generator that provides real-time recommendations in your IDE.',
    url: 'https://aws.amazon.com/codewhisperer',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=codewhisperer',
    suggested_prompt: 'Write a Lambda function in Python to process S3 events...',
    color: 'cyan'
  },
  {
    id: '75',
    name: 'Khroma',
    category: 'Design',
    description: 'AI color tool for designers that learns your preferences.',
    url: 'https://www.khroma.co',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=khroma',
    suggested_prompt: 'Generate a color palette based on my favorite 50 colors...',
    color: 'purple'
  },
  {
    id: '76',
    name: 'Hemingway Editor',
    category: 'Writing',
    description: 'AI-powered writing app that makes your writing bold and clear.',
    url: 'https://hemingwayapp.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hemingway',
    suggested_prompt: 'Identify passive voice and complex sentences in this blog post...',
    color: 'cyan'
  },
  {
    id: '77',
    name: 'Elsa Speak',
    category: 'Education',
    description: 'AI-powered English pronunciation coach.',
    url: 'https://elsaspeak.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=elsaspeak',
    suggested_prompt: 'Analyze my pronunciation of "th" sounds and provide feedback...',
    color: 'purple'
  },
  {
    id: '78',
    name: 'Zenia',
    category: 'Fitness',
    description: 'AI-powered yoga assistant that provides real-time posture correction.',
    url: 'https://zenia.app',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zenia',
    suggested_prompt: 'Correct my alignment in a downward-facing dog pose...',
    color: 'cyan'
  },
  {
    id: '79',
    name: 'Chorus.ai',
    category: 'Business',
    description: 'AI platform that analyzes sales calls to identify winning behaviors.',
    url: 'https://www.chorus.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=chorus',
    suggested_prompt: 'Identify the most common customer pain points mentioned in recent calls...',
    color: 'purple'
  },
  {
    id: '80',
    name: 'Pictory',
    category: 'Video',
    description: 'AI-powered video generator that creates videos from long-form content.',
    url: 'https://pictory.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pictory',
    suggested_prompt: 'Convert this 2000-word blog post into a 2-minute video for social media...',
    color: 'green'
  },
  {
    id: '81',
    name: 'Krisp',
    category: 'Audio',
    description: 'AI-powered noise cancellation for crystal-clear calls.',
    url: 'https://krisp.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=krisp',
    suggested_prompt: 'Remove background noise from this recording of a busy coffee shop...',
    color: 'orange'
  },
  {
    id: '82',
    name: 'Unbounce Smart Builder',
    category: 'Marketing',
    description: 'AI-powered landing page builder that optimizes for conversions.',
    url: 'https://unbounce.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=unbounce',
    suggested_prompt: 'Create a high-converting landing page for a new SaaS product...',
    color: 'purple'
  },
  {
    id: '83',
    name: 'Taskade AI',
    category: 'Productivity',
    description: 'AI-powered productivity platform for teams to collaborate and manage tasks.',
    url: 'https://www.taskade.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=taskade',
    suggested_prompt: 'Generate a project plan for a new website redesign...',
    color: 'cyan'
  },
  {
    id: '84',
    name: 'Sprout Social AI',
    category: 'Social Media',
    description: 'AI-powered social media management and listening platform.',
    url: 'https://sproutsocial.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sproutsocial',
    suggested_prompt: 'Analyze social media sentiment for our brand over the last 30 days...',
    color: 'purple'
  },
  {
    id: '85',
    name: 'Inworld AI',
    category: 'Gaming',
    description: 'AI platform for creating realistic NPCs and interactive characters.',
    url: 'https://inworld.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=inworld',
    suggested_prompt: 'Create a personality for a wise old wizard NPC in a fantasy game...',
    color: 'cyan'
  },
  {
    id: '86',
    name: 'K Health',
    category: 'Health',
    description: 'AI-powered primary care and symptom assessment.',
    url: 'https://khealth.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=khealth',
    suggested_prompt: 'Assess my symptoms of a sore throat and headache...',
    color: 'purple'
  },
  {
    id: '87',
    name: 'Qapital',
    category: 'Finance',
    description: 'AI-powered savings and investment app that uses behavioral science.',
    url: 'https://www.qapital.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=qapital',
    suggested_prompt: 'Set up a "Guilty Pleasure" rule to save $5 every time I buy coffee...',
    color: 'cyan'
  },
  {
    id: '88',
    name: 'Spellbook',
    category: 'Legal',
    description: 'AI legal assistant that helps you draft and review contracts in Word.',
    url: 'https://www.spellbook.legal',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=spellbook',
    suggested_prompt: 'Identify missing clauses in this employment agreement...',
    color: 'purple'
  },
  {
    id: '89',
    name: 'Tripnotes',
    category: 'Travel',
    description: 'AI-powered travel planner that helps you discover and organize trips.',
    url: 'https://tripnotes.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tripnotes',
    suggested_prompt: 'Find the best rooftop bars in New York City...',
    color: 'cyan'
  },
  {
    id: '90',
    name: 'Compass AI',
    category: 'Real Estate',
    description: 'AI-powered real estate platform for agents and home buyers.',
    url: 'https://www.compass.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=compass',
    suggested_prompt: 'Find homes that are likely to appreciate in value over the next 5 years...',
    color: 'purple'
  },
  {
    id: '91',
    name: 'Beamery',
    category: 'HR',
    description: 'AI-powered talent lifecycle management platform.',
    url: 'https://beamery.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=beamery',
    suggested_prompt: 'Predict which employees are at risk of leaving and suggest retention strategies...',
    color: 'cyan'
  },
  {
    id: '92',
    name: 'Highspot',
    category: 'Sales',
    description: 'AI-powered sales enablement platform that helps teams close more deals.',
    url: 'https://www.highspot.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=highspot',
    suggested_prompt: 'Recommend the best sales content for a follow-up email after a demo...',
    color: 'purple'
  },
  {
    id: '93',
    name: 'Gorgias AI',
    category: 'Customer Support',
    description: 'AI-powered helpdesk for e-commerce brands.',
    url: 'https://www.gorgias.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gorgias',
    suggested_prompt: 'Automatically respond to common customer questions about order status...',
    color: 'cyan'
  },
  {
    id: '94',
    name: 'Dataiku',
    category: 'Data Science',
    description: 'AI and machine learning platform for teams to build and deploy models.',
    url: 'https://www.dataiku.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=dataiku',
    suggested_prompt: 'Collaborate on a data science project and track model versions...',
    color: 'purple'
  },
  {
    id: '95',
    name: 'SentinelOne',
    category: 'Security',
    description: 'AI-powered autonomous endpoint protection and response.',
    url: 'https://www.sentinelone.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sentinelone',
    suggested_prompt: 'Automatically roll back a system to a healthy state after a malware attack...',
    color: 'cyan'
  },
  {
    id: '96',
    name: 'Dynatrace Davis',
    category: 'DevOps',
    description: 'AI engine that provides root-cause analysis and observability.',
    url: 'https://www.dynatrace.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=dynatrace',
    suggested_prompt: 'Identify the root cause of a sudden spike in application latency...',
    color: 'purple'
  },
  {
    id: '97',
    name: 'Sourcegraph Cody',
    category: 'Coding',
    description: 'AI coding assistant that understands your entire codebase.',
    url: 'https://about.sourcegraph.com/cody',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cody',
    suggested_prompt: 'Explain how the authentication logic works across the entire project...',
    color: 'cyan'
  },
  {
    id: '98',
    name: 'Looka',
    category: 'Design',
    description: 'AI-powered logo maker and brand identity platform.',
    url: 'https://looka.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=looka',
    suggested_prompt: 'Generate a professional logo for a new AI consulting firm...',
    color: 'purple'
  },
  {
    id: '99',
    name: 'Rytr',
    category: 'Writing',
    description: 'AI writing assistant that helps you create high-quality content in seconds.',
    url: 'https://rytr.me',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rytr',
    suggested_prompt: 'Write a catchy product description for a new eco-friendly water bottle...',
    color: 'cyan'
  },
  {
    id: '100',
    name: 'Brainly AI',
    category: 'Education',
    description: 'AI-powered homework helper and learning community.',
    url: 'https://brainly.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=brainly',
    suggested_prompt: 'Help me solve this complex physics problem about projectile motion...',
    color: 'purple'
  },
  {
    id: '101',
    name: 'Warp AI',
    category: 'Coding',
    description: 'AI-powered terminal that helps you work faster and smarter.',
    url: 'https://www.warp.dev',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=warp',
    suggested_prompt: 'Find the command to list all running Docker containers and their resource usage...',
    color: 'cyan'
  },
  {
    id: '102',
    name: 'Remove.bg',
    category: 'Design',
    description: 'AI tool to remove image backgrounds automatically in 5 seconds.',
    url: 'https://www.remove.bg',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=removebg',
    suggested_prompt: 'Remove the background from this portrait and make it transparent...',
    color: 'purple'
  },
  {
    id: '103',
    name: 'Sudowrite',
    category: 'Writing',
    description: 'AI writing partner for fiction writers and novelists.',
    url: 'https://www.sudowrite.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sudowrite',
    suggested_prompt: 'Describe a futuristic city in a way that evokes a sense of mystery and wonder...',
    color: 'cyan'
  },
  {
    id: '104',
    name: 'Quizlet Q-Chat',
    category: 'Education',
    description: 'AI study coach that helps you master any subject through conversation.',
    url: 'https://quizlet.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=quizlet',
    suggested_prompt: 'Quiz me on the key concepts of cellular biology...',
    color: 'purple'
  },
  {
    id: '105',
    name: 'Motion AI',
    category: 'Productivity',
    description: 'AI-powered calendar and task manager that optimizes your schedule.',
    url: 'https://www.usemotion.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=motionai',
    suggested_prompt: 'Automatically schedule my tasks for the week to maximize deep work time...',
    color: 'cyan'
  },
  {
    id: '106',
    name: 'Predis.ai',
    category: 'Social Media',
    description: 'AI-powered social media content generator and scheduler.',
    url: 'https://predis.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=predis',
    suggested_prompt: 'Generate a week of Instagram posts for a new vegan restaurant...',
    color: 'purple'
  },
  {
    id: '107',
    name: 'Rosebud AI',
    category: 'Gaming',
    description: 'AI platform for creating game assets and interactive experiences.',
    url: 'https://www.rosebud.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rosebud',
    suggested_prompt: 'Generate a 3D environment for a cyberpunk-themed adventure game...',
    color: 'cyan'
  },
  {
    id: '108',
    name: 'Woebot',
    category: 'Health',
    description: 'AI-powered mental health ally that provides CBT-based support.',
    url: 'https://woebothealth.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=woebot',
    suggested_prompt: 'Help me manage my anxiety about an upcoming presentation...',
    color: 'purple'
  },
  {
    id: '109',
    name: 'YNAB AI',
    category: 'Finance',
    description: 'AI-powered budgeting app that helps you give every dollar a job.',
    url: 'https://www.ynab.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ynab',
    suggested_prompt: 'Analyze my spending patterns and suggest a budget for my next vacation...',
    color: 'cyan'
  },
  {
    id: '110',
    name: 'Luminance',
    category: 'Legal',
    description: 'AI platform for document review and legal due diligence.',
    url: 'https://www.luminance.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=luminance',
    suggested_prompt: 'Identify potential risks in this set of commercial contracts...',
    color: 'purple'
  },
  {
    id: '111',
    name: 'iplan.ai',
    category: 'Travel',
    description: 'AI travel planner that creates personalized itineraries in seconds.',
    url: 'https://iplan.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=iplan',
    suggested_prompt: 'Create a 5-day itinerary for a family trip to London...',
    color: 'cyan'
  },
  {
    id: '112',
    name: 'Opendoor AI',
    category: 'Real Estate',
    description: 'AI-powered platform for buying and selling homes instantly.',
    url: 'https://www.opendoor.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=opendoor',
    suggested_prompt: 'Get an instant offer on my home based on recent market data...',
    color: 'purple'
  },
  {
    id: '113',
    name: 'Greenhouse AI',
    category: 'HR',
    description: 'AI-powered recruitment platform that helps teams hire better.',
    url: 'https://www.greenhouse.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=greenhouse',
    suggested_prompt: 'Screen resumes for a new engineering role and identify the top 10%...',
    color: 'cyan'
  },
  {
    id: '114',
    name: 'Seismic',
    category: 'Sales',
    description: 'AI-powered sales enablement and training platform.',
    url: 'https://seismic.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=seismic',
    suggested_prompt: 'Personalize a sales presentation for a prospect in the financial services industry...',
    color: 'purple'
  },
  {
    id: '115',
    name: 'Gladly AI',
    category: 'Customer Support',
    description: 'AI-powered customer service platform that focuses on people, not tickets.',
    url: 'https://www.gladly.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gladly',
    suggested_prompt: 'Provide a personalized response to a customer based on their entire purchase history...',
    color: 'cyan'
  },
  {
    id: '116',
    name: 'Alteryx AI',
    category: 'Data Science',
    description: 'AI-powered data analytics platform for automating complex workflows.',
    url: 'https://www.alteryx.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=alteryx',
    suggested_prompt: 'Clean and prep this messy dataset for a marketing analysis...',
    color: 'purple'
  },
  {
    id: '117',
    name: 'Cylance',
    category: 'Security',
    description: 'AI-powered endpoint security that prevents threats before they execute.',
    url: 'https://www.blackberry.com/us/en/products/cylance-endpoint-security',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cylance',
    suggested_prompt: 'Predict and block a zero-day attack based on file behavior...',
    color: 'cyan'
  },
  {
    id: '118',
    name: 'Datadog Watchdog',
    category: 'DevOps',
    description: 'AI-powered monitoring and security platform for cloud applications.',
    url: 'https://www.datadoghq.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=datadog',
    suggested_prompt: 'Identify anomalies in application performance and alert the team...',
    color: 'purple'
  },
  {
    id: '119',
    name: 'Blackbox AI',
    category: 'Coding',
    description: 'AI coding assistant that helps you write code faster and better.',
    url: 'https://www.useblackbox.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=blackbox',
    suggested_prompt: 'Generate a Python script to scrape data from a website and save it to a CSV...',
    color: 'cyan'
  },
  {
    id: '120',
    name: 'Fontjoy',
    category: 'Design',
    description: 'AI-powered font pairing tool for designers.',
    url: 'https://fontjoy.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fontjoy',
    suggested_prompt: 'Find a perfect font pairing for a modern tech blog...',
    color: 'purple'
  },
  {
    id: '121',
    name: 'Brandwatch',
    category: 'Social Media',
    description: 'AI-powered consumer intelligence and social media listening.',
    url: 'https://www.brandwatch.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=brandwatch',
    suggested_prompt: 'Analyze consumer sentiment around our latest product launch...',
    color: 'cyan'
  },
  {
    id: '122',
    name: 'Later',
    category: 'Social Media',
    description: 'AI-powered social media scheduling and link-in-bio tool.',
    url: 'https://later.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=later',
    suggested_prompt: 'Find the best time to post on Instagram for maximum engagement...',
    color: 'purple'
  },
  {
    id: '123',
    name: 'FeedHive',
    category: 'Social Media',
    description: 'AI-powered social media management and automation platform.',
    url: 'https://feedhive.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=feedhive',
    suggested_prompt: 'Recycle my best performing posts and schedule them for next week...',
    color: 'cyan'
  },
  {
    id: '124',
    name: 'Promethean AI',
    category: 'Gaming',
    description: 'AI that helps artists build virtual worlds for games and movies.',
    url: 'https://www.prometheanai.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=promethean',
    suggested_prompt: 'Generate a realistic forest environment with diverse vegetation...',
    color: 'purple'
  },
  {
    id: '125',
    name: 'Charisma.ai',
    category: 'Gaming',
    description: 'AI-powered interactive storytelling and character dialogue.',
    url: 'https://charisma.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=charisma',
    suggested_prompt: 'Create a branching dialogue tree for an NPC with a mysterious past...',
    color: 'cyan'
  },
  {
    id: '126',
    name: 'Ludo.ai',
    category: 'Gaming',
    description: 'AI-powered game ideation and research platform.',
    url: 'https://ludo.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ludo',
    suggested_prompt: 'Generate 5 unique game concepts for a mobile puzzle game...',
    color: 'purple'
  },
  {
    id: '127',
    name: 'Forward',
    category: 'Health',
    description: 'AI-powered primary care clinics with advanced diagnostic tools.',
    url: 'https://goforward.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=forward',
    suggested_prompt: 'Analyze my body scan results and identify potential health risks...',
    color: 'cyan'
  },
  {
    id: '128',
    name: 'Virta Health',
    category: 'Health',
    description: 'AI-powered platform for reversing type 2 diabetes through nutrition.',
    url: 'https://www.virtahealth.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=virta',
    suggested_prompt: 'Personalize my nutrition plan to help lower my blood sugar levels...',
    color: 'purple'
  },
  {
    id: '129',
    name: 'Sword Health',
    category: 'Health',
    description: 'AI-powered digital physical therapy and musculoskeletal care.',
    url: 'https://swordhealth.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sword',
    suggested_prompt: 'Guide me through a physical therapy session for chronic back pain...',
    color: 'cyan'
  },
  {
    id: '130',
    name: 'Ramp',
    category: 'Finance',
    description: 'AI-powered corporate cards and spend management platform.',
    url: 'https://ramp.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ramp',
    suggested_prompt: 'Identify duplicate subscriptions and suggest ways to save money...',
    color: 'purple'
  },
  {
    id: '131',
    name: 'Brex',
    category: 'Finance',
    description: 'AI-powered financial stack for growing businesses.',
    url: 'https://www.brex.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=brex',
    suggested_prompt: 'Automatically categorize my business expenses for tax season...',
    color: 'cyan'
  },
  {
    id: '132',
    name: 'Navan',
    category: 'Finance',
    description: 'AI-powered travel and expense management platform.',
    url: 'https://navan.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=navan',
    suggested_prompt: 'Book a business trip to San Francisco within my company\'s budget...',
    color: 'purple'
  },
  {
    id: '133',
    name: 'Bill.com',
    category: 'Finance',
    description: 'AI-powered accounts payable and receivable automation.',
    url: 'https://www.bill.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bill',
    suggested_prompt: 'Extract data from this invoice and schedule a payment...',
    color: 'cyan'
  },
  {
    id: '134',
    name: 'Ironclad',
    category: 'Legal',
    description: 'AI-powered contract lifecycle management for legal teams.',
    url: 'https://ironcladapp.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ironclad',
    suggested_prompt: 'Analyze this contract and highlight any non-standard clauses...',
    color: 'purple'
  },
  {
    id: '135',
    name: 'Everlaw',
    category: 'Legal',
    description: 'AI-powered ediscovery and litigation platform for legal professionals.',
    url: 'https://www.everlaw.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=everlaw',
    suggested_prompt: 'Search through millions of documents to find key evidence for a case...',
    color: 'cyan'
  },
  {
    id: '136',
    name: 'Reveal',
    category: 'Legal',
    description: 'AI-powered ediscovery and investigation platform.',
    url: 'https://www.revealdata.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=reveal',
    suggested_prompt: 'Identify patterns of communication that might indicate fraud...',
    color: 'purple'
  },
  {
    id: '137',
    name: 'Logikcull',
    category: 'Legal',
    description: 'AI-powered ediscovery and legal discovery software.',
    url: 'https://www.logikcull.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=logikcull',
    suggested_prompt: 'Automatically de-duplicate and organize legal documents for review...',
    color: 'cyan'
  },
  {
    id: '138',
    name: 'Hopper',
    category: 'Travel',
    description: 'AI-powered travel app that predicts prices and helps you save.',
    url: 'https://www.hopper.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hopper',
    suggested_prompt: 'Predict when the price for a flight to Paris will be at its lowest...',
    color: 'purple'
  },
  {
    id: '139',
    name: 'TripIt',
    category: 'Travel',
    description: 'AI-powered travel organizer that creates a master itinerary.',
    url: 'https://www.tripit.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tripit',
    suggested_prompt: 'Organize all my travel confirmation emails into a single itinerary...',
    color: 'cyan'
  },
  {
    id: '140',
    name: 'Wanderlog',
    category: 'Travel',
    description: 'AI-powered travel planner for road trips and group travel.',
    url: 'https://wanderlog.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wanderlog',
    suggested_prompt: 'Plan a 10-day road trip through the Pacific Northwest...',
    color: 'purple'
  },
  {
    id: '141',
    name: 'Entera',
    category: 'Real Estate',
    description: 'AI-powered platform for residential real estate investing.',
    url: 'https://www.entera.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=entera',
    suggested_prompt: 'Identify high-yield investment properties in the Austin market...',
    color: 'cyan'
  },
  {
    id: '142',
    name: 'LocalizeOS',
    category: 'Real Estate',
    description: 'AI-powered platform for real estate agents to engage leads.',
    url: 'https://www.localizeos.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=localizeos',
    suggested_prompt: 'Automatically follow up with new leads and qualify their interest...',
    color: 'purple'
  },
  {
    id: '143',
    name: 'Cherre',
    category: 'Real Estate',
    description: 'AI-powered real estate data and analytics platform.',
    url: 'https://cherre.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cherre',
    suggested_prompt: 'Analyze market trends and property values across multiple cities...',
    color: 'cyan'
  },
  {
    id: '144',
    name: 'Skyline AI',
    category: 'Real Estate',
    description: 'AI-powered commercial real estate investment platform.',
    url: 'https://www.skyline.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=skyline',
    suggested_prompt: 'Identify undervalued commercial properties with high growth potential...',
    color: 'purple'
  },
  {
    id: '145',
    name: 'Paradox',
    category: 'HR',
    description: 'AI-powered conversational recruiting platform.',
    url: 'https://www.paradox.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=paradox',
    suggested_prompt: 'Automate the initial screening process for high-volume hiring...',
    color: 'cyan'
  },
  {
    id: '146',
    name: 'Hired',
    category: 'HR',
    description: 'AI-powered marketplace for tech and sales talent.',
    url: 'https://hired.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hired',
    suggested_prompt: 'Match my skills and experience with the best tech companies...',
    color: 'purple'
  },
  {
    id: '147',
    name: 'Gloat',
    category: 'HR',
    description: 'AI-powered internal talent marketplace for large enterprises.',
    url: 'https://www.gloat.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gloat',
    suggested_prompt: 'Identify internal opportunities for career growth and skill development...',
    color: 'cyan'
  },
  {
    id: '148',
    name: 'SeekOut',
    category: 'HR',
    description: 'AI-powered talent search and recruiting platform.',
    url: 'https://www.seekout.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=seekout',
    suggested_prompt: 'Find diverse candidates with specialized technical skills...',
    color: 'purple'
  },
  {
    id: '149',
    name: 'Outreach',
    category: 'Sales',
    description: 'AI-powered sales execution platform for high-growth teams.',
    url: 'https://www.outreach.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=outreach',
    suggested_prompt: 'Optimize my sales sequences based on prospect engagement data...',
    color: 'cyan'
  },
  {
    id: '150',
    name: 'Salesloft',
    category: 'Sales',
    description: 'AI-powered sales engagement platform for revenue teams.',
    url: 'https://salesloft.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=salesloft',
    suggested_prompt: 'Identify the best sales actions to take for each prospect in my pipeline...',
    color: 'purple'
  },
  {
    id: '151',
    name: 'Apollo.io',
    category: 'Sales',
    description: 'AI-powered sales intelligence and engagement platform.',
    url: 'https://www.apollo.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=apollo',
    suggested_prompt: 'Find high-quality leads that match my ideal customer profile...',
    color: 'cyan'
  },
  {
    id: '152',
    name: 'ZoomInfo Chorus',
    category: 'Sales',
    description: 'AI-powered conversation intelligence for sales teams.',
    url: 'https://www.zoominfo.com/products/chorus',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zoominfo',
    suggested_prompt: 'Analyze my sales calls to identify areas for improvement...',
    color: 'purple'
  },
  {
    id: '153',
    name: 'Ada',
    category: 'Customer Support',
    description: 'AI-powered customer service automation platform.',
    url: 'https://www.ada.support',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ada',
    suggested_prompt: 'Automate my customer support interactions across multiple channels...',
    color: 'cyan'
  },
  {
    id: '154',
    name: 'Ultimate.ai',
    category: 'Customer Support',
    description: 'AI-powered customer service automation for enterprise teams.',
    url: 'https://www.ultimate.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ultimate',
    suggested_prompt: 'Deflect common support queries and provide instant answers...',
    color: 'purple'
  },
  {
    id: '155',
    name: 'Forethought',
    category: 'Customer Support',
    description: 'AI-powered customer service platform that automates the entire lifecycle.',
    url: 'https://www.forethought.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=forethought',
    suggested_prompt: 'Automatically route support tickets to the right agent...',
    color: 'cyan'
  },
  {
    id: '156',
    name: 'Solvvy',
    category: 'Customer Support',
    description: 'AI-powered self-service platform for customer support.',
    url: 'https://solvvy.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=solvvy',
    suggested_prompt: 'Provide instant answers to customer questions using my help center...',
    color: 'purple'
  },
  {
    id: '157',
    name: 'Domino Data Lab',
    category: 'Data Science',
    description: 'AI-powered enterprise MLOps platform for data science teams.',
    url: 'https://www.dominodatalab.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=domino',
    suggested_prompt: 'Collaborate on a data science project and track model experiments...',
    color: 'cyan'
  },
  {
    id: '158',
    name: 'KNIME',
    category: 'Data Science',
    description: 'Open-source AI-powered data analytics and integration platform.',
    url: 'https://www.knime.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=knime',
    suggested_prompt: 'Build a data pipeline to clean and transform my data...',
    color: 'purple'
  },
  {
    id: '159',
    name: 'RapidMiner',
    category: 'Data Science',
    description: 'AI-powered data science platform for building and deploying models.',
    url: 'https://rapidminer.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rapidminer',
    suggested_prompt: 'Train a machine learning model to predict customer churn...',
    color: 'cyan'
  },
  {
    id: '160',
    name: 'Pecan AI',
    category: 'Data Science',
    description: 'AI-powered predictive analytics for business teams.',
    url: 'https://www.pecan.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pecan',
    suggested_prompt: 'Predict future sales based on historical data and market trends...',
    color: 'purple'
  },
  {
    id: '161',
    name: 'Snyk',
    category: 'Security',
    description: 'AI-powered developer security platform for finding and fixing vulnerabilities.',
    url: 'https://snyk.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=snyk',
    suggested_prompt: 'Scan my code for security vulnerabilities and suggest fixes...',
    color: 'cyan'
  },
  {
    id: '162',
    name: 'Wiz',
    category: 'Security',
    description: 'AI-powered cloud security platform for identifying and mitigating risks.',
    url: 'https://www.wiz.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wiz',
    suggested_prompt: 'Identify security risks in my cloud infrastructure...',
    color: 'purple'
  },
  {
    id: '163',
    name: 'Orca Security',
    category: 'Security',
    description: 'AI-powered agentless cloud security platform.',
    url: 'https://orca.security',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=orca',
    suggested_prompt: 'Detect vulnerabilities and misconfigurations in my cloud environment...',
    color: 'cyan'
  },
  {
    id: '164',
    name: 'Lacework',
    category: 'Security',
    description: 'AI-powered cloud security platform for threat detection and response.',
    url: 'https://www.lacework.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lacework',
    suggested_prompt: 'Detect unusual activity in my cloud environment that might indicate a threat...',
    color: 'purple'
  },
  {
    id: '165',
    name: 'Harness',
    category: 'DevOps',
    description: 'AI-powered software delivery platform for automating CI/CD.',
    url: 'https://www.harness.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=harness',
    suggested_prompt: 'Automate my software delivery process and ensure reliable deployments...',
    color: 'cyan'
  },
  {
    id: '166',
    name: 'CircleCI AI',
    category: 'DevOps',
    description: 'AI-powered CI/CD platform for automating software development.',
    url: 'https://circleci.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=circleci',
    suggested_prompt: 'Optimize my build and test process using AI-powered insights...',
    color: 'purple'
  },
  {
    id: '167',
    name: 'GitLab Duo',
    category: 'DevOps',
    description: 'AI-powered features integrated into the GitLab platform.',
    url: 'https://about.gitlab.com/solutions/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gitlab',
    suggested_prompt: 'Use AI to help me write better code and automate my DevOps tasks...',
    color: 'cyan'
  },
  {
    id: '168',
    name: 'Pulumi AI',
    category: 'DevOps',
    description: 'AI-powered infrastructure as code platform.',
    url: 'https://www.pulumi.com/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pulumi',
    suggested_prompt: 'Generate infrastructure as code using natural language prompts...',
    color: 'purple'
  },
  {
    id: '169',
    name: 'HubSpot AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into the HubSpot CRM platform.',
    url: 'https://www.hubspot.com/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hubspot',
    suggested_prompt: 'Use AI to help me create content and manage my marketing campaigns...',
    color: 'cyan'
  },
  {
    id: '170',
    name: 'Salesforce Einstein',
    category: 'Business',
    description: 'AI-powered features integrated into the Salesforce platform.',
    url: 'https://www.salesforce.com/products/einstein/overview',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=salesforce',
    suggested_prompt: 'Use AI to help me predict sales and manage my customer relationships...',
    color: 'purple'
  },
  {
    id: '171',
    name: 'SAP AI',
    category: 'Business',
    description: 'AI-powered features integrated into the SAP enterprise platform.',
    url: 'https://www.sap.com/products/artificial-intelligence.html',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sap',
    suggested_prompt: 'Use AI to help me optimize my business processes and make better decisions...',
    color: 'cyan'
  },
  {
    id: '172',
    name: 'Oracle AI',
    category: 'Business',
    description: 'AI-powered features integrated into the Oracle cloud platform.',
    url: 'https://www.oracle.com/artificial-intelligence',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=oracle',
    suggested_prompt: 'Use AI to help me manage my data and build intelligent applications...',
    color: 'purple'
  },
  {
    id: '173',
    name: 'IBM Watson Studio',
    category: 'Data Science',
    description: 'AI-powered platform for building and deploying machine learning models.',
    url: 'https://www.ibm.com/products/watson-studio',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ibm',
    suggested_prompt: 'Use AI to help me build and deploy models at scale...',
    color: 'cyan'
  },
  {
    id: '174',
    name: 'Azure Machine Learning',
    category: 'Data Science',
    description: 'AI-powered platform for building and deploying machine learning models on Azure.',
    url: 'https://azure.microsoft.com/en-us/services/machine-learning',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=azure',
    suggested_prompt: 'Use AI to help me build and deploy models on the Azure cloud...',
    color: 'purple'
  },
  {
    id: '175',
    name: 'Google Vertex AI',
    category: 'Data Science',
    description: 'AI-powered platform for building and deploying machine learning models on Google Cloud.',
    url: 'https://cloud.google.com/vertex-ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=google',
    suggested_prompt: 'Use AI to help me build and deploy models on the Google Cloud platform...',
    color: 'cyan'
  },
  {
    id: '176',
    name: 'Databricks AI',
    category: 'Data Science',
    description: 'AI-powered platform for building and deploying machine learning models on Databricks.',
    url: 'https://www.databricks.com/product/machine-learning',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=databricks',
    suggested_prompt: 'Use AI to help me build and deploy models on the Databricks platform...',
    color: 'purple'
  },
  {
    id: '177',
    name: 'Snowflake AI',
    category: 'Data Science',
    description: 'AI-powered features integrated into the Snowflake data platform.',
    url: 'https://www.snowflake.com/en/data-cloud/ai-ml',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=snowflake',
    suggested_prompt: 'Use AI to help me manage my data and build intelligent applications on Snowflake...',
    color: 'cyan'
  },
  {
    id: '178',
    name: 'Cloudera AI',
    category: 'Data Science',
    description: 'AI-powered platform for building and deploying machine learning models on Cloudera.',
    url: 'https://www.cloudera.com/products/cloudera-machine-learning.html',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cloudera',
    suggested_prompt: 'Use AI to help me build and deploy models on the Cloudera platform...',
    color: 'purple'
  },
  {
    id: '179',
    name: 'Teradata AI',
    category: 'Data Science',
    description: 'AI-powered features integrated into the Teradata data platform.',
    url: 'https://www.teradata.com/products/ai-ml',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=teradata',
    suggested_prompt: 'Use AI to help me manage my data and build intelligent applications on Teradata...',
    color: 'cyan'
  },
  {
    id: '180',
    name: '6sense',
    category: 'Marketing',
    description: 'AI-powered account-based marketing platform.',
    url: 'https://6sense.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=6sense',
    suggested_prompt: 'Identify accounts that are in-market for our products...',
    color: 'purple'
  },
  {
    id: '181',
    name: 'Demandbase',
    category: 'Marketing',
    description: 'AI-powered account-based marketing platform.',
    url: 'https://www.demandbase.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=demandbase',
    suggested_prompt: 'Personalize our marketing campaigns for our target accounts...',
    color: 'cyan'
  },
  {
    id: '182',
    name: 'Terminus',
    category: 'Marketing',
    description: 'AI-powered account-based marketing platform.',
    url: 'https://terminus.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=terminus',
    suggested_prompt: 'Engage our target accounts across multiple channels...',
    color: 'purple'
  },
  {
    id: '183',
    name: 'RollWorks',
    category: 'Marketing',
    description: 'AI-powered account-based marketing platform.',
    url: 'https://www.rollworks.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rollworks',
    suggested_prompt: 'Identify and engage our ideal customer profile...',
    color: 'cyan'
  },
  {
    id: '184',
    name: 'Metadata.io',
    category: 'Marketing',
    description: 'AI-powered account-based marketing platform.',
    url: 'https://metadata.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=metadata',
    suggested_prompt: 'Automate our marketing campaigns and optimize for revenue...',
    color: 'purple'
  },
  {
    id: '185',
    name: 'Influ2',
    category: 'Marketing',
    description: 'AI-powered person-based advertising platform.',
    url: 'https://www.influ2.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=influ2',
    suggested_prompt: 'Target specific decision-makers with personalized ads...',
    color: 'cyan'
  },
  {
    id: '186',
    name: 'Sendoso',
    category: 'Marketing',
    description: 'AI-powered sending platform for corporate gifting.',
    url: 'https://sendoso.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sendoso',
    suggested_prompt: 'Send personalized gifts to our prospects and customers...',
    color: 'purple'
  },
  {
    id: '187',
    name: 'Alyce',
    category: 'Marketing',
    description: 'AI-powered personal experience platform for corporate gifting.',
    url: 'https://www.alyce.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=alyce',
    suggested_prompt: 'Create personalized experiences for our prospects and customers...',
    color: 'cyan'
  },
  {
    id: '188',
    name: 'Reachdesk',
    category: 'Marketing',
    description: 'AI-powered direct mail and corporate gifting platform.',
    url: 'https://reachdesk.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=reachdesk',
    suggested_prompt: 'Automate our direct mail and gifting campaigns...',
    color: 'purple'
  },
  {
    id: '189',
    name: 'Postal.io',
    category: 'Marketing',
    description: 'AI-powered offline marketing automation platform.',
    url: 'https://postal.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=postal',
    suggested_prompt: 'Manage our offline marketing campaigns and track ROI...',
    color: 'cyan'
  },
  {
    id: '190',
    name: 'Lob',
    category: 'Marketing',
    description: 'AI-powered direct mail automation platform.',
    url: 'https://www.lob.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lob',
    suggested_prompt: 'Automate our direct mail campaigns and personalize at scale...',
    color: 'purple'
  },
  {
    id: '191',
    name: 'Stannp',
    category: 'Marketing',
    description: 'AI-powered direct mail platform.',
    url: 'https://www.stannp.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=stannp',
    suggested_prompt: 'Send personalized direct mail to our customers and prospects...',
    color: 'cyan'
  },
  {
    id: '192',
    name: 'Inkpact',
    category: 'Marketing',
    description: 'AI-powered handwritten note platform.',
    url: 'https://inkpact.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=inkpact',
    suggested_prompt: 'Send personalized handwritten notes to our customers...',
    color: 'purple'
  },
  {
    id: '193',
    name: 'Handwrytten',
    category: 'Marketing',
    description: 'AI-powered handwritten note platform.',
    url: 'https://www.handwrytten.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=handwrytten',
    suggested_prompt: 'Send personalized handwritten notes to our customers and prospects...',
    color: 'cyan'
  },
  {
    id: '194',
    name: 'Scribeless',
    category: 'Marketing',
    description: 'AI-powered handwritten note platform.',
    url: 'https://scribeless.co',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=scribeless',
    suggested_prompt: 'Send personalized handwritten notes to our customers...',
    color: 'purple'
  },
  {
    id: '195',
    name: 'Postie',
    category: 'Marketing',
    description: 'AI-powered direct mail platform.',
    url: 'https://postie.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=postie',
    suggested_prompt: 'Manage our direct mail campaigns and track performance...',
    color: 'cyan'
  },
  {
    id: '196',
    name: 'Poplar',
    category: 'Marketing',
    description: 'AI-powered direct mail platform.',
    url: 'https://heypoplar.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=poplar',
    suggested_prompt: 'Send personalized direct mail to our customers...',
    color: 'purple'
  },
  {
    id: '197',
    name: 'Postgrid',
    category: 'Marketing',
    description: 'AI-powered direct mail automation platform.',
    url: 'https://www.postgrid.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=postgrid',
    suggested_prompt: 'Automate our direct mail campaigns and track delivery...',
    color: 'cyan'
  },
  {
    id: '198',
    name: 'Mailjoy',
    category: 'Marketing',
    description: 'AI-powered direct mail platform.',
    url: 'https://www.mailjoy.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mailjoy',
    suggested_prompt: 'Send personalized direct mail to our customers and prospects...',
    color: 'purple'
  },
  {
    id: '199',
    name: 'Enthusem',
    category: 'Marketing',
    description: 'AI-powered direct mail platform.',
    url: 'https://enthusem.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=enthusem',
    suggested_prompt: 'Send personalized direct mail to our customers...',
    color: 'cyan'
  },
  {
    id: '200',
    name: 'SendJim',
    category: 'Marketing',
    description: 'AI-powered direct mail platform.',
    url: 'https://www.sendjim.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sendjim',
    suggested_prompt: 'Send personalized direct mail to our customers and prospects...',
    color: 'purple'
  },
  {
    id: '201',
    name: 'Ocoya',
    category: 'Social Media',
    description: 'AI-powered social media management and content creation platform.',
    url: 'https://www.ocoya.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ocoya',
    suggested_prompt: 'Generate a week of social media posts for my new product launch...',
    color: 'cyan'
  },
  {
    id: '202',
    name: 'ContentStudio',
    category: 'Social Media',
    description: 'AI-powered social media management and content curation platform.',
    url: 'https://contentstudio.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=contentstudio',
    suggested_prompt: 'Discover trending content in my niche and schedule it for my social channels...',
    color: 'purple'
  },
  {
    id: '203',
    name: 'SocialBee',
    category: 'Social Media',
    description: 'AI-powered social media management and automation platform.',
    url: 'https://socialbee.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=socialbee',
    suggested_prompt: 'Categorize my social media posts and schedule them for optimal engagement...',
    color: 'cyan'
  },
  {
    id: '204',
    name: 'Missinglettr',
    category: 'Social Media',
    description: 'AI-powered social media automation platform for bloggers and content creators.',
    url: 'https://missinglettr.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=missinglettr',
    suggested_prompt: 'Automatically create a year-long social media campaign for my latest blog post...',
    color: 'purple'
  },
  {
    id: '205',
    name: 'Publer',
    category: 'Social Media',
    description: 'AI-powered social media management and scheduling platform.',
    url: 'https://publer.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=publer',
    suggested_prompt: 'Schedule my social media posts across all my channels from a single dashboard...',
    color: 'cyan'
  },
  {
    id: '206',
    name: 'CoSchedule',
    category: 'Social Media',
    description: 'AI-powered marketing calendar and social media management platform.',
    url: 'https://coschedule.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=coschedule',
    suggested_prompt: 'Plan and execute my entire marketing strategy from a single calendar...',
    color: 'purple'
  },
  {
    id: '207',
    name: 'Agorapulse',
    category: 'Social Media',
    description: 'AI-powered social media management and monitoring platform.',
    url: 'https://www.agorapulse.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=agorapulse',
    suggested_prompt: 'Monitor social media conversations and engage with my audience in real-time...',
    color: 'cyan'
  },
  {
    id: '208',
    name: 'Hootsuite Insights',
    category: 'Social Media',
    description: 'AI-powered social media listening and analytics platform.',
    url: 'https://www.hootsuite.com/products/insights',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hootsuiteinsights',
    suggested_prompt: 'Analyze social media trends and gain insights into my audience...',
    color: 'purple'
  },
  {
    id: '209',
    name: 'Buffer Analyze',
    category: 'Social Media',
    description: 'AI-powered social media analytics and reporting platform.',
    url: 'https://buffer.com/analyze',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bufferanalyze',
    suggested_prompt: 'Measure the performance of my social media campaigns and generate reports...',
    color: 'cyan'
  },
  {
    id: '210',
    name: 'Canva Magic Edit',
    category: 'Design',
    description: 'AI-powered image editing tool integrated into Canva.',
    url: 'https://www.canva.com/features/magic-edit',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=canvamagicedit',
    suggested_prompt: 'Replace an object in my image with something else using AI...',
    color: 'purple'
  },
  {
    id: '211',
    name: 'Adobe Express AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Adobe Express.',
    url: 'https://www.adobe.com/express/feature/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=adobeexpress',
    suggested_prompt: 'Generate a professional design for my social media post using AI...',
    color: 'cyan'
  },
  {
    id: '212',
    name: 'VistaCreate AI',
    category: 'Design',
    description: 'AI-powered design features integrated into VistaCreate.',
    url: 'https://vistacreate.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=vistacreate',
    suggested_prompt: 'Create a stunning design for my marketing materials using AI...',
    color: 'purple'
  },
  {
    id: '213',
    name: 'Snappa AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Snappa.',
    url: 'https://snappa.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=snappa',
    suggested_prompt: 'Generate a professional design for my blog post using AI...',
    color: 'cyan'
  },
  {
    id: '214',
    name: 'Stencil AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Stencil.',
    url: 'https://getstencil.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=stencil',
    suggested_prompt: 'Create a stunning design for my social media ads using AI...',
    color: 'purple'
  },
  {
    id: '215',
    name: 'PicMonkey AI',
    category: 'Design',
    description: 'AI-powered design features integrated into PicMonkey.',
    url: 'https://www.picmonkey.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=picmonkey',
    suggested_prompt: 'Generate a professional design for my website using AI...',
    color: 'cyan'
  },
  {
    id: '216',
    name: 'BeFunky AI',
    category: 'Design',
    description: 'AI-powered design features integrated into BeFunky.',
    url: 'https://www.befunky.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=befunky',
    suggested_prompt: 'Create a stunning design for my photo collage using AI...',
    color: 'purple'
  },
  {
    id: '217',
    name: 'Fotor AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Fotor.',
    url: 'https://www.fotor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fotor',
    suggested_prompt: 'Generate a professional design for my business card using AI...',
    color: 'cyan'
  },
  {
    id: '218',
    name: 'Pixlr AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Pixlr.',
    url: 'https://pixlr.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pixlr',
    suggested_prompt: 'Create a stunning design for my image editing project using AI...',
    color: 'purple'
  },
  {
    id: '219',
    name: 'Photopea AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Photopea.',
    url: 'https://www.photopea.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=photopea',
    suggested_prompt: 'Generate a professional design for my graphic design project using AI...',
    color: 'cyan'
  },
  {
    id: '220',
    name: 'GIMP AI',
    category: 'Design',
    description: 'AI-powered design features integrated into GIMP.',
    url: 'https://www.gimp.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gimp',
    suggested_prompt: 'Create a stunning design for my open-source project using AI...',
    color: 'purple'
  },
  {
    id: '221',
    name: 'Inkscape AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Inkscape.',
    url: 'https://inkscape.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=inkscape',
    suggested_prompt: 'Generate a professional design for my vector graphics project using AI...',
    color: 'cyan'
  },
  {
    id: '222',
    name: 'Krita AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Krita.',
    url: 'https://krita.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=krita',
    suggested_prompt: 'Create a stunning design for my digital painting project using AI...',
    color: 'purple'
  },
  {
    id: '223',
    name: 'Blender AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Blender.',
    url: 'https://www.blender.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=blender',
    suggested_prompt: 'Generate a professional design for my 3D modeling project using AI...',
    color: 'cyan'
  },
  {
    id: '224',
    name: 'Maya AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Maya.',
    url: 'https://www.autodesk.com/products/maya/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=maya',
    suggested_prompt: 'Create a stunning design for my animation project using AI...',
    color: 'purple'
  },
  {
    id: '225',
    name: '3ds Max AI',
    category: 'Design',
    description: 'AI-powered design features integrated into 3ds Max.',
    url: 'https://www.autodesk.com/products/3ds-max/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=3dsmax',
    suggested_prompt: 'Generate a professional design for my architectural visualization project using AI...',
    color: 'cyan'
  },
  {
    id: '226',
    name: 'Cinema 4D AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Cinema 4D.',
    url: 'https://www.maxon.net/en/cinema-4d/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cinema4d',
    suggested_prompt: 'Create a stunning design for my motion graphics project using AI...',
    color: 'purple'
  },
  {
    id: '227',
    name: 'Houdini AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Houdini.',
    url: 'https://www.sidefx.com/products/houdini/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=houdini',
    suggested_prompt: 'Generate a professional design for my visual effects project using AI...',
    color: 'cyan'
  },
  {
    id: '228',
    name: 'ZBrush AI',
    category: 'Design',
    description: 'AI-powered design features integrated into ZBrush.',
    url: 'https://pixologic.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zbrush',
    suggested_prompt: 'Create a stunning design for my digital sculpting project using AI...',
    color: 'purple'
  },
  {
    id: '229',
    name: 'Substance Painter AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Substance Painter.',
    url: 'https://www.adobe.com/products/substance3d-painter/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=substancepainter',
    suggested_prompt: 'Generate a professional design for my texture painting project using AI...',
    color: 'cyan'
  },
  {
    id: '230',
    name: 'Substance Designer AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Substance Designer.',
    url: 'https://www.adobe.com/products/substance3d-designer/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=substancedesigner',
    suggested_prompt: 'Create a stunning design for my material creation project using AI...',
    color: 'purple'
  },
  {
    id: '231',
    name: 'Marmoset Toolbag AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Marmoset Toolbag.',
    url: 'https://marmoset.co/toolbag/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=marmoset',
    suggested_prompt: 'Generate a professional design for my real-time rendering project using AI...',
    color: 'cyan'
  },
  {
    id: '232',
    name: 'KeyShot AI',
    category: 'Design',
    description: 'AI-powered design features integrated into KeyShot.',
    url: 'https://www.keyshot.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=keyshot',
    suggested_prompt: 'Create a stunning design for my product rendering project using AI...',
    color: 'purple'
  },
  {
    id: '233',
    name: 'V-Ray AI',
    category: 'Design',
    description: 'AI-powered design features integrated into V-Ray.',
    url: 'https://www.chaos.com/vray/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=vray',
    suggested_prompt: 'Generate a professional design for my high-end rendering project using AI...',
    color: 'cyan'
  },
  {
    id: '234',
    name: 'Corona Renderer AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Corona Renderer.',
    url: 'https://corona-renderer.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=coronarenderer',
    suggested_prompt: 'Create a stunning design for my photorealistic rendering project using AI...',
    color: 'purple'
  },
  {
    id: '235',
    name: 'OctaneRender AI',
    category: 'Design',
    description: 'AI-powered design features integrated into OctaneRender.',
    url: 'https://home.otoy.com/render/octane-render/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=octanerender',
    suggested_prompt: 'Generate a professional design for my GPU rendering project using AI...',
    color: 'cyan'
  },
  {
    id: '236',
    name: 'Redshift AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Redshift.',
    url: 'https://www.maxon.net/en/redshift/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=redshift',
    suggested_prompt: 'Create a stunning design for my production rendering project using AI...',
    color: 'purple'
  },
  {
    id: '237',
    name: 'Arnold AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Arnold.',
    url: 'https://www.autodesk.com/products/arnold/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=arnold',
    suggested_prompt: 'Generate a professional design for my ray-tracing rendering project using AI...',
    color: 'cyan'
  },
  {
    id: '238',
    name: 'Renderman AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Renderman.',
    url: 'https://renderman.pixar.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=renderman',
    suggested_prompt: 'Create a stunning design for my cinematic rendering project using AI...',
    color: 'purple'
  },
  {
    id: '239',
    name: 'Maxwell Render AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Maxwell Render.',
    url: 'https://www.maxwellrender.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=maxwellrender',
    suggested_prompt: 'Generate a professional design for my unbiased rendering project using AI...',
    color: 'cyan'
  },
  {
    id: '240',
    name: 'Indigo Renderer AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Indigo Renderer.',
    url: 'https://www.indigorenderer.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=indigorenderer',
    suggested_prompt: 'Create a stunning design for my spectral rendering project using AI...',
    color: 'purple'
  },
  {
    id: '241',
    name: 'LuxCoreRender AI',
    category: 'Design',
    description: 'AI-powered design features integrated into LuxCoreRender.',
    url: 'https://luxcorerender.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=luxcorerender',
    suggested_prompt: 'Generate a professional design for my open-source rendering project using AI...',
    color: 'cyan'
  },
  {
    id: '242',
    name: 'Kerkythea AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Kerkythea.',
    url: 'https://www.kerkythea.net/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kerkythea',
    suggested_prompt: 'Create a stunning design for my free rendering project using AI...',
    color: 'purple'
  },
  {
    id: '243',
    name: 'Mitsuba AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Mitsuba.',
    url: 'https://www.mitsuba-renderer.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mitsuba',
    suggested_prompt: 'Generate a professional design for my research rendering project using AI...',
    color: 'cyan'
  },
  {
    id: '244',
    name: 'Radiance AI',
    category: 'Design',
    description: 'AI-powered design features integrated into Radiance.',
    url: 'https://www.radiance-online.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=radiance',
    suggested_prompt: 'Create a stunning design for my lighting simulation project using AI...',
    color: 'purple'
  },
  {
    id: '245',
    name: 'Buoy Health',
    category: 'Health',
    description: 'AI-powered health assistant that helps you understand your symptoms.',
    url: 'https://www.buoyhealth.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=buoyhealth',
    suggested_prompt: 'Analyze my symptoms and provide personalized health recommendations...',
    color: 'cyan'
  },
  {
    id: '246',
    name: 'Symptomate',
    category: 'Health',
    description: 'AI-powered symptom checker and health assessment tool.',
    url: 'https://symptomate.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=symptomate',
    suggested_prompt: 'Check my symptoms and gain insights into my health condition...',
    color: 'purple'
  },
  {
    id: '247',
    name: 'HealthTap AI',
    category: 'Health',
    description: 'AI-powered health platform that provides instant answers from doctors.',
    url: 'https://www.healthtap.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=healthtap',
    suggested_prompt: 'Ask a health question and receive an instant answer from an AI-powered doctor...',
    color: 'cyan'
  },
  {
    id: '248',
    name: 'Your.MD AI',
    category: 'Health',
    description: 'AI-powered health assistant that provides personalized health information.',
    url: 'https://www.your.md/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=yourmd',
    suggested_prompt: 'Gain insights into my health condition and receive personalized recommendations...',
    color: 'purple'
  },
  {
    id: '249',
    name: 'Infermedica AI',
    category: 'Health',
    description: 'AI-powered health platform that provides symptom checking and triage.',
    url: 'https://infermedica.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=infermedica',
    suggested_prompt: 'Check my symptoms and receive personalized health recommendations...',
    color: 'cyan'
  },
  {
    id: '250',
    name: 'Curai AI',
    category: 'Health',
    description: 'AI-powered health platform that provides virtual primary care.',
    url: 'https://www.curai.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=curai',
    suggested_prompt: 'Receive personalized health recommendations and virtual primary care using AI...',
    color: 'purple'
  },
  {
    id: '251',
    name: 'Cleo',
    category: 'Finance',
    description: 'AI-powered money assistant that helps you save and manage your budget.',
    url: 'https://www.meetcleo.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cleo',
    suggested_prompt: 'Analyze my spending habits and suggest ways to save money...',
    color: 'cyan'
  },
  {
    id: '252',
    name: 'Digit',
    category: 'Finance',
    description: 'AI-powered savings app that automatically saves money for you.',
    url: 'https://digit.co',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=digit',
    suggested_prompt: 'Automatically save money for my upcoming vacation...',
    color: 'purple'
  },
  {
    id: '253',
    name: 'Qapital',
    category: 'Finance',
    description: 'AI-powered banking and savings app that helps you reach your goals.',
    url: 'https://www.qapital.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=qapital',
    suggested_prompt: 'Set up a savings goal and automate my contributions using AI...',
    color: 'cyan'
  },
  {
    id: '254',
    name: 'Mint AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Mint personal finance app.',
    url: 'https://mint.intuit.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mint',
    suggested_prompt: 'Use AI to help me track my spending and manage my budget...',
    color: 'purple'
  },
  {
    id: '255',
    name: 'YNAB AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the YNAB budgeting app.',
    url: 'https://www.ynab.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ynab',
    suggested_prompt: 'Use AI to help me create a budget and track my expenses...',
    color: 'cyan'
  },
  {
    id: '256',
    name: 'Personal Capital AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Personal Capital wealth management app.',
    url: 'https://www.personalcapital.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=personalcapital',
    suggested_prompt: 'Use AI to help me manage my investments and track my net worth...',
    color: 'purple'
  },
  {
    id: '257',
    name: 'Betterment AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Betterment robo-advisor platform.',
    url: 'https://www.betterment.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=betterment',
    suggested_prompt: 'Use AI to help me invest my money and reach my financial goals...',
    color: 'cyan'
  },
  {
    id: '258',
    name: 'Wealthfront AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Wealthfront robo-advisor platform.',
    url: 'https://www.wealthfront.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wealthfront',
    suggested_prompt: 'Use AI to help me manage my portfolio and optimize my taxes...',
    color: 'purple'
  },
  {
    id: '259',
    name: 'Acorns AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Acorns micro-investing app.',
    url: 'https://www.acorns.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=acorns',
    suggested_prompt: 'Use AI to help me invest my spare change and grow my wealth...',
    color: 'cyan'
  },
  {
    id: '260',
    name: 'Robinhood AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Robinhood trading app.',
    url: 'https://robinhood.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=robinhood',
    suggested_prompt: 'Use AI to help me trade stocks and manage my portfolio...',
    color: 'purple'
  },
  {
    id: '261',
    name: 'Coinbase AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Coinbase crypto exchange platform.',
    url: 'https://www.coinbase.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=coinbase',
    suggested_prompt: 'Use AI to help me trade crypto and manage my digital assets...',
    color: 'cyan'
  },
  {
    id: '262',
    name: 'Binance AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Binance crypto exchange platform.',
    url: 'https://www.binance.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=binance',
    suggested_prompt: 'Use AI to help me trade crypto and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '263',
    name: 'Kraken AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Kraken crypto exchange platform.',
    url: 'https://www.kraken.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kraken',
    suggested_prompt: 'Use AI to help me trade crypto and manage my digital assets on Kraken...',
    color: 'cyan'
  },
  {
    id: '264',
    name: 'Gemini AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Gemini crypto exchange platform.',
    url: 'https://www.gemini.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gemini',
    suggested_prompt: 'Use AI to help me trade crypto and manage my digital assets on Gemini...',
    color: 'purple'
  },
  {
    id: '265',
    name: 'Crypto.com AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Crypto.com platform.',
    url: 'https://crypto.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cryptocom',
    suggested_prompt: 'Use AI to help me trade crypto and manage my digital assets on Crypto.com...',
    color: 'cyan'
  },
  {
    id: '266',
    name: 'KuCoin AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the KuCoin crypto exchange platform.',
    url: 'https://www.kucoin.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kucoin',
    suggested_prompt: 'Use AI to help me trade crypto and gain insights into the market on KuCoin...',
    color: 'purple'
  },
  {
    id: '267',
    name: 'Huobi AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Huobi crypto exchange platform.',
    url: 'https://www.huobi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=huobi',
    suggested_prompt: 'Use AI to help me trade crypto and manage my digital assets on Huobi...',
    color: 'cyan'
  },
  {
    id: '268',
    name: 'OKX AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the OKX crypto exchange platform.',
    url: 'https://www.okx.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=okx',
    suggested_prompt: 'Use AI to help me trade crypto and gain insights into the market on OKX...',
    color: 'purple'
  },
  {
    id: '269',
    name: 'Bybit AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Bybit crypto exchange platform.',
    url: 'https://www.bybit.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bybit',
    suggested_prompt: 'Use AI to help me trade crypto and manage my digital assets on Bybit...',
    color: 'cyan'
  },
  {
    id: '270',
    name: 'Gate.io AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Gate.io crypto exchange platform.',
    url: 'https://www.gate.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gateio',
    suggested_prompt: 'Use AI to help me trade crypto and gain insights into the market on Gate.io...',
    color: 'purple'
  },
  {
    id: '271',
    name: 'CaseText',
    category: 'Legal',
    description: 'AI-powered legal research platform for lawyers.',
    url: 'https://casetext.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=casetext',
    suggested_prompt: 'Search through legal documents and find relevant case law using AI...',
    color: 'cyan'
  },
  {
    id: '272',
    name: 'Ross Intelligence',
    category: 'Legal',
    description: 'AI-powered legal research assistant.',
    url: 'https://rossintelligence.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rossintelligence',
    suggested_prompt: 'Ask a legal question and receive an instant answer from an AI-powered assistant...',
    color: 'purple'
  },
  {
    id: '273',
    name: 'Luminance',
    category: 'Legal',
    description: 'AI-powered document review platform for legal professionals.',
    url: 'https://www.luminance.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=luminance',
    suggested_prompt: 'Analyze legal documents and identify key information using AI...',
    color: 'cyan'
  },
  {
    id: '274',
    name: 'Kira Systems',
    category: 'Legal',
    description: 'AI-powered contract analysis and review software.',
    url: 'https://kirasystems.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kirasystems',
    suggested_prompt: 'Extract data from contracts and identify potential risks using AI...',
    color: 'purple'
  },
  {
    id: '275',
    name: 'LawGeex',
    category: 'Legal',
    description: 'AI-powered contract review and automation platform.',
    url: 'https://www.lawgeex.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lawgeex',
    suggested_prompt: 'Automatically review contracts and ensure compliance using AI...',
    color: 'cyan'
  },
  {
    id: '276',
    name: 'ContractPodAi',
    category: 'Legal',
    description: 'AI-powered contract lifecycle management platform.',
    url: 'https://contractpodai.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=contractpodai',
    suggested_prompt: 'Manage the entire contract lifecycle and gain insights using AI...',
    color: 'purple'
  },
  {
    id: '277',
    name: 'Icertis AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Icertis contract management platform.',
    url: 'https://www.icertis.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=icertis',
    suggested_prompt: 'Use AI to help me manage my contracts and optimize my business processes...',
    color: 'cyan'
  },
  {
    id: '278',
    name: 'SirionLabs AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the SirionLabs contract management platform.',
    url: 'https://www.sirionlabs.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sirionlabs',
    suggested_prompt: 'Use AI to help me manage my contracts and track performance...',
    color: 'purple'
  },
  {
    id: '279',
    name: 'Evisort AI',
    category: 'Legal',
    description: 'AI-powered contract analysis and management platform.',
    url: 'https://www.evisort.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=evisort',
    suggested_prompt: 'Use AI to help me analyze my contracts and gain insights into my business...',
    color: 'cyan'
  },
  {
    id: '280',
    name: 'LinkSquares AI',
    category: 'Legal',
    description: 'AI-powered contract management and analysis platform.',
    url: 'https://linksquares.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=linksquares',
    suggested_prompt: 'Use AI to help me manage my contracts and identify potential risks...',
    color: 'purple'
  },
  {
    id: '281',
    name: 'Juro AI',
    category: 'Legal',
    description: 'AI-powered contract automation and management platform.',
    url: 'https://juro.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=juro',
    suggested_prompt: 'Use AI to help me create and manage my contracts...',
    color: 'cyan'
  },
  {
    id: '282',
    name: 'SpotDraft AI',
    category: 'Legal',
    description: 'AI-powered contract automation and management platform.',
    url: 'https://www.spotdraft.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=spotdraft',
    suggested_prompt: 'Use AI to help me manage my contracts and ensure compliance...',
    color: 'purple'
  },
  {
    id: '283',
    name: 'Clause AI',
    category: 'Legal',
    description: 'AI-powered smart contract platform.',
    url: 'https://clause.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=clause',
    suggested_prompt: 'Use AI to help me create and manage smart contracts...',
    color: 'cyan'
  },
  {
    id: '284',
    name: 'OpenLaw AI',
    category: 'Legal',
    description: 'AI-powered platform for creating and managing legal documents on the blockchain.',
    url: 'https://openlaw.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=openlaw',
    suggested_prompt: 'Use AI to help me create and manage legal documents on the blockchain...',
    color: 'purple'
  },
  {
    id: '285',
    name: 'Accord Project AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Accord Project open-source platform.',
    url: 'https://www.accordproject.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=accordproject',
    suggested_prompt: 'Use AI to help me create and manage smart legal contracts...',
    color: 'cyan'
  },
  {
    id: '286',
    name: 'LexCheck AI',
    category: 'Legal',
    description: 'AI-powered contract review and negotiation platform.',
    url: 'https://lexcheck.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lexcheck',
    suggested_prompt: 'Use AI to help me review and negotiate contracts...',
    color: 'purple'
  },
  {
    id: '287',
    name: 'Skyscanner AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Skyscanner travel search engine.',
    url: 'https://www.skyscanner.net/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=skyscanner',
    suggested_prompt: 'Use AI to help me find the best flights and hotels for my trip...',
    color: 'cyan'
  },
  {
    id: '288',
    name: 'Trip.com AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Trip.com travel platform.',
    url: 'https://www.trip.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tripcom',
    suggested_prompt: 'Use AI to help me plan and book my entire trip...',
    color: 'purple'
  },
  {
    id: '289',
    name: 'Expedia AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Expedia travel platform.',
    url: 'https://www.expedia.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=expedia',
    suggested_prompt: 'Use AI to help me find the best travel deals and manage my itinerary...',
    color: 'cyan'
  },
  {
    id: '290',
    name: 'Booking.com AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Booking.com travel platform.',
    url: 'https://www.booking.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bookingcom',
    suggested_prompt: 'Use AI to help me find the best hotels and manage my bookings...',
    color: 'purple'
  },
  {
    id: '291',
    name: 'Airbnb AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Airbnb platform.',
    url: 'https://www.airbnb.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=airbnb',
    suggested_prompt: 'Use AI to help me find the best unique stays and experiences...',
    color: 'cyan'
  },
  {
    id: '292',
    name: 'TripAdvisor AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the TripAdvisor platform.',
    url: 'https://www.tripadvisor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tripadvisor',
    suggested_prompt: 'Use AI to help me find the best restaurants and attractions...',
    color: 'purple'
  },
  {
    id: '293',
    name: 'Kayak AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Kayak travel search engine.',
    url: 'https://www.kayak.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kayak',
    suggested_prompt: 'Use AI to help me find the best travel deals and track prices...',
    color: 'cyan'
  },
  {
    id: '294',
    name: 'Google Travel AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Google Travel platform.',
    url: 'https://www.google.com/travel/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=googletravel',
    suggested_prompt: 'Use AI to help me plan my trip and manage my travel documents...',
    color: 'purple'
  },
  {
    id: '295',
    name: 'Roadtrippers AI',
    category: 'Travel',
    description: 'AI-powered road trip planning platform.',
    url: 'https://roadtrippers.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=roadtrippers',
    suggested_prompt: 'Use AI to help me plan the ultimate road trip...',
    color: 'cyan'
  },
  {
    id: '296',
    name: 'Sygic Travel AI',
    category: 'Travel',
    description: 'AI-powered travel planner and map platform.',
    url: 'https://travel.sygic.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sygictravel',
    suggested_prompt: 'Use AI to help me plan my trip and explore new destinations...',
    color: 'purple'
  },
  {
    id: '297',
    name: 'Citymapper AI',
    category: 'Travel',
    description: 'AI-powered public transit and navigation app.',
    url: 'https://citymapper.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=citymapper',
    suggested_prompt: 'Use AI to help me find the best way to get around the city...',
    color: 'cyan'
  },
  {
    id: '298',
    name: 'Rome2rio AI',
    category: 'Travel',
    description: 'AI-powered travel search engine for finding the best way to get from A to B.',
    url: 'https://www.rome2rio.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rome2rio',
    suggested_prompt: 'Use AI to help me find the best travel options for my trip...',
    color: 'purple'
  },
  {
    id: '299',
    name: 'Omio AI',
    category: 'Travel',
    description: 'AI-powered travel platform for booking trains, buses, and flights.',
    url: 'https://www.omio.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=omio',
    suggested_prompt: 'Use AI to help me find the best travel deals and manage my bookings...',
    color: 'cyan'
  },
  {
    id: '300',
    name: 'Trainline AI',
    category: 'Travel',
    description: 'AI-powered platform for booking train and bus tickets.',
    url: 'https://www.thetrainline.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=trainline',
    suggested_prompt: 'Use AI to help me find the best train and bus deals and manage my tickets...',
    color: 'purple'
  },
  {
    id: '301',
    name: 'Eightfold.ai',
    category: 'HR',
    description: 'AI-powered talent intelligence platform for enterprises.',
    url: 'https://eightfold.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=eightfold',
    suggested_prompt: 'Use AI to help me find and retain the best talent for my organization...',
    color: 'cyan'
  },
  {
    id: '302',
    name: 'Beamery',
    category: 'HR',
    description: 'AI-powered talent lifecycle management platform.',
    url: 'https://beamery.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=beamery',
    suggested_prompt: 'Use AI to help me manage my talent pipeline and engage with candidates...',
    color: 'purple'
  },
  {
    id: '303',
    name: 'Phenom',
    category: 'HR',
    description: 'AI-powered talent experience management platform.',
    url: 'https://www.phenom.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=phenom',
    suggested_prompt: 'Use AI to help me create a personalized experience for my candidates and employees...',
    color: 'cyan'
  },
  {
    id: '304',
    name: 'Textio',
    category: 'HR',
    description: 'AI-powered writing assistant for creating inclusive job descriptions.',
    url: 'https://textio.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=textio',
    suggested_prompt: 'Use AI to help me write job descriptions that attract a diverse pool of candidates...',
    color: 'purple'
  },
  {
    id: '305',
    name: 'HireVue',
    category: 'HR',
    description: 'AI-powered video interviewing and assessment platform.',
    url: 'https://www.hirevue.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hirevue',
    suggested_prompt: 'Use AI to help me screen candidates and identify the best fits for my roles...',
    color: 'cyan'
  },
  {
    id: '306',
    name: 'Pymetrics',
    category: 'HR',
    description: 'AI-powered talent matching platform using neuroscience-based games.',
    url: 'https://www.pymetrics.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pymetrics',
    suggested_prompt: 'Use AI to help me match candidates with the right roles based on their cognitive traits...',
    color: 'purple'
  },
  {
    id: '307',
    name: 'Mya Systems',
    category: 'HR',
    description: 'AI-powered conversational AI for recruiting.',
    url: 'https://www.mya.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mya',
    suggested_prompt: 'Use AI to help me automate my recruiting process and engage with candidates...',
    color: 'cyan'
  },
  {
    id: '308',
    name: 'Ideal',
    category: 'HR',
    description: 'AI-powered talent screening and matching software.',
    url: 'https://ideal.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ideal',
    suggested_prompt: 'Use AI to help me screen resumes and identify the best candidates for my roles...',
    color: 'purple'
  },
  {
    id: '309',
    name: 'AllyO',
    category: 'HR',
    description: 'AI-powered recruiting automation platform.',
    url: 'https://www.allyo.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=allyo',
    suggested_prompt: 'Use AI to help me automate my hiring process and improve candidate experience...',
    color: 'cyan'
  },
  {
    id: '310',
    name: 'Wade & Wendy',
    category: 'HR',
    description: 'AI-powered recruiting assistants for candidates and recruiters.',
    url: 'https://wadeandwendy.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wadeandwendy',
    suggested_prompt: 'Use AI to help me find the right job or the right candidate for my role...',
    color: 'purple'
  },
  {
    id: '311',
    name: 'Stella.ai',
    category: 'HR',
    description: 'AI-powered talent network for shared recruiting.',
    url: 'https://stella.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=stella',
    suggested_prompt: 'Use AI to help me find candidates from a shared network of top talent...',
    color: 'cyan'
  },
  {
    id: '312',
    name: 'Entelo',
    category: 'HR',
    description: 'AI-powered talent sourcing and engagement platform.',
    url: 'https://www.entelo.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=entelo',
    suggested_prompt: 'Use AI to help me find and engage with passive candidates...',
    color: 'purple'
  },
  {
    id: '313',
    name: 'Arya',
    category: 'HR',
    description: 'AI-powered recruiting platform that automates sourcing and engagement.',
    url: 'https://goarya.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=arya',
    suggested_prompt: 'Use AI to help me find the best candidates and automate my outreach...',
    color: 'cyan'
  },
  {
    id: '314',
    name: 'Fetcher',
    category: 'HR',
    description: 'AI-powered talent sourcing and outreach platform.',
    url: 'https://fetcher.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fetcher',
    suggested_prompt: 'Use AI to help me find and engage with top talent for my roles...',
    color: 'purple'
  },
  {
    id: '315',
    name: 'Humanly',
    category: 'HR',
    description: 'AI-powered conversational AI for high-volume recruiting.',
    url: 'https://humanly.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=humanly',
    suggested_prompt: 'Use AI to help me automate my high-volume hiring process...',
    color: 'cyan'
  },
  {
    id: '316',
    name: 'XOR',
    category: 'HR',
    description: 'AI-powered recruiting automation platform.',
    url: 'https://www.xor.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=xor',
    suggested_prompt: 'Use AI to help me automate my recruiting tasks and engage with candidates...',
    color: 'purple'
  },
  {
    id: '317',
    name: 'Gong',
    category: 'Sales',
    description: 'AI-powered revenue intelligence platform for sales teams.',
    url: 'https://www.gong.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gong',
    suggested_prompt: 'Use AI to help me analyze my sales calls and improve my team\'s performance...',
    color: 'cyan'
  },
  {
    id: '318',
    name: 'Revenue.io',
    category: 'Sales',
    description: 'AI-powered real-time revenue guidance platform.',
    url: 'https://www.revenue.io',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=revenueio',
    suggested_prompt: 'Use AI to help me guide my sales team in real-time and close more deals...',
    color: 'purple'
  },
  {
    id: '319',
    name: 'Clari',
    category: 'Sales',
    description: 'AI-powered revenue operations platform.',
    url: 'https://www.clari.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=clari',
    suggested_prompt: 'Use AI to help me manage my revenue pipeline and forecast sales accurately...',
    color: 'cyan'
  },
  {
    id: '320',
    name: 'InsightSquared',
    category: 'Sales',
    description: 'AI-powered revenue intelligence and forecasting platform.',
    url: 'https://www.insightsquared.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=insightsquared',
    suggested_prompt: 'Use AI to help me gain insights into my sales data and improve my forecasting...',
    color: 'purple'
  },
  {
    id: '321',
    name: 'People.ai',
    category: 'Sales',
    description: 'AI-powered revenue intelligence platform that automates data capture.',
    url: 'https://people.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=peopleai',
    suggested_prompt: 'Use AI to help me automate my sales data capture and gain insights into my pipeline...',
    color: 'cyan'
  },
  {
    id: '322',
    name: 'Troops.ai',
    category: 'Sales',
    description: 'AI-powered revenue communications platform integrated into Slack.',
    url: 'https://troops.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=troopsai',
    suggested_prompt: 'Use AI to help me manage my sales workflows and collaborate with my team in Slack...',
    color: 'purple'
  },
  {
    id: '323',
    name: 'Conversica',
    category: 'Sales',
    description: 'AI-powered conversational AI for sales and marketing.',
    url: 'https://www.conversica.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=conversica',
    suggested_prompt: 'Use AI to help me engage with my leads and qualify them for my sales team...',
    color: 'cyan'
  },
  {
    id: '324',
    name: 'Drift AI',
    category: 'Marketing',
    description: 'AI-powered conversational marketing and sales platform.',
    url: 'https://www.drift.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=drift',
    suggested_prompt: 'Use AI to help me engage with my website visitors and generate more leads...',
    color: 'purple'
  },
  {
    id: '325',
    name: 'Qualified AI',
    category: 'Marketing',
    description: 'AI-powered conversational marketing and sales platform for Salesforce users.',
    url: 'https://www.qualified.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=qualified',
    suggested_prompt: 'Use AI to help me engage with my target accounts and generate more pipeline...',
    color: 'cyan'
  },
  {
    id: '326',
    name: 'Intercom Fin',
    category: 'Customer Support',
    description: 'AI-powered customer service bot integrated into Intercom.',
    url: 'https://www.intercom.com/fin',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=intercomfin',
    suggested_prompt: 'Use AI to help me provide instant answers to my customers\' questions...',
    color: 'purple'
  },
  {
    id: '327',
    name: 'Zendesk AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Zendesk platform.',
    url: 'https://www.zendesk.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zendesk',
    suggested_prompt: 'Use AI to help me automate my customer support and improve agent productivity...',
    color: 'cyan'
  },
  {
    id: '328',
    name: 'Microsoft Dynamics 365 AI',
    category: 'Business',
    description: 'AI-powered features integrated into the Microsoft Dynamics 365 platform.',
    url: 'https://dynamics.microsoft.com/en-us/ai-overview',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=microsoftdynamics',
    suggested_prompt: 'Use AI to help me manage my business processes and gain insights into my data...',
    color: 'purple'
  },
  {
    id: '329',
    name: 'Oracle CX AI',
    category: 'Business',
    description: 'AI-powered features integrated into the Oracle customer experience platform.',
    url: 'https://www.oracle.com/cx/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=oraclecx',
    suggested_prompt: 'Use AI to help me manage my customer relationships and improve my marketing...',
    color: 'cyan'
  },
  {
    id: '330',
    name: 'Netomi',
    category: 'Customer Support',
    description: 'AI-powered customer service automation platform.',
    url: 'https://www.netomi.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=netomi',
    suggested_prompt: 'Use AI to help me automate my customer support across multiple channels...',
    color: 'purple'
  },
  {
    id: '331',
    name: 'Thankful',
    category: 'Customer Support',
    description: 'AI-powered customer service automation for e-commerce brands.',
    url: 'https://www.thankful.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=thankful',
    suggested_prompt: 'Use AI to help me automate my customer support and improve customer satisfaction...',
    color: 'cyan'
  },
  {
    id: '332',
    name: 'Zowie',
    category: 'Customer Support',
    description: 'AI-powered customer service automation for e-commerce teams.',
    url: 'https://zowie.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zowie',
    suggested_prompt: 'Use AI to help me automate my customer support and generate more revenue...',
    color: 'purple'
  },
  {
    id: '333',
    name: 'Kustomer AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Kustomer platform.',
    url: 'https://www.kustomer.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kustomer',
    suggested_prompt: 'Use AI to help me manage my customer relationships and improve my support...',
    color: 'cyan'
  },
  {
    id: '334',
    name: 'Gladly AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Gladly platform.',
    url: 'https://www.gladly.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gladly',
    suggested_prompt: 'Use AI to help me provide a personalized experience for my customers...',
    color: 'purple'
  },
  {
    id: '335',
    name: 'Gorgias AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Gorgias platform for e-commerce.',
    url: 'https://www.gorgias.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gorgias',
    suggested_prompt: 'Use AI to help me automate my customer support and improve my response times...',
    color: 'cyan'
  },
  {
    id: '336',
    name: 'Re:amaze AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Re:amaze platform.',
    url: 'https://www.reamaze.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=reamaze',
    suggested_prompt: 'Use AI to help me manage my customer support and engage with my audience...',
    color: 'purple'
  },
  {
    id: '337',
    name: 'Help Scout AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Help Scout platform.',
    url: 'https://www.helpscout.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=helpscout',
    suggested_prompt: 'Use AI to help me manage my customer support and improve my team\'s productivity...',
    color: 'cyan'
  },
  {
    id: '338',
    name: 'Front AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Front platform.',
    url: 'https://front.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=front',
    suggested_prompt: 'Use AI to help me manage my shared inboxes and collaborate with my team...',
    color: 'purple'
  },
  {
    id: '339',
    name: 'Aircall AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Aircall phone system.',
    url: 'https://aircall.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=aircall',
    suggested_prompt: 'Use AI to help me analyze my phone calls and improve my team\'s performance...',
    color: 'cyan'
  },
  {
    id: '340',
    name: 'Talkdesk AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Talkdesk contact center platform.',
    url: 'https://www.talkdesk.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=talkdesk',
    suggested_prompt: 'Use AI to help me manage my contact center and improve my customer experience...',
    color: 'purple'
  },
  {
    id: '341',
    name: 'Genesys AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Genesys platform.',
    url: 'https://www.genesys.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=genesys',
    suggested_prompt: 'Use AI to help me manage my customer journeys and improve my support...',
    color: 'cyan'
  },
  {
    id: '342',
    name: 'Five9 AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Five9 cloud contact center platform.',
    url: 'https://www.five9.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=five9',
    suggested_prompt: 'Use AI to help me manage my contact center and improve agent productivity...',
    color: 'purple'
  },
  {
    id: '343',
    name: 'Nice InContact AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Nice InContact platform.',
    url: 'https://www.niceincontact.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=niceincontact',
    suggested_prompt: 'Use AI to help me manage my contact center and improve my customer experience...',
    color: 'cyan'
  },
  {
    id: '344',
    name: 'RingCentral AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the RingCentral platform.',
    url: 'https://www.ringcentral.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ringcentral',
    suggested_prompt: 'Use AI to help me manage my communications and improve my team\'s productivity...',
    color: 'purple'
  },
  {
    id: '345',
    name: '8x8 AI',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the 8x8 platform.',
    url: 'https://www.8x8.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=8x8',
    suggested_prompt: 'Use AI to help me manage my communications and gain insights into my data...',
    color: 'cyan'
  },
  {
    id: '346',
    name: 'Zendesk Answer Bot',
    category: 'Customer Support',
    description: 'AI-powered bot that provides instant answers to customer questions.',
    url: 'https://www.zendesk.com/answer-bot',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zendeskanswerbot',
    suggested_prompt: 'Use AI to help me provide instant answers to my customers\' questions...',
    color: 'purple'
  },
  {
    id: '347',
    name: 'Intercom Resolution Bot',
    category: 'Customer Support',
    description: 'AI-powered bot that resolves common customer questions.',
    url: 'https://www.intercom.com/resolution-bot',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=intercomresolutionbot',
    suggested_prompt: 'Use AI to help me resolve common customer questions automatically...',
    color: 'cyan'
  },
  {
    id: '348',
    name: 'Drift Custom Bots',
    category: 'Marketing',
    description: 'AI-powered bots that engage with website visitors and generate leads.',
    url: 'https://www.drift.com/custom-bots',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=driftcustombots',
    suggested_prompt: 'Use AI to help me engage with my website visitors and generate more leads...',
    color: 'purple'
  },
  {
    id: '349',
    name: 'Qualified Chatbots',
    category: 'Marketing',
    description: 'AI-powered chatbots that engage with target accounts and generate pipeline.',
    url: 'https://www.qualified.com/chatbots',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=qualifiedchatbots',
    suggested_prompt: 'Use AI to help me engage with my target accounts and generate more pipeline...',
    color: 'cyan'
  },
  {
    id: '350',
    name: 'Ada Glass',
    category: 'Customer Support',
    description: 'AI-powered features integrated into the Ada platform for personalized support.',
    url: 'https://www.ada.support/glass',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=adaglass',
    suggested_prompt: 'Use AI to help me provide a personalized experience for my customers...',
    color: 'purple'
  },
  {
    id: '351',
    name: 'Palo Alto Networks AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Palo Alto Networks platform.',
    url: 'https://www.paloaltonetworks.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=paloalto',
    suggested_prompt: 'Use AI to help me protect my network and detect threats in real-time...',
    color: 'cyan'
  },
  {
    id: '352',
    name: 'CrowdStrike AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the CrowdStrike Falcon platform.',
    url: 'https://www.crowdstrike.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=crowdstrike',
    suggested_prompt: 'Use AI to help me detect and prevent endpoint attacks...',
    color: 'purple'
  },
  {
    id: '353',
    name: 'SentinelOne AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the SentinelOne platform.',
    url: 'https://www.sentinelone.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sentinelone',
    suggested_prompt: 'Use AI to help me automate my threat detection and response...',
    color: 'cyan'
  },
  {
    id: '354',
    name: 'Darktrace',
    category: 'Security',
    description: 'AI-powered cyber defense platform that uses self-learning AI.',
    url: 'https://www.darktrace.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=darktrace',
    suggested_prompt: 'Use AI to help me detect and respond to novel cyber threats...',
    color: 'purple'
  },
  {
    id: '355',
    name: 'Vectra AI',
    category: 'Security',
    description: 'AI-powered threat detection and response platform for hybrid clouds.',
    url: 'https://www.vectra.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=vectraai',
    suggested_prompt: 'Use AI to help me detect and respond to attacks across my cloud and network...',
    color: 'cyan'
  },
  {
    id: '356',
    name: 'ExtraHop',
    category: 'Security',
    description: 'AI-powered network detection and response platform.',
    url: 'https://www.extrahop.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=extrahop',
    suggested_prompt: 'Use AI to help me gain visibility into my network and detect threats...',
    color: 'purple'
  },
  {
    id: '357',
    name: 'Cybereason',
    category: 'Security',
    description: 'AI-powered endpoint protection and response platform.',
    url: 'https://www.cybereason.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cybereason',
    suggested_prompt: 'Use AI to help me detect and prevent complex cyber attacks...',
    color: 'cyan'
  },
  {
    id: '358',
    name: 'FireEye AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the FireEye platform.',
    url: 'https://www.fireeye.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fireeye',
    suggested_prompt: 'Use AI to help me detect and respond to advanced cyber threats...',
    color: 'purple'
  },
  {
    id: '359',
    name: 'McAfee AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the McAfee platform.',
    url: 'https://www.mcafee.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mcafee',
    suggested_prompt: 'Use AI to help me protect my devices and data from cyber threats...',
    color: 'cyan'
  },
  {
    id: '360',
    name: 'Symantec AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Symantec platform.',
    url: 'https://www.broadcom.com/products/cybersecurity/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=symantec',
    suggested_prompt: 'Use AI to help me protect my organization from cyber attacks...',
    color: 'purple'
  },
  {
    id: '361',
    name: 'Trend Micro AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Trend Micro platform.',
    url: 'https://www.trendmicro.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=trendmicro',
    suggested_prompt: 'Use AI to help me detect and prevent cyber threats across my environment...',
    color: 'cyan'
  },
  {
    id: '362',
    name: 'Fortinet AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Fortinet Security Fabric.',
    url: 'https://www.fortinet.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fortinet',
    suggested_prompt: 'Use AI to help me protect my network and automate my security operations...',
    color: 'purple'
  },
  {
    id: '363',
    name: 'Check Point AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Check Point Infinity platform.',
    url: 'https://www.checkpoint.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=checkpoint',
    suggested_prompt: 'Use AI to help me protect my organization from advanced cyber threats...',
    color: 'cyan'
  },
  {
    id: '364',
    name: 'Cisco AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Cisco security portfolio.',
    url: 'https://www.cisco.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cisco',
    suggested_prompt: 'Use AI to help me protect my network and detect threats in real-time...',
    color: 'purple'
  },
  {
    id: '365',
    name: 'Akamai AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Akamai platform.',
    url: 'https://www.akamai.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=akamai',
    suggested_prompt: 'Use AI to help me protect my website and applications from cyber attacks...',
    color: 'cyan'
  },
  {
    id: '366',
    name: 'Cloudflare AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Cloudflare platform.',
    url: 'https://www.cloudflare.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cloudflare',
    suggested_prompt: 'Use AI to help me protect my website and improve its performance...',
    color: 'purple'
  },
  {
    id: '367',
    name: 'Atlassian Intelligence',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Atlassian platform (Jira, Confluence).',
    url: 'https://www.atlassian.com/intelligence',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=atlassian',
    suggested_prompt: 'Use AI to help me manage my projects and collaborate with my team...',
    color: 'cyan'
  },
  {
    id: '368',
    name: 'GitHub Copilot',
    category: 'Coding',
    description: 'AI-powered code completion and assistance tool.',
    url: 'https://github.com/features/copilot',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=githubcopilot',
    suggested_prompt: 'Use AI to help me write code faster and with fewer errors...',
    color: 'purple'
  },
  {
    id: '369',
    name: 'AWS AI Services',
    category: 'DevOps',
    description: 'AI-powered services integrated into the Amazon Web Services platform.',
    url: 'https://aws.amazon.com/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=aws',
    suggested_prompt: 'Use AI to help me build and deploy intelligent applications on AWS...',
    color: 'cyan'
  },
  {
    id: '370',
    name: 'Azure AI Services',
    category: 'DevOps',
    description: 'AI-powered services integrated into the Microsoft Azure platform.',
    url: 'https://azure.microsoft.com/en-us/services/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=azureai',
    suggested_prompt: 'Use AI to help me build and deploy intelligent applications on Azure...',
    color: 'purple'
  },
  {
    id: '371',
    name: 'Google Cloud AI',
    category: 'DevOps',
    description: 'AI-powered services integrated into the Google Cloud platform.',
    url: 'https://cloud.google.com/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=googlecloudai',
    suggested_prompt: 'Use AI to help me build and deploy intelligent applications on Google Cloud...',
    color: 'cyan'
  },
  {
    id: '372',
    name: 'IBM Cloud AI',
    category: 'DevOps',
    description: 'AI-powered services integrated into the IBM Cloud platform.',
    url: 'https://www.ibm.com/cloud/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ibmcloudai',
    suggested_prompt: 'Use AI to help me build and deploy intelligent applications on IBM Cloud...',
    color: 'purple'
  },
  {
    id: '373',
    name: 'Oracle Cloud AI',
    category: 'DevOps',
    description: 'AI-powered services integrated into the Oracle Cloud platform.',
    url: 'https://www.oracle.com/cloud/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=oraclecloudai',
    suggested_prompt: 'Use AI to help me build and deploy intelligent applications on Oracle Cloud...',
    color: 'cyan'
  },
  {
    id: '374',
    name: 'DigitalOcean AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the DigitalOcean platform.',
    url: 'https://www.digitalocean.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=digitalocean',
    suggested_prompt: 'Use AI to help me manage my cloud infrastructure and deploy my apps...',
    color: 'purple'
  },
  {
    id: '375',
    name: 'Heroku AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Heroku platform.',
    url: 'https://www.heroku.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=heroku',
    suggested_prompt: 'Use AI to help me deploy and manage my applications on Heroku...',
    color: 'cyan'
  },
  {
    id: '376',
    name: 'Netlify AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Netlify platform.',
    url: 'https://www.netlify.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=netlify',
    suggested_prompt: 'Use AI to help me build and deploy my websites on Netlify...',
    color: 'purple'
  },
  {
    id: '377',
    name: 'Vercel AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Vercel platform.',
    url: 'https://vercel.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=vercel',
    suggested_prompt: 'Use AI to help me build and deploy my web applications on Vercel...',
    color: 'cyan'
  },
  {
    id: '378',
    name: 'Render AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Render platform.',
    url: 'https://render.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=render',
    suggested_prompt: 'Use AI to help me deploy and manage my applications on Render...',
    color: 'purple'
  },
  {
    id: '379',
    name: 'Fly.io AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Fly.io platform.',
    url: 'https://fly.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=flyio',
    suggested_prompt: 'Use AI to help me deploy and manage my applications on Fly.io...',
    color: 'cyan'
  },
  {
    id: '380',
    name: 'Railway AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Railway platform.',
    url: 'https://railway.app/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=railway',
    suggested_prompt: 'Use AI to help me deploy and manage my applications on Railway...',
    color: 'purple'
  },
  {
    id: '381',
    name: 'Supabase AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Supabase platform.',
    url: 'https://supabase.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=supabase',
    suggested_prompt: 'Use AI to help me build and manage my backend on Supabase...',
    color: 'cyan'
  },
  {
    id: '382',
    name: 'Appwrite AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Appwrite platform.',
    url: 'https://appwrite.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=appwrite',
    suggested_prompt: 'Use AI to help me build and manage my backend on Appwrite...',
    color: 'purple'
  },
  {
    id: '383',
    name: 'Postman AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the Postman API platform.',
    url: 'https://www.postman.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=postman',
    suggested_prompt: 'Use AI to help me test and manage my APIs on Postman...',
    color: 'cyan'
  },
  {
    id: '384',
    name: 'Insomnia AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the Insomnia API platform.',
    url: 'https://insomnia.rest/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=insomnia',
    suggested_prompt: 'Use AI to help me test and manage my APIs on Insomnia...',
    color: 'purple'
  },
  {
    id: '385',
    name: 'Swagger AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the Swagger API platform.',
    url: 'https://swagger.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=swagger',
    suggested_prompt: 'Use AI to help me design and document my APIs on Swagger...',
    color: 'cyan'
  },
  {
    id: '386',
    name: 'Stoplight AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the Stoplight API platform.',
    url: 'https://stoplight.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=stoplight',
    suggested_prompt: 'Use AI to help me design and document my APIs on Stoplight...',
    color: 'purple'
  },
  {
    id: '387',
    name: 'RapidAPI AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the RapidAPI platform.',
    url: 'https://rapidapi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rapidapi',
    suggested_prompt: 'Use AI to help me find and manage my APIs on RapidAPI...',
    color: 'cyan'
  },
  {
    id: '388',
    name: 'Apigee AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the Google Cloud Apigee platform.',
    url: 'https://cloud.google.com/apigee/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=apigee',
    suggested_prompt: 'Use AI to help me manage my APIs on Apigee...',
    color: 'purple'
  },
  {
    id: '389',
    name: 'MuleSoft AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the MuleSoft Anypoint platform.',
    url: 'https://www.mulesoft.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mulesoft',
    suggested_prompt: 'Use AI to help me integrate my applications and manage my APIs on MuleSoft...',
    color: 'cyan'
  },
  {
    id: '390',
    name: 'Kong AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the Kong API gateway platform.',
    url: 'https://konghq.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kong',
    suggested_prompt: 'Use AI to help me manage my APIs on Kong...',
    color: 'purple'
  },
  {
    id: '391',
    name: 'Tyk AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the Tyk API gateway platform.',
    url: 'https://tyk.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tyk',
    suggested_prompt: 'Use AI to help me manage my APIs on Tyk...',
    color: 'cyan'
  },
  {
    id: '392',
    name: 'Gravitee AI',
    category: 'Coding',
    description: 'AI-powered features integrated into the Gravitee API management platform.',
    url: 'https://www.gravitee.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gravitee',
    suggested_prompt: 'Use AI to help me manage my APIs on Gravitee...',
    color: 'purple'
  },
  {
    id: '393',
    name: 'Wib AI',
    category: 'Security',
    description: 'AI-powered API security platform.',
    url: 'https://www.wib.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wib',
    suggested_prompt: 'Use AI to help me protect my APIs from cyber attacks...',
    color: 'cyan'
  },
  {
    id: '394',
    name: 'Salt Security AI',
    category: 'Security',
    description: 'AI-powered API security platform.',
    url: 'https://salt.security',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=saltsecurity',
    suggested_prompt: 'Use AI to help me protect my APIs and detect threats in real-time...',
    color: 'purple'
  },
  {
    id: '395',
    name: 'Noname Security AI',
    category: 'Security',
    description: 'AI-powered API security platform.',
    url: 'https://nonamesecurity.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nonamesecurity',
    suggested_prompt: 'Use AI to help me protect my APIs and gain visibility into my API landscape...',
    color: 'cyan'
  },
  {
    id: '396',
    name: 'Traceable AI',
    category: 'Security',
    description: 'AI-powered API security platform.',
    url: 'https://www.traceable.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=traceableai',
    suggested_prompt: 'Use AI to help me protect my APIs and detect threats across my environment...',
    color: 'purple'
  },
  {
    id: '397',
    name: 'Cequence Security AI',
    category: 'Security',
    description: 'AI-powered API security platform.',
    url: 'https://www.cequence.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cequence',
    suggested_prompt: 'Use AI to help me protect my APIs and prevent bot attacks...',
    color: 'cyan'
  },
  {
    id: '398',
    name: 'Imperva AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Imperva platform.',
    url: 'https://www.imperva.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=imperva',
    suggested_prompt: 'Use AI to help me protect my website and applications from cyber attacks...',
    color: 'purple'
  },
  {
    id: '399',
    name: 'F5 AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the F5 platform.',
    url: 'https://www.f5.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=f5',
    suggested_prompt: 'Use AI to help me protect my applications and manage my traffic...',
    color: 'cyan'
  },
  {
    id: '400',
    name: 'Radware AI',
    category: 'Security',
    description: 'AI-powered security features integrated into the Radware platform.',
    url: 'https://www.radware.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=radware',
    suggested_prompt: 'Use AI to help me protect my network and applications from cyber attacks...',
    color: 'purple'
  },
  {
    id: '401',
    name: 'Alteryx AiDIN',
    category: 'Data Science',
    description: 'AI-powered engine integrated into the Alteryx analytics platform.',
    url: 'https://www.alteryx.com/aidin',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=alteryx',
    suggested_prompt: 'Use AI to help me automate my data analytics and gain insights faster...',
    color: 'cyan'
  },
  {
    id: '402',
    name: 'DataRobot AI',
    category: 'Data Science',
    description: 'AI-powered platform for building and deploying machine learning models.',
    url: 'https://www.datarobot.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=datarobot',
    suggested_prompt: 'Use AI to help me build and deploy high-quality machine learning models...',
    color: 'purple'
  },
  {
    id: '403',
    name: 'H2O.ai',
    category: 'Data Science',
    description: 'AI-powered platform for automated machine learning.',
    url: 'https://h2o.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=h2oai',
    suggested_prompt: 'Use AI to help me automate my machine learning workflows and build better models...',
    color: 'cyan'
  },
  {
    id: '404',
    name: 'RapidMiner AI',
    category: 'Data Science',
    description: 'AI-powered data science platform for teams.',
    url: 'https://rapidminer.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rapidminer',
    suggested_prompt: 'Use AI to help me manage my data science projects and collaborate with my team...',
    color: 'purple'
  },
  {
    id: '405',
    name: 'KNIME AI',
    category: 'Data Science',
    description: 'AI-powered open-source data science platform.',
    url: 'https://www.knime.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=knime',
    suggested_prompt: 'Use AI to help me build and deploy data science workflows using open-source tools...',
    color: 'cyan'
  },
  {
    id: '406',
    name: 'TIBCO AI',
    category: 'Data Science',
    description: 'AI-powered features integrated into the TIBCO analytics platform.',
    url: 'https://www.tibco.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tibco',
    suggested_prompt: 'Use AI to help me gain insights into my data and improve my business decisions...',
    color: 'purple'
  },
  {
    id: '407',
    name: 'SAS Viya AI',
    category: 'Data Science',
    description: 'AI-powered analytics platform for enterprises.',
    url: 'https://www.sas.com/en_us/software/viya.html',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sas',
    suggested_prompt: 'Use AI to help me manage my enterprise analytics and gain insights into my data...',
    color: 'cyan'
  },
  {
    id: '408',
    name: 'Teradata AI',
    category: 'Data Science',
    description: 'AI-powered features integrated into the Teradata data platform.',
    url: 'https://www.teradata.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=teradata',
    suggested_prompt: 'Use AI to help me manage my large-scale data and gain insights into my business...',
    color: 'purple'
  },
  {
    id: '409',
    name: 'Cloudera AI',
    category: 'Data Science',
    description: 'AI-powered features integrated into the Cloudera data platform.',
    url: 'https://www.cloudera.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cloudera',
    suggested_prompt: 'Use AI to help me manage my data across hybrid and multi-cloud environments...',
    color: 'cyan'
  },
  {
    id: '410',
    name: 'Databricks AI',
    category: 'Data Science',
    description: 'AI-powered platform for data engineering, data science, and analytics.',
    url: 'https://www.databricks.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=databricks',
    suggested_prompt: 'Use AI to help me build and manage my data lakehouse on Databricks...',
    color: 'purple'
  },
  {
    id: '411',
    name: 'Snowflake AI',
    category: 'Data Science',
    description: 'AI-powered features integrated into the Snowflake data cloud platform.',
    url: 'https://www.snowflake.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=snowflake',
    suggested_prompt: 'Use AI to help me manage my data in the cloud and gain insights into my business...',
    color: 'cyan'
  },
  {
    id: '412',
    name: 'MongoDB Atlas AI',
    category: 'Data Science',
    description: 'AI-powered features integrated into the MongoDB Atlas cloud database platform.',
    url: 'https://www.mongodb.com/atlas/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mongodb',
    suggested_prompt: 'Use AI to help me build and manage my intelligent applications on MongoDB...',
    color: 'purple'
  },
  {
    id: '413',
    name: 'Redis AI',
    category: 'Data Science',
    description: 'AI-powered module for Redis that allows for real-time model serving.',
    url: 'https://redis.io/modules/redisai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=redis',
    suggested_prompt: 'Use AI to help me serve my machine learning models in real-time on Redis...',
    color: 'cyan'
  },
  {
    id: '414',
    name: 'Elastic AI',
    category: 'Data Science',
    description: 'AI-powered features integrated into the Elastic search and analytics platform.',
    url: 'https://www.elastic.co/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=elastic',
    suggested_prompt: 'Use AI to help me search and analyze my data across my environment...',
    color: 'purple'
  },
  {
    id: '415',
    name: 'Splunk AI',
    category: 'Data Science',
    description: 'AI-powered features integrated into the Splunk observability and security platform.',
    url: 'https://www.splunk.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=splunk',
    suggested_prompt: 'Use AI to help me gain visibility into my data and detect threats in real-time...',
    color: 'cyan'
  },
  {
    id: '416',
    name: 'New Relic AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the New Relic observability platform.',
    url: 'https://newrelic.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=newrelic',
    suggested_prompt: 'Use AI to help me monitor my applications and improve their performance...',
    color: 'purple'
  },
  {
    id: '417',
    name: 'Datadog AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the Datadog monitoring and security platform.',
    url: 'https://www.datadoghq.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=datadog',
    suggested_prompt: 'Use AI to help me monitor my infrastructure and detect threats in real-time...',
    color: 'cyan'
  },
  {
    id: '418',
    name: 'Dynatrace AI',
    category: 'DevOps',
    description: 'AI-powered observability and security platform for enterprises.',
    url: 'https://www.dynatrace.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=dynatrace',
    suggested_prompt: 'Use AI to help me monitor my enterprise applications and automate my operations...',
    color: 'purple'
  },
  {
    id: '419',
    name: 'AppDynamics AI',
    category: 'DevOps',
    description: 'AI-powered application performance monitoring platform.',
    url: 'https://www.appdynamics.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=appdynamics',
    suggested_prompt: 'Use AI to help me monitor my applications and improve their performance...',
    color: 'cyan'
  },
  {
    id: '420',
    name: 'SolarWinds AI',
    category: 'DevOps',
    description: 'AI-powered features integrated into the SolarWinds IT management platform.',
    url: 'https://www.solarwinds.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=solarwinds',
    suggested_prompt: 'Use AI to help me manage my IT infrastructure and improve my operations...',
    color: 'purple'
  },
  {
    id: '421',
    name: 'Kensho AI',
    category: 'Finance',
    description: 'AI-powered analytics platform for the financial industry.',
    url: 'https://www.kensho.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kensho',
    suggested_prompt: 'Use AI to help me gain insights into financial data and improve my investment decisions...',
    color: 'cyan'
  },
  {
    id: '422',
    name: 'AlphaSense AI',
    category: 'Finance',
    description: 'AI-powered market intelligence platform for financial professionals.',
    url: 'https://www.alpha-sense.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=alphasense',
    suggested_prompt: 'Use AI to help me find and analyze market information faster...',
    color: 'purple'
  },
  {
    id: '423',
    name: 'Sentieo AI',
    category: 'Finance',
    description: 'AI-powered financial research platform for investment teams.',
    url: 'https://sentieo.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sentieo',
    suggested_prompt: 'Use AI to help me manage my financial research and collaborate with my team...',
    color: 'cyan'
  },
  {
    id: '424',
    name: 'Kavout AI',
    category: 'Finance',
    description: 'AI-powered investment platform that uses machine learning for stock picking.',
    url: 'https://www.kavout.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kavout',
    suggested_prompt: 'Use AI to help me identify top-performing stocks and improve my investment returns...',
    color: 'purple'
  },
  {
    id: '425',
    name: 'Numerai',
    category: 'Finance',
    description: 'AI-powered hedge fund that uses a crowdsourced machine learning model.',
    url: 'https://numer.ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=numerai',
    suggested_prompt: 'Use AI to help me contribute to a crowdsourced machine learning model for a hedge fund...',
    color: 'cyan'
  },
  {
    id: '426',
    name: 'WorldQuant AI',
    category: 'Finance',
    description: 'AI-powered quantitative investment management firm.',
    url: 'https://www.worldquant.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=worldquant',
    suggested_prompt: 'Use AI to help me build and manage quantitative investment strategies...',
    color: 'purple'
  },
  {
    id: '427',
    name: 'Two Sigma AI',
    category: 'Finance',
    description: 'AI-powered quantitative investment management firm.',
    url: 'https://www.twosigma.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=twosigma',
    suggested_prompt: 'Use AI to help me build and manage quantitative investment strategies...',
    color: 'cyan'
  },
  {
    id: '428',
    name: 'Renaissance Technologies AI',
    category: 'Finance',
    description: 'AI-powered quantitative investment management firm.',
    url: 'https://www.rentech.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=renaissance',
    suggested_prompt: 'Use AI to help me build and manage quantitative investment strategies...',
    color: 'purple'
  },
  {
    id: '429',
    name: 'Bridgewater Associates AI',
    category: 'Finance',
    description: 'AI-powered investment management firm.',
    url: 'https://www.bridgewater.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bridgewater',
    suggested_prompt: 'Use AI to help me manage my investments and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '430',
    name: 'Goldman Sachs AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Goldman Sachs financial platform.',
    url: 'https://www.goldmansachs.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=goldmansachs',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '431',
    name: 'Morgan Stanley AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Morgan Stanley financial platform.',
    url: 'https://www.morganstanley.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=morganstanley',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '432',
    name: 'JPMorgan Chase AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the JPMorgan Chase financial platform.',
    url: 'https://www.jpmorganchase.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=jpmorgan',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '433',
    name: 'Bank of America AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Bank of America financial platform.',
    url: 'https://www.bankofamerica.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bankofamerica',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '434',
    name: 'Citigroup AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Citigroup financial platform.',
    url: 'https://www.citigroup.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=citigroup',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '435',
    name: 'Wells Fargo AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Wells Fargo financial platform.',
    url: 'https://www.wellsfargo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wellsfargo',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '436',
    name: 'HSBC AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the HSBC financial platform.',
    url: 'https://www.hsbc.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hsbc',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '437',
    name: 'Barclays AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Barclays financial platform.',
    url: 'https://www.barclays.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=barclays',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '438',
    name: 'UBS AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the UBS financial platform.',
    url: 'https://www.ubs.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ubs',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '439',
    name: 'Credit Suisse AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Credit Suisse financial platform.',
    url: 'https://www.credit-suisse.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=creditsuisse',
    suggested_prompt: 'Use AI to help me manage my finances and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '440',
    name: 'BlackRock AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the BlackRock investment platform.',
    url: 'https://www.blackrock.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=blackrock',
    suggested_prompt: 'Use AI to help me manage my investments and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '441',
    name: 'Vanguard AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Vanguard investment platform.',
    url: 'https://www.vanguard.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=vanguard',
    suggested_prompt: 'Use AI to help me manage my investments and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '442',
    name: 'Fidelity AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Fidelity investment platform.',
    url: 'https://www.fidelity.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fidelity',
    suggested_prompt: 'Use AI to help me manage my investments and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '443',
    name: 'Schwab AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Charles Schwab investment platform.',
    url: 'https://www.schwab.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=schwab',
    suggested_prompt: 'Use AI to help me manage my investments and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '444',
    name: 'TD Ameritrade AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the TD Ameritrade investment platform.',
    url: 'https://www.tdameritrade.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tdameritrade',
    suggested_prompt: 'Use AI to help me manage my investments and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '445',
    name: 'E*TRADE AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the E*TRADE investment platform.',
    url: 'https://us.etrade.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=etrade',
    suggested_prompt: 'Use AI to help me manage my investments and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '446',
    name: 'Robinhood AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Robinhood investment platform.',
    url: 'https://robinhood.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=robinhood',
    suggested_prompt: 'Use AI to help me manage my investments and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '447',
    name: 'Coinbase AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Coinbase cryptocurrency platform.',
    url: 'https://www.coinbase.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=coinbase',
    suggested_prompt: 'Use AI to help me manage my cryptocurrency investments and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '448',
    name: 'Binance AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Binance cryptocurrency platform.',
    url: 'https://www.binance.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=binance',
    suggested_prompt: 'Use AI to help me manage my cryptocurrency investments and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '449',
    name: 'Kraken AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Kraken cryptocurrency platform.',
    url: 'https://www.kraken.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kraken',
    suggested_prompt: 'Use AI to help me manage my cryptocurrency investments and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '450',
    name: 'Gemini AI (Exchange)',
    category: 'Finance',
    description: 'AI-powered features integrated into the Gemini cryptocurrency exchange platform.',
    url: 'https://www.gemini.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=geminiexchange',
    suggested_prompt: 'Use AI to help me manage my cryptocurrency investments and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '451',
    name: 'Casetext CoCounsel',
    category: 'Legal',
    description: 'AI-powered legal assistant that can review documents and research law.',
    url: 'https://casetext.com/cocounsel',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=casetext',
    suggested_prompt: 'Use AI to help me research legal cases and review my documents...',
    color: 'cyan'
  },
  {
    id: '452',
    name: 'Everlaw AI',
    category: 'Legal',
    description: 'AI-powered e-discovery platform for legal teams.',
    url: 'https://www.everlaw.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=everlaw',
    suggested_prompt: 'Use AI to help me manage my e-discovery process and find key evidence...',
    color: 'purple'
  },
  {
    id: '453',
    name: 'DISCO AI',
    category: 'Legal',
    description: 'AI-powered legal technology platform for e-discovery and document review.',
    url: 'https://www.csdisco.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=disco',
    suggested_prompt: 'Use AI to help me review legal documents and manage my cases...',
    color: 'cyan'
  },
  {
    id: '454',
    name: 'Relativity aiR',
    category: 'Legal',
    description: 'AI-powered features integrated into the Relativity e-discovery platform.',
    url: 'https://www.relativity.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=relativity',
    suggested_prompt: 'Use AI to help me manage my e-discovery process and gain insights into my data...',
    color: 'purple'
  },
  {
    id: '455',
    name: 'Lexis+ AI',
    category: 'Legal',
    description: 'AI-powered legal research and drafting platform from LexisNexis.',
    url: 'https://www.lexisnexis.com/en-us/products/lexis-plus-ai.page',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lexisnexis',
    suggested_prompt: 'Use AI to help me research the law and draft legal documents...',
    color: 'cyan'
  },
  {
    id: '456',
    name: 'Westlaw Precision AI',
    category: 'Legal',
    description: 'AI-powered legal research platform from Thomson Reuters.',
    url: 'https://legal.thomsonreuters.com/en/products/westlaw/precision-ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=westlaw',
    suggested_prompt: 'Use AI to help me find relevant legal cases and research the law...',
    color: 'purple'
  },
  {
    id: '457',
    name: 'Bloomberg Law AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Bloomberg Law platform.',
    url: 'https://pro.bloomberglaw.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bloomberglaw',
    suggested_prompt: 'Use AI to help me research the law and gain insights into the legal market...',
    color: 'cyan'
  },
  {
    id: '458',
    name: 'Kira Systems AI',
    category: 'Legal',
    description: 'AI-powered contract analysis and review software.',
    url: 'https://kirasystems.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kirasystems',
    suggested_prompt: 'Use AI to help me analyze my contracts and identify key terms...',
    color: 'purple'
  },
  {
    id: '459',
    name: 'Luminance AI',
    category: 'Legal',
    description: 'AI-powered document review and analysis platform for legal teams.',
    url: 'https://www.luminance.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=luminance',
    suggested_prompt: 'Use AI to help me review my legal documents and manage my contracts...',
    color: 'cyan'
  },
  {
    id: '460',
    name: 'LawGeex AI',
    category: 'Legal',
    description: 'AI-powered contract review automation platform.',
    url: 'https://www.lawgeex.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lawgeex',
    suggested_prompt: 'Use AI to help me automate my contract review process...',
    color: 'purple'
  },
  {
    id: '461',
    name: 'Ironclad AI',
    category: 'Legal',
    description: 'AI-powered contract lifecycle management platform.',
    url: 'https://ironcladapp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ironclad',
    suggested_prompt: 'Use AI to help me manage my contracts and automate my legal workflows...',
    color: 'cyan'
  },
  {
    id: '462',
    name: 'LinkSquares AI',
    category: 'Legal',
    description: 'AI-powered contract management and analysis platform.',
    url: 'https://linksquares.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=linksquares',
    suggested_prompt: 'Use AI to help me manage my contracts and gain insights into my legal data...',
    color: 'purple'
  },
  {
    id: '463',
    name: 'Evisort AI',
    category: 'Legal',
    description: 'AI-powered contract management and analysis platform.',
    url: 'https://www.evisort.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=evisort',
    suggested_prompt: 'Use AI to help me manage my contracts and automate my legal tasks...',
    color: 'cyan'
  },
  {
    id: '464',
    name: 'ContractPodAi',
    category: 'Legal',
    description: 'AI-powered contract lifecycle management platform.',
    url: 'https://contractpodai.com',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=contractpodai',
    suggested_prompt: 'Use AI to help me manage my contracts and improve my legal operations...',
    color: 'purple'
  },
  {
    id: '465',
    name: 'SirionLabs AI',
    category: 'Legal',
    description: 'AI-powered contract lifecycle management platform.',
    url: 'https://www.sirionlabs.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sirionlabs',
    suggested_prompt: 'Use AI to help me manage my contracts and improve my business relationships...',
    color: 'cyan'
  },
  {
    id: '466',
    name: 'Icertis AI',
    category: 'Legal',
    description: 'AI-powered contract intelligence platform for enterprises.',
    url: 'https://www.icertis.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=icertis',
    suggested_prompt: 'Use AI to help me manage my enterprise contracts and gain insights into my data...',
    color: 'purple'
  },
  {
    id: '467',
    name: 'Conga AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Conga revenue lifecycle management platform.',
    url: 'https://conga.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=conga',
    suggested_prompt: 'Use AI to help me manage my contracts and improve my revenue operations...',
    color: 'cyan'
  },
  {
    id: '468',
    name: 'DocuSign AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the DocuSign agreement cloud platform.',
    url: 'https://www.docusign.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=docusign',
    suggested_prompt: 'Use AI to help me manage my agreements and automate my signing process...',
    color: 'purple'
  },
  {
    id: '469',
    name: 'Adobe Acrobat AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into Adobe Acrobat for document management.',
    url: 'https://www.adobe.com/acrobat/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=adobeacrobat',
    suggested_prompt: 'Use AI to help me manage my PDF documents and gain insights into my data...',
    color: 'cyan'
  },
  {
    id: '470',
    name: 'Nitro AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Nitro document productivity platform.',
    url: 'https://www.gonitro.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nitro',
    suggested_prompt: 'Use AI to help me manage my documents and improve my team\'s productivity...',
    color: 'purple'
  },
  {
    id: '471',
    name: 'Zillow AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Zillow real estate platform.',
    url: 'https://www.zillow.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zillow',
    suggested_prompt: 'Use AI to help me find the right home and gain insights into the real estate market...',
    color: 'cyan'
  },
  {
    id: '472',
    name: 'Redfin AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Redfin real estate platform.',
    url: 'https://www.redfin.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=redfin',
    suggested_prompt: 'Use AI to help me find the right home and save money on my real estate transactions...',
    color: 'purple'
  },
  {
    id: '473',
    name: 'Realtor.com AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Realtor.com real estate platform.',
    url: 'https://www.realtor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=realtor',
    suggested_prompt: 'Use AI to help me find the right home and gain insights into the real estate market...',
    color: 'cyan'
  },
  {
    id: '474',
    name: 'Compass AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Compass real estate platform.',
    url: 'https://www.compass.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=compass',
    suggested_prompt: 'Use AI to help me find the right home and manage my real estate business...',
    color: 'purple'
  },
  {
    id: '475',
    name: 'Opendoor AI',
    category: 'Real Estate',
    description: 'AI-powered platform for buying and selling homes.',
    url: 'https://www.opendoor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=opendoor',
    suggested_prompt: 'Use AI to help me sell my home quickly and easily...',
    color: 'cyan'
  },
  {
    id: '476',
    name: 'Offerpad AI',
    category: 'Real Estate',
    description: 'AI-powered platform for buying and selling homes.',
    url: 'https://www.offerpad.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=offerpad',
    suggested_prompt: 'Use AI to help me sell my home quickly and easily...',
    color: 'purple'
  },
  {
    id: '477',
    name: 'Roofstock AI',
    category: 'Real Estate',
    description: 'AI-powered platform for investing in single-family rental homes.',
    url: 'https://www.roofstock.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=roofstock',
    suggested_prompt: 'Use AI to help me find and invest in rental properties...',
    color: 'cyan'
  },
  {
    id: '478',
    name: 'AppFolio AI',
    category: 'Real Estate',
    description: 'AI-powered property management software.',
    url: 'https://www.appfolio.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=appfolio',
    suggested_prompt: 'Use AI to help me manage my rental properties and improve my operations...',
    color: 'purple'
  },
  {
    id: '479',
    name: 'Yardi AI',
    category: 'Real Estate',
    description: 'AI-powered property management software for enterprises.',
    url: 'https://www.yardi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=yardi',
    suggested_prompt: 'Use AI to help me manage my enterprise real estate portfolio...',
    color: 'cyan'
  },
  {
    id: '480',
    name: 'RealPage AI',
    category: 'Real Estate',
    description: 'AI-powered property management software and analytics.',
    url: 'https://www.realpage.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=realpage',
    suggested_prompt: 'Use AI to help me manage my rental properties and gain insights into my data...',
    color: 'purple'
  },
  {
    id: '481',
    name: 'Entrata AI',
    category: 'Real Estate',
    description: 'AI-powered property management software.',
    url: 'https://www.entrata.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=entrata',
    suggested_prompt: 'Use AI to help me manage my rental properties and improve my operations...',
    color: 'cyan'
  },
  {
    id: '482',
    name: 'Buildium AI',
    category: 'Real Estate',
    description: 'AI-powered property management software for small to mid-sized portfolios.',
    url: 'https://www.buildium.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=buildium',
    suggested_prompt: 'Use AI to help me manage my rental properties and improve my operations...',
    color: 'purple'
  },
  {
    id: '483',
    name: 'RentRedi AI',
    category: 'Real Estate',
    description: 'AI-powered property management software for landlords.',
    url: 'https://rentredi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rentredi',
    suggested_prompt: 'Use AI to help me manage my rental properties and improve my operations...',
    color: 'cyan'
  },
  {
    id: '484',
    name: 'Stessa AI',
    category: 'Real Estate',
    description: 'AI-powered financial management software for real estate investors.',
    url: 'https://www.stessa.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=stessa',
    suggested_prompt: 'Use AI to help me manage my real estate investments and gain insights into my data...',
    color: 'purple'
  },
  {
    id: '485',
    name: 'DealCheck AI',
    category: 'Real Estate',
    description: 'AI-powered investment property analysis software.',
    url: 'https://dealcheck.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=dealcheck',
    suggested_prompt: 'Use AI to help me analyze rental properties and identify the best deals...',
    color: 'cyan'
  },
  {
    id: '486',
    name: 'PropStream AI',
    category: 'Real Estate',
    description: 'AI-powered real estate data and lead generation platform.',
    url: 'https://www.propstream.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=propstream',
    suggested_prompt: 'Use AI to help me find real estate leads and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '487',
    name: 'BatchLeads AI',
    category: 'Real Estate',
    description: 'AI-powered real estate lead generation and marketing platform.',
    url: 'https://batchleads.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=batchleads',
    suggested_prompt: 'Use AI to help me find real estate leads and manage my marketing...',
    color: 'cyan'
  },
  {
    id: '488',
    name: 'Privy AI',
    category: 'Real Estate',
    description: 'AI-powered real estate investment software.',
    url: 'https://www.privy.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=privy',
    suggested_prompt: 'Use AI to help me find and analyze real estate deals...',
    color: 'purple'
  },
  {
    id: '489',
    name: 'Flipster AI',
    category: 'Real Estate',
    description: 'AI-powered real estate flipping software.',
    url: 'https://flipster.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=flipster',
    suggested_prompt: 'Use AI to help me find and flip houses for a profit...',
    color: 'cyan'
  },
  {
    id: '490',
    name: 'REIPro AI',
    category: 'Real Estate',
    description: 'AI-powered real estate investment software.',
    url: 'https://www.myreipro.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=reipro',
    suggested_prompt: 'Use AI to help me find and manage my real estate investments...',
    color: 'purple'
  },
  {
    id: '491',
    name: 'Zumper AI',
    category: 'Real Estate',
    description: 'AI-powered platform for finding rental homes.',
    url: 'https://www.zumper.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zumper',
    suggested_prompt: 'Use AI to help me find the right rental home and manage my applications...',
    color: 'cyan'
  },
  {
    id: '492',
    name: 'Apartments.com AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Apartments.com platform.',
    url: 'https://www.apartments.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=apartments',
    suggested_prompt: 'Use AI to help me find the right rental home and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '493',
    name: 'Rent.com AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Rent.com platform.',
    url: 'https://www.rent.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rent',
    suggested_prompt: 'Use AI to help me find the right rental home and manage my applications...',
    color: 'cyan'
  },
  {
    id: '494',
    name: 'HotPads AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the HotPads platform.',
    url: 'https://hotpads.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hotpads',
    suggested_prompt: 'Use AI to help me find the right rental home and gain insights into the market...',
    color: 'purple'
  },
  {
    id: '495',
    name: 'Trulia AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Trulia platform.',
    url: 'https://www.trulia.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=trulia',
    suggested_prompt: 'Use AI to help me find the right home and gain insights into the real estate market...',
    color: 'cyan'
  },
  {
    id: '496',
    name: 'Houzz AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Houzz platform for home design.',
    url: 'https://www.houzz.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=houzz',
    suggested_prompt: 'Use AI to help me design my home and find the right products...',
    color: 'purple'
  },
  {
    id: '497',
    name: 'Wayfair AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Wayfair platform for home shopping.',
    url: 'https://www.wayfair.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wayfair',
    suggested_prompt: 'Use AI to help me find the right products for my home and gain insights into my data...',
    color: 'cyan'
  },
  {
    id: '498',
    name: 'IKEA AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the IKEA platform for home design.',
    url: 'https://www.ikea.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ikea',
    suggested_prompt: 'Use AI to help me design my home and find the right products...',
    color: 'purple'
  },
  {
    id: '499',
    name: 'Home Depot AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Home Depot platform for home improvement.',
    url: 'https://www.homedepot.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=homedepot',
    suggested_prompt: 'Use AI to help me find the right products for my home improvement projects...',
    color: 'cyan'
  },
  {
    id: '500',
    name: 'Lowe\'s AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Lowe\'s platform for home improvement.',
    url: 'https://www.lowes.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lowes',
    suggested_prompt: 'Use AI to help me find the right products for my home improvement projects...',
    color: 'purple'
  },
  {
    id: '501',
    name: 'Babylon Health AI',
    category: 'Health',
    description: 'AI-powered health platform for remote consultations and symptom checking.',
    url: 'https://www.babylonhealth.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=babylon',
    suggested_prompt: 'Use AI to help me check my symptoms and manage my health...',
    color: 'cyan'
  },
  {
    id: '502',
    name: 'Ada Health AI',
    category: 'Health',
    description: 'AI-powered health assistant for symptom checking and health management.',
    url: 'https://ada.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=adahealth',
    suggested_prompt: 'Use AI to help me check my symptoms and gain insights into my health...',
    color: 'purple'
  },
  {
    id: '503',
    name: 'Buoy Health AI',
    category: 'Health',
    description: 'AI-powered health assistant for symptom checking and triage.',
    url: 'https://www.buoyhealth.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=buoy',
    suggested_prompt: 'Use AI to help me check my symptoms and find the right care...',
    color: 'cyan'
  },
  {
    id: '504',
    name: 'Your.MD AI',
    category: 'Health',
    description: 'AI-powered health assistant for personalized health information.',
    url: 'https://www.your.md/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=yourmd',
    suggested_prompt: 'Use AI to help me find personalized health information and manage my well-being...',
    color: 'purple'
  },
  {
    id: '505',
    name: 'Infermedica AI',
    category: 'Health',
    description: 'AI-powered platform for preliminary medical diagnosis and triage.',
    url: 'https://infermedica.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=infermedica',
    suggested_prompt: 'Use AI to help me build intelligent health applications and improve triage...',
    color: 'cyan'
  },
  {
    id: '506',
    name: 'K Health AI',
    category: 'Health',
    description: 'AI-powered health platform for remote consultations and personalized health insights.',
    url: 'https://khealth.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=khealth',
    suggested_prompt: 'Use AI to help me manage my health and gain insights into my data...',
    color: 'purple'
  },
  {
    id: '507',
    name: 'Curai Health AI',
    category: 'Health',
    description: 'AI-powered health platform for remote consultations and primary care.',
    url: 'https://www.curaihealth.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=curai',
    suggested_prompt: 'Use AI to help me manage my health and access primary care remotely...',
    color: 'cyan'
  },
  {
    id: '508',
    name: 'Forward Health AI',
    category: 'Health',
    description: 'AI-powered primary care platform that uses data and AI for personalized health.',
    url: 'https://goforward.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=forward',
    suggested_prompt: 'Use AI to help me manage my health and gain insights into my data...',
    color: 'purple'
  },
  {
    id: '509',
    name: 'One Medical AI',
    category: 'Health',
    description: 'AI-powered features integrated into the One Medical primary care platform.',
    url: 'https://www.onemedical.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=onemedical',
    suggested_prompt: 'Use AI to help me manage my health and access primary care easily...',
    color: 'cyan'
  },
  {
    id: '510',
    name: 'Teladoc AI',
    category: 'Health',
    description: 'AI-powered features integrated into the Teladoc remote consultation platform.',
    url: 'https://www.teladochealth.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=teladoc',
    suggested_prompt: 'Use AI to help me manage my health and access remote consultations...',
    color: 'purple'
  },
  {
    id: '511',
    name: 'Amwell AI',
    category: 'Health',
    description: 'AI-powered features integrated into the Amwell telehealth platform.',
    url: 'https://business.amwell.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=amwell',
    suggested_prompt: 'Use AI to help me manage my health and access telehealth services...',
    color: 'cyan'
  },
  {
    id: '512',
    name: 'Doctor On Demand AI',
    category: 'Health',
    description: 'AI-powered features integrated into the Doctor On Demand platform.',
    url: 'https://doctorondemand.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=doctorondemand',
    suggested_prompt: 'Use AI to help me manage my health and access remote consultations...',
    color: 'purple'
  },
  {
    id: '513',
    name: 'MDLIVE AI',
    category: 'Health',
    description: 'AI-powered features integrated into the MDLIVE telehealth platform.',
    url: 'https://www.mdlive.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mdlive',
    suggested_prompt: 'Use AI to help me manage my health and access telehealth services...',
    color: 'cyan'
  },
  {
    id: '514',
    name: 'PlushCare AI',
    category: 'Health',
    description: 'AI-powered features integrated into the PlushCare platform.',
    url: 'https://www.plushcare.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=plushcare',
    suggested_prompt: 'Use AI to help me manage my health and access remote consultations...',
    color: 'purple'
  },
  {
    id: '515',
    name: 'Zocdoc AI',
    category: 'Health',
    description: 'AI-powered features integrated into the Zocdoc platform for finding doctors.',
    url: 'https://www.zocdoc.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zocdoc',
    suggested_prompt: 'Use AI to help me find the right doctor and manage my appointments...',
    color: 'cyan'
  },
  {
    id: '516',
    name: 'HealthTap AI',
    category: 'Health',
    description: 'AI-powered features integrated into the HealthTap platform.',
    url: 'https://www.healthtap.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=healthtap',
    suggested_prompt: 'Use AI to help me manage my health and gain insights into my data...',
    color: 'purple'
  },
  {
    id: '517',
    name: 'Sharecare AI',
    category: 'Health',
    description: 'AI-powered features integrated into the Sharecare platform.',
    url: 'https://www.sharecare.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sharecare',
    suggested_prompt: 'Use AI to help me manage my health and improve my well-being...',
    color: 'cyan'
  },
  {
    id: '518',
    name: 'WebMD AI',
    category: 'Health',
    description: 'AI-powered features integrated into the WebMD platform.',
    url: 'https://www.webmd.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=webmd',
    suggested_prompt: 'Use AI to help me find health information and manage my well-being...',
    color: 'purple'
  },
  {
    id: '519',
    name: 'Mayo Clinic AI',
    category: 'Health',
    description: 'AI-powered features integrated into the Mayo Clinic platform.',
    url: 'https://www.mayoclinic.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mayoclinic',
    suggested_prompt: 'Use AI to help me find health information and manage my well-being...',
    color: 'cyan'
  },
  {
    id: '520',
    name: 'Cleveland Clinic AI',
    category: 'Health',
    description: 'AI-powered features integrated into the Cleveland Clinic platform.',
    url: 'https://my.clevelandclinic.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=clevelandclinic',
    suggested_prompt: 'Use AI to help me find health information and manage my well-being...',
    color: 'purple'
  },
  {
    id: '521',
    name: 'Unity Muse',
    category: 'Gaming',
    description: 'AI-powered features integrated into the Unity game engine.',
    url: 'https://unity.com/products/muse',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=unity',
    suggested_prompt: 'Use AI to help me build and deploy intelligent games on Unity...',
    color: 'cyan'
  },
  {
    id: '522',
    name: 'Unreal Engine AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into the Unreal Engine.',
    url: 'https://www.unrealengine.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=unrealengine',
    suggested_prompt: 'Use AI to help me build and deploy intelligent games on Unreal Engine...',
    color: 'purple'
  },
  {
    id: '523',
    name: 'Roblox AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into the Roblox platform.',
    url: 'https://create.roblox.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=roblox',
    suggested_prompt: 'Use AI to help me build and deploy intelligent games on Roblox...',
    color: 'cyan'
  },
  {
    id: '524',
    name: 'NVIDIA DLSS',
    category: 'Gaming',
    description: 'AI-powered super resolution technology for gaming.',
    url: 'https://www.nvidia.com/en-us/geforce/technologies/dlss',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nvidia',
    suggested_prompt: 'Use AI to help me improve my gaming performance and visual quality...',
    color: 'purple'
  },
  {
    id: '525',
    name: 'AMD FSR',
    category: 'Gaming',
    description: 'AI-powered super resolution technology for gaming.',
    url: 'https://www.amd.com/en/technologies/fidelityfx-super-resolution',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=amd',
    suggested_prompt: 'Use AI to help me improve my gaming performance and visual quality...',
    color: 'cyan'
  },
  {
    id: '526',
    name: 'Intel XeSS',
    category: 'Gaming',
    description: 'AI-powered super resolution technology for gaming.',
    url: 'https://www.intel.com/content/www/us/en/products/docs/discrete-gpus/xe-ss.html',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=intel',
    suggested_prompt: 'Use AI to help me improve my gaming performance and visual quality...',
    color: 'purple'
  },
  {
    id: '527',
    name: 'Sony AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Sony gaming platforms.',
    url: 'https://www.sony.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sony',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'cyan'
  },
  {
    id: '528',
    name: 'Microsoft AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Microsoft gaming platforms.',
    url: 'https://www.microsoft.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=microsoftgaming',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'purple'
  },
  {
    id: '529',
    name: 'Nintendo AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Nintendo gaming platforms.',
    url: 'https://www.nintendo.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nintendo',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'cyan'
  },
  {
    id: '530',
    name: 'EA AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into EA games.',
    url: 'https://www.ea.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ea',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'purple'
  },
  {
    id: '531',
    name: 'Ubisoft AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Ubisoft games.',
    url: 'https://www.ubisoft.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ubisoft',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'cyan'
  },
  {
    id: '532',
    name: 'Activision Blizzard AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into Activision Blizzard games.',
    url: 'https://www.activisionblizzard.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=activision',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'purple'
  },
  {
    id: '533',
    name: 'Take-Two AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Take-Two games.',
    url: 'https://www.take2games.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=taketwo',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'cyan'
  },
  {
    id: '534',
    name: 'Epic Games AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into Epic Games.',
    url: 'https://www.epicgames.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=epicgames',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'purple'
  },
  {
    id: '535',
    name: 'Valve AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Valve games.',
    url: 'https://www.valvesoftware.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=valve',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'cyan'
  },
  {
    id: '536',
    name: 'Riot Games AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into Riot Games.',
    url: 'https://www.riotgames.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=riotgames',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'purple'
  },
  {
    id: '537',
    name: 'Supercell AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Supercell games.',
    url: 'https://supercell.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=supercell',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'cyan'
  },
  {
    id: '538',
    name: 'King AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into King games.',
    url: 'https://www.king.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kinggaming',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'purple'
  },
  {
    id: '539',
    name: 'Zynga AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Zynga games.',
    url: 'https://www.zynga.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zynga',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'cyan'
  },
  {
    id: '540',
    name: 'Playrix AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Playrix games.',
    url: 'https://www.playrix.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=playrix',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'purple'
  },
  {
    id: '541',
    name: 'Niantic AI Gaming',
    category: 'Gaming',
    description: 'AI-powered features integrated into Niantic games.',
    url: 'https://nianticlabs.com/features/ai-gaming',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=niantic',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'cyan'
  },
  {
    id: '542',
    name: 'Roblox Studio AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into Roblox Studio for game development.',
    url: 'https://create.roblox.com/features/ai-studio',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=robloxstudio',
    suggested_prompt: 'Use AI to help me build and deploy intelligent games on Roblox...',
    color: 'purple'
  },
  {
    id: '543',
    name: 'Unity Sentis',
    category: 'Gaming',
    description: 'AI-powered engine for real-time inference in Unity games.',
    url: 'https://unity.com/products/sentis',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=unitysentis',
    suggested_prompt: 'Use AI to help me serve my machine learning models in real-time on Unity...',
    color: 'cyan'
  },
  {
    id: '544',
    name: 'Unreal Engine MetaHuman',
    category: 'Gaming',
    description: 'AI-powered tool for creating realistic digital humans in Unreal Engine.',
    url: 'https://www.unrealengine.com/metahuman',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=metahuman',
    suggested_prompt: 'Use AI to help me create realistic digital humans for my games...',
    color: 'purple'
  },
  {
    id: '545',
    name: 'NVIDIA Omniverse AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into the NVIDIA Omniverse platform.',
    url: 'https://www.nvidia.com/en-us/omniverse/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nvidiaomniverse',
    suggested_prompt: 'Use AI to help me build and deploy intelligent 3D applications...',
    color: 'cyan'
  },
  {
    id: '546',
    name: 'AMD FidelityFX AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into the AMD FidelityFX toolkit.',
    url: 'https://www.amd.com/en/technologies/fidelityfx-ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=amdfidelityfx',
    suggested_prompt: 'Use AI to help me improve my gaming performance and visual quality...',
    color: 'purple'
  },
  {
    id: '547',
    name: 'Intel OpenVINO Gaming',
    category: 'Gaming',
    description: 'AI-powered toolkit for optimizing and deploying AI in games.',
    url: 'https://www.intel.com/content/www/us/en/developer/tools/openvino-toolkit/gaming.html',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=intelopenvino',
    suggested_prompt: 'Use AI to help me optimize and deploy my machine learning models in games...',
    color: 'cyan'
  },
  {
    id: '548',
    name: 'Sony PlayStation AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into PlayStation games and services.',
    url: 'https://www.playstation.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=playstation',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'purple'
  },
  {
    id: '549',
    name: 'Microsoft Xbox AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into Xbox games and services.',
    url: 'https://www.xbox.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=xbox',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'cyan'
  },
  {
    id: '550',
    name: 'Nintendo Switch AI',
    category: 'Gaming',
    description: 'AI-powered features integrated into Nintendo Switch games and services.',
    url: 'https://www.nintendo.com/switch/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nintendoswitch',
    suggested_prompt: 'Use AI to help me improve my gaming experience and visual quality...',
    color: 'purple'
  },
  {
    id: '551',
    name: 'Duolingo AI',
    category: 'Education',
    description: 'AI-powered language learning features integrated into Duolingo.',
    url: 'https://www.duolingo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=duolingo',
    suggested_prompt: 'Use AI to help me learn a new language more effectively...',
    color: 'cyan'
  },
  {
    id: '552',
    name: 'Coursera AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Coursera learning platform.',
    url: 'https://www.coursera.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=coursera',
    suggested_prompt: 'Use AI to help me find the right courses and improve my learning...',
    color: 'purple'
  },
  {
    id: '553',
    name: 'edX AI',
    category: 'Education',
    description: 'AI-powered features integrated into the edX learning platform.',
    url: 'https://www.edx.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=edx',
    suggested_prompt: 'Use AI to help me find the right courses and improve my learning...',
    color: 'cyan'
  },
  {
    id: '554',
    name: 'Udacity AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Udacity learning platform.',
    url: 'https://www.udacity.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=udacity',
    suggested_prompt: 'Use AI to help me find the right courses and improve my learning...',
    color: 'purple'
  },
  {
    id: '555',
    name: 'Khan Academy AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Khan Academy learning platform.',
    url: 'https://www.khanacademy.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=khanacademy',
    suggested_prompt: 'Use AI to help me learn new subjects and improve my understanding...',
    color: 'cyan'
  },
  {
    id: '556',
    name: 'Quizlet AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Quizlet learning platform.',
    url: 'https://quizlet.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=quizlet',
    suggested_prompt: 'Use AI to help me study more effectively and improve my memory...',
    color: 'purple'
  },
  {
    id: '557',
    name: 'Chegg AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Chegg learning platform.',
    url: 'https://www.chegg.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=chegg',
    suggested_prompt: 'Use AI to help me find answers to my questions and improve my learning...',
    color: 'cyan'
  },
  {
    id: '558',
    name: 'Grammarly AI',
    category: 'Education',
    description: 'AI-powered writing assistant for grammar, spelling, and style.',
    url: 'https://www.grammarly.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=grammarly',
    suggested_prompt: 'Use AI to help me improve my writing and communicate more effectively...',
    color: 'purple'
  },
  {
    id: '559',
    name: 'Turnitin AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Turnitin plagiarism detection platform.',
    url: 'https://www.turnitin.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=turnitin',
    suggested_prompt: 'Use AI to help me detect plagiarism and improve academic integrity...',
    color: 'cyan'
  },
  {
    id: '560',
    name: 'Blackboard AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Blackboard learning management system.',
    url: 'https://www.blackboard.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=blackboard',
    suggested_prompt: 'Use AI to help me manage my courses and improve my learning...',
    color: 'purple'
  },
  {
    id: '561',
    name: 'Canvas AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Canvas learning management system.',
    url: 'https://www.instructure.com/canvas/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=canvas',
    suggested_prompt: 'Use AI to help me manage my courses and improve my learning...',
    color: 'cyan'
  },
  {
    id: '562',
    name: 'Moodle AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Moodle learning management system.',
    url: 'https://moodle.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=moodle',
    suggested_prompt: 'Use AI to help me manage my courses and improve my learning...',
    color: 'purple'
  },
  {
    id: '563',
    name: 'Google Classroom AI',
    category: 'Education',
    description: 'AI-powered features integrated into Google Classroom.',
    url: 'https://classroom.google.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=googleclassroom',
    suggested_prompt: 'Use AI to help me manage my classes and improve my learning...',
    color: 'cyan'
  },
  {
    id: '564',
    name: 'Microsoft Teams for Education AI',
    category: 'Education',
    description: 'AI-powered features integrated into Microsoft Teams for Education.',
    url: 'https://www.microsoft.com/en-us/education/products/teams/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=microsoftteamsedu',
    suggested_prompt: 'Use AI to help me manage my classes and improve my learning...',
    color: 'purple'
  },
  {
    id: '565',
    name: 'Zoom for Education AI',
    category: 'Education',
    description: 'AI-powered features integrated into Zoom for Education.',
    url: 'https://zoom.us/education/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zoomedu',
    suggested_prompt: 'Use AI to help me manage my classes and improve my learning...',
    color: 'cyan'
  },
  {
    id: '566',
    name: 'Kahoot! AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Kahoot! learning platform.',
    url: 'https://kahoot.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kahoot',
    suggested_prompt: 'Use AI to help me create and play engaging learning games...',
    color: 'purple'
  },
  {
    id: '567',
    name: 'Padlet AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Padlet collaboration platform.',
    url: 'https://padlet.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=padlet',
    suggested_prompt: 'Use AI to help me collaborate and share ideas more effectively...',
    color: 'cyan'
  },
  {
    id: '568',
    name: 'Seesaw AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Seesaw learning platform.',
    url: 'https://web.seesaw.me/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=seesaw',
    suggested_prompt: 'Use AI to help me manage my classes and improve my learning...',
    color: 'purple'
  },
  {
    id: '569',
    name: 'Remind AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Remind communication platform.',
    url: 'https://www.remind.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=remind',
    suggested_prompt: 'Use AI to help me communicate with my students and parents more effectively...',
    color: 'cyan'
  },
  {
    id: '570',
    name: 'ClassDojo AI',
    category: 'Education',
    description: 'AI-powered features integrated into the ClassDojo platform.',
    url: 'https://www.classdojo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=classdojo',
    suggested_prompt: 'Use AI to help me manage my classes and improve my learning...',
    color: 'purple'
  },
  {
    id: '571',
    name: 'Robinhood AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Robinhood trading platform.',
    url: 'https://robinhood.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=robinhood',
    suggested_prompt: 'Use AI to help me manage my investments and gain insights into the market...',
    color: 'cyan'
  },
  {
    id: '572',
    name: 'Coinbase AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Coinbase cryptocurrency platform.',
    url: 'https://www.coinbase.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=coinbase',
    suggested_prompt: 'Use AI to help me manage my cryptocurrency investments and gain insights...',
    color: 'purple'
  },
  {
    id: '573',
    name: 'Binance AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Binance cryptocurrency platform.',
    url: 'https://www.binance.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=binance',
    suggested_prompt: 'Use AI to help me manage my cryptocurrency investments and gain insights...',
    color: 'cyan'
  },
  {
    id: '574',
    name: 'Kraken AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Kraken cryptocurrency platform.',
    url: 'https://www.kraken.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kraken',
    suggested_prompt: 'Use AI to help me manage my cryptocurrency investments and gain insights...',
    color: 'purple'
  },
  {
    id: '575',
    name: 'Gemini AI Finance',
    category: 'Finance',
    description: 'AI-powered features integrated into the Gemini cryptocurrency platform.',
    url: 'https://www.gemini.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=geminifinance',
    suggested_prompt: 'Use AI to help me manage my cryptocurrency investments and gain insights...',
    color: 'cyan'
  },
  {
    id: '576',
    name: 'PayPal AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the PayPal payment platform.',
    url: 'https://www.paypal.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=paypal',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'purple'
  },
  {
    id: '577',
    name: 'Venmo AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Venmo payment platform.',
    url: 'https://venmo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=venmo',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'cyan'
  },
  {
    id: '578',
    name: 'Cash App AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Cash App payment platform.',
    url: 'https://cash.app/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cashapp',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'purple'
  },
  {
    id: '579',
    name: 'Zelle AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Zelle payment platform.',
    url: 'https://www.zellepay.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zelle',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'cyan'
  },
  {
    id: '580',
    name: 'Stripe AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Stripe payment platform.',
    url: 'https://stripe.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=stripe',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'purple'
  },
  {
    id: '581',
    name: 'Square AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Square payment platform.',
    url: 'https://squareup.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=square',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'cyan'
  },
  {
    id: '582',
    name: 'Adyen AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Adyen payment platform.',
    url: 'https://www.adyen.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=adyen',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'purple'
  },
  {
    id: '583',
    name: 'Klarna AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Klarna payment platform.',
    url: 'https://www.klarna.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=klarna',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'cyan'
  },
  {
    id: '584',
    name: 'Affirm AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Affirm payment platform.',
    url: 'https://www.affirm.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=affirm',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'purple'
  },
  {
    id: '585',
    name: 'Afterpay AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Afterpay payment platform.',
    url: 'https://www.afterpay.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=afterpay',
    suggested_prompt: 'Use AI to help me manage my payments and improve my financial security...',
    color: 'cyan'
  },
  {
    id: '586',
    name: 'SoFi AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the SoFi financial platform.',
    url: 'https://www.sofi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sofi',
    suggested_prompt: 'Use AI to help me manage my finances and improve my financial security...',
    color: 'purple'
  },
  {
    id: '587',
    name: 'Chime AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Chime financial platform.',
    url: 'https://www.chime.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=chime',
    suggested_prompt: 'Use AI to help me manage my finances and improve my financial security...',
    color: 'cyan'
  },
  {
    id: '588',
    name: 'Revolut AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Revolut financial platform.',
    url: 'https://www.revolut.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=revolut',
    suggested_prompt: 'Use AI to help me manage my finances and improve my financial security...',
    color: 'purple'
  },
  {
    id: '589',
    name: 'Monzo AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Monzo financial platform.',
    url: 'https://monzo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=monzo',
    suggested_prompt: 'Use AI to help me manage my finances and improve my financial security...',
    color: 'cyan'
  },
  {
    id: '590',
    name: 'N26 AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the N26 financial platform.',
    url: 'https://n26.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=n26',
    suggested_prompt: 'Use AI to help me manage my finances and improve my financial security...',
    color: 'purple'
  },
  {
    id: '591',
    name: 'LegalZoom AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the LegalZoom platform.',
    url: 'https://www.legalzoom.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=legalzoom',
    suggested_prompt: 'Use AI to help me manage my legal needs and improve my legal security...',
    color: 'cyan'
  },
  {
    id: '592',
    name: 'Rocket Lawyer AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Rocket Lawyer platform.',
    url: 'https://www.rocketlawyer.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rocketlawyer',
    suggested_prompt: 'Use AI to help me manage my legal needs and improve my legal security...',
    color: 'purple'
  },
  {
    id: '593',
    name: 'Clio AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Clio legal practice management platform.',
    url: 'https://www.clio.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=clio',
    suggested_prompt: 'Use AI to help me manage my legal practice and improve my legal security...',
    color: 'cyan'
  },
  {
    id: '594',
    name: 'MyCase AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the MyCase legal practice management platform.',
    url: 'https://www.mycase.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mycase',
    suggested_prompt: 'Use AI to help me manage my legal practice and improve my legal security...',
    color: 'purple'
  },
  {
    id: '595',
    name: 'PracticePanther AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the PracticePanther platform.',
    url: 'https://www.practicepanther.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=practicepanther',
    suggested_prompt: 'Use AI to help me manage my legal practice and improve my legal security...',
    color: 'cyan'
  },
  {
    id: '596',
    name: 'Smokeball AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Smokeball platform.',
    url: 'https://www.smokeball.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=smokeball',
    suggested_prompt: 'Use AI to help me manage my legal practice and improve my legal security...',
    color: 'purple'
  },
  {
    id: '597',
    name: 'Filevine AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Filevine platform.',
    url: 'https://www.filevine.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=filevine',
    suggested_prompt: 'Use AI to help me manage my legal practice and improve my legal security...',
    color: 'cyan'
  },
  {
    id: '598',
    name: 'Litify AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Litify platform.',
    url: 'https://www.litify.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=litify',
    suggested_prompt: 'Use AI to help me manage my legal practice and improve my legal security...',
    color: 'purple'
  },
  {
    id: '599',
    name: 'Ironclad AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Ironclad contract management platform.',
    url: 'https://ironcladapp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ironclad',
    suggested_prompt: 'Use AI to help me manage my contracts and improve my legal security...',
    color: 'cyan'
  },
  {
    id: '600',
    name: 'LinkSquares AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the LinkSquares platform.',
    url: 'https://linksquares.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=linksquares',
    suggested_prompt: 'Use AI to help me manage my contracts and improve my legal security...',
    color: 'purple'
  },
  {
    id: '601',
    name: 'Zillow AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Zillow real estate platform.',
    url: 'https://www.zillow.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zillow',
    suggested_prompt: 'Use AI to help me find the right home and manage my real estate needs...',
    color: 'cyan'
  },
  {
    id: '602',
    name: 'Redfin AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Redfin real estate platform.',
    url: 'https://www.redfin.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=redfin',
    suggested_prompt: 'Use AI to help me find the right home and manage my real estate needs...',
    color: 'purple'
  },
  {
    id: '603',
    name: 'Trulia AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Trulia real estate platform.',
    url: 'https://www.trulia.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=trulia',
    suggested_prompt: 'Use AI to help me find the right home and manage my real estate needs...',
    color: 'cyan'
  },
  {
    id: '604',
    name: 'Realtor.com AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Realtor.com platform.',
    url: 'https://www.realtor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=realtor',
    suggested_prompt: 'Use AI to help me find the right home and manage my real estate needs...',
    color: 'purple'
  },
  {
    id: '605',
    name: 'Compass AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Compass real estate platform.',
    url: 'https://www.compass.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=compass',
    suggested_prompt: 'Use AI to help me find the right home and manage my real estate needs...',
    color: 'cyan'
  },
  {
    id: '606',
    name: 'Opendoor AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Opendoor real estate platform.',
    url: 'https://www.opendoor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=opendoor',
    suggested_prompt: 'Use AI to help me sell my home and manage my real estate needs...',
    color: 'purple'
  },
  {
    id: '607',
    name: 'Offerpad AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Offerpad real estate platform.',
    url: 'https://www.offerpad.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=offerpad',
    suggested_prompt: 'Use AI to help me sell my home and manage my real estate needs...',
    color: 'cyan'
  },
  {
    id: '608',
    name: 'Roofstock AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Roofstock real estate platform.',
    url: 'https://www.roofstock.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=roofstock',
    suggested_prompt: 'Use AI to help me invest in real estate and manage my properties...',
    color: 'purple'
  },
  {
    id: '609',
    name: 'AppFolio AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the AppFolio property management platform.',
    url: 'https://www.appfolio.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=appfolio',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'cyan'
  },
  {
    id: '610',
    name: 'Entrata AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Entrata property management platform.',
    url: 'https://www.entrata.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=entrata',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'purple'
  },
  {
    id: '611',
    name: 'Yardi AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Yardi property management platform.',
    url: 'https://www.yardi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=yardi',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'cyan'
  },
  {
    id: '612',
    name: 'RealPage AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the RealPage property management platform.',
    url: 'https://www.realpage.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=realpage',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'purple'
  },
  {
    id: '613',
    name: 'Buildium AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Buildium property management platform.',
    url: 'https://www.buildium.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=buildium',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'cyan'
  },
  {
    id: '614',
    name: 'Propertyware AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Propertyware platform.',
    url: 'https://www.propertyware.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=propertyware',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'purple'
  },
  {
    id: '615',
    name: 'RentRedi AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the RentRedi platform.',
    url: 'https://rentredi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rentredi',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'cyan'
  },
  {
    id: '616',
    name: 'Avail AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Avail platform.',
    url: 'https://www.avail.co/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=avail',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'purple'
  },
  {
    id: '617',
    name: 'TurboTenant AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the TurboTenant platform.',
    url: 'https://www.turbotenant.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=turbotenant',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'cyan'
  },
  {
    id: '618',
    name: 'Stessa AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Stessa platform.',
    url: 'https://www.stessa.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=stessa',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'purple'
  },
  {
    id: '619',
    name: 'Baselane AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Baselane platform.',
    url: 'https://www.baselane.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=baselane',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'cyan'
  },
  {
    id: '620',
    name: 'Azibo AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Azibo platform.',
    url: 'https://www.azibo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=azibo',
    suggested_prompt: 'Use AI to help me manage my properties and improve my real estate business...',
    color: 'purple'
  },
  {
    id: '621',
    name: 'Expedia AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Expedia travel platform.',
    url: 'https://www.expedia.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=expedia',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '622',
    name: 'Booking.com AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Booking.com travel platform.',
    url: 'https://www.booking.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=booking',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '623',
    name: 'Airbnb AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Airbnb travel platform.',
    url: 'https://www.airbnb.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=airbnb',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '624',
    name: 'TripAdvisor AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the TripAdvisor travel platform.',
    url: 'https://www.tripadvisor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tripadvisor',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '625',
    name: 'Kayak AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Kayak travel platform.',
    url: 'https://www.kayak.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kayak',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '626',
    name: 'Skyscanner AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Skyscanner travel platform.',
    url: 'https://www.skyscanner.net/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=skyscanner',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '627',
    name: 'Hopper AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Hopper travel platform.',
    url: 'https://www.hopper.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hopper',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '628',
    name: 'Google Flights AI',
    category: 'Travel',
    description: 'AI-powered features integrated into Google Flights.',
    url: 'https://www.google.com/flights/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=googleflights',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '629',
    name: 'Marriott AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Marriott travel platform.',
    url: 'https://www.marriott.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=marriott',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '630',
    name: 'Hilton AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Hilton travel platform.',
    url: 'https://www.hilton.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hilton',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '631',
    name: 'Hyatt AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Hyatt travel platform.',
    url: 'https://www.hyatt.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hyatt',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '632',
    name: 'Accor AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Accor travel platform.',
    url: 'https://all.accor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=accor',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '633',
    name: 'IHG AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the IHG travel platform.',
    url: 'https://www.ihg.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ihg',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '634',
    name: 'Wyndham AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Wyndham travel platform.',
    url: 'https://www.wyndhamhotels.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wyndham',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '635',
    name: 'Choice Hotels AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Choice Hotels platform.',
    url: 'https://www.choicehotels.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=choicehotels',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '636',
    name: 'Best Western AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Best Western platform.',
    url: 'https://www.bestwestern.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bestwestern',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '637',
    name: 'Radisson AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Radisson travel platform.',
    url: 'https://www.radissonhotels.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=radisson',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '638',
    name: 'TUI AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the TUI travel platform.',
    url: 'https://www.tui.co.uk/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tui',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '639',
    name: 'Carnival AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Carnival travel platform.',
    url: 'https://www.carnival.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=carnival',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'cyan'
  },
  {
    id: '640',
    name: 'Royal Caribbean AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Royal Caribbean platform.',
    url: 'https://www.royalcaribbean.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=royalcaribbean',
    suggested_prompt: 'Use AI to help me plan my travel and find the best deals...',
    color: 'purple'
  },
  {
    id: '641',
    name: 'FedEx AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into the FedEx logistics platform.',
    url: 'https://www.fedex.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fedex',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'cyan'
  },
  {
    id: '642',
    name: 'UPS AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into the UPS logistics platform.',
    url: 'https://www.ups.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ups',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'purple'
  },
  {
    id: '643',
    name: 'DHL AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into the DHL logistics platform.',
    url: 'https://www.dhl.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=dhl',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'cyan'
  },
  {
    id: '644',
    name: 'Maersk AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into the Maersk logistics platform.',
    url: 'https://www.maersk.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=maersk',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'purple'
  },
  {
    id: '645',
    name: 'Hapag-Lloyd AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into the Hapag-Lloyd platform.',
    url: 'https://www.hapag-lloyd.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hapaglloyd',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'cyan'
  },
  {
    id: '646',
    name: 'MSC AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into the MSC logistics platform.',
    url: 'https://www.msc.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=msc',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'purple'
  },
  {
    id: '647',
    name: 'CMA CGM AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into the CMA CGM platform.',
    url: 'https://www.cma-cgm.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cmacgm',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'cyan'
  },
  {
    id: '648',
    name: 'COSCO AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into the COSCO logistics platform.',
    url: 'https://www.coscoshipping.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cosco',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'purple'
  },
  {
    id: '649',
    name: 'Evergreen AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into the Evergreen platform.',
    url: 'https://www.evergreen-marine.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=evergreen',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'cyan'
  },
  {
    id: '650',
    name: 'ONE AI Logistics',
    category: 'Logistics',
    description: 'AI-powered features integrated into the ONE logistics platform.',
    url: 'https://www.one-line.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=onelogistics',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my business...',
    color: 'purple'
  },
  {
    id: '651',
    name: 'Shell AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the Shell energy platform.',
    url: 'https://www.shell.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=shell',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'cyan'
  },
  {
    id: '652',
    name: 'BP AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the BP energy platform.',
    url: 'https://www.bp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bp',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'purple'
  },
  {
    id: '653',
    name: 'ExxonMobil AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the ExxonMobil platform.',
    url: 'https://www.exxonmobil.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=exxonmobil',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'cyan'
  },
  {
    id: '654',
    name: 'Chevron AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the Chevron energy platform.',
    url: 'https://www.chevron.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=chevron',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'purple'
  },
  {
    id: '655',
    name: 'TotalEnergies AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the TotalEnergies platform.',
    url: 'https://totalenergies.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=totalenergies',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'cyan'
  },
  {
    id: '656',
    name: 'Eni AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the Eni energy platform.',
    url: 'https://www.eni.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=eni',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'purple'
  },
  {
    id: '657',
    name: 'Equinor AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the Equinor energy platform.',
    url: 'https://www.equinor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=equinor',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'cyan'
  },
  {
    id: '658',
    name: 'Repsol AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the Repsol energy platform.',
    url: 'https://www.repsol.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=repsol',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'purple'
  },
  {
    id: '659',
    name: 'OMV AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the OMV energy platform.',
    url: 'https://www.omv.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=omv',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'cyan'
  },
  {
    id: '660',
    name: 'Galp AI',
    category: 'Energy',
    description: 'AI-powered features integrated into the Galp energy platform.',
    url: 'https://www.galp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=galp',
    suggested_prompt: 'Use AI to help me manage my energy needs and improve my business...',
    color: 'purple'
  },
  {
    id: '661',
    name: 'John Deere AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the John Deere agriculture platform.',
    url: 'https://www.deere.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=johndeere',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'cyan'
  },
  {
    id: '662',
    name: 'CNH Industrial AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the CNH Industrial platform.',
    url: 'https://www.cnhindustrial.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cnhindustrial',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'purple'
  },
  {
    id: '663',
    name: 'AGCO AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the AGCO agriculture platform.',
    url: 'https://www.agcocorp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=agco',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'cyan'
  },
  {
    id: '664',
    name: 'Kubota AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the Kubota agriculture platform.',
    url: 'https://www.kubota.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kubota',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'purple'
  },
  {
    id: '665',
    name: 'CLAAS AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the CLAAS agriculture platform.',
    url: 'https://www.claas.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=claas',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'cyan'
  },
  {
    id: '666',
    name: 'Yanmar AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the Yanmar agriculture platform.',
    url: 'https://www.yanmar.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=yanmar',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'purple'
  },
  {
    id: '667',
    name: 'Mahindra AI Agriculture',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the Mahindra agriculture platform.',
    url: 'https://www.mahindra.com/features/ai-agriculture',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mahindraagri',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'cyan'
  },
  {
    id: '668',
    name: 'TAFE AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the TAFE agriculture platform.',
    url: 'https://www.tafe.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tafe',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'purple'
  },
  {
    id: '669',
    name: 'Escorts AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the Escorts agriculture platform.',
    url: 'https://www.escortsgroup.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=escorts',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'cyan'
  },
  {
    id: '670',
    name: 'Sonalika AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into the Sonalika agriculture platform.',
    url: 'https://www.sonalika.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sonalika',
    suggested_prompt: 'Use AI to help me manage my farm and improve my agriculture business...',
    color: 'purple'
  },
  {
    id: '671',
    name: 'Siemens AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the Siemens manufacturing platform.',
    url: 'https://www.siemens.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=siemens',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'cyan'
  },
  {
    id: '672',
    name: 'ABB AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the ABB manufacturing platform.',
    url: 'https://www.abb.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=abb',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'purple'
  },
  {
    id: '673',
    name: 'Schneider Electric AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the Schneider Electric platform.',
    url: 'https://www.se.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=schneider',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'cyan'
  },
  {
    id: '674',
    name: 'Rockwell Automation AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the Rockwell Automation platform.',
    url: 'https://www.rockwellautomation.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rockwell',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'purple'
  },
  {
    id: '675',
    name: 'Honeywell AI Manufacturing',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the Honeywell manufacturing platform.',
    url: 'https://www.honeywell.com/features/ai-manufacturing',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=honeywellmfg',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'cyan'
  },
  {
    id: '676',
    name: 'Emerson AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the Emerson manufacturing platform.',
    url: 'https://www.emerson.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=emerson',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'purple'
  },
  {
    id: '677',
    name: 'Mitsubishi Electric AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the Mitsubishi Electric platform.',
    url: 'https://www.mitsubishielectric.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mitsubishi',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'cyan'
  },
  {
    id: '678',
    name: 'Fanuc AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the Fanuc manufacturing platform.',
    url: 'https://www.fanuc.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fanuc',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'purple'
  },
  {
    id: '679',
    name: 'Yaskawa AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the Yaskawa manufacturing platform.',
    url: 'https://www.yaskawa.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=yaskawa',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'cyan'
  },
  {
    id: '680',
    name: 'Kuka AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into the Kuka manufacturing platform.',
    url: 'https://www.kuka.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kuka',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my business...',
    color: 'purple'
  },
  {
    id: '681',
    name: 'Walmart AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Walmart retail platform.',
    url: 'https://www.walmart.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=walmartretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '682',
    name: 'Amazon AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Amazon retail platform.',
    url: 'https://www.amazon.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=amazonretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '683',
    name: 'Target AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Target retail platform.',
    url: 'https://www.target.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=targetretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '684',
    name: 'Costco AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Costco retail platform.',
    url: 'https://www.costco.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=costcoretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '685',
    name: 'Kroger AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Kroger retail platform.',
    url: 'https://www.kroger.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=krogerretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '686',
    name: 'Walgreens AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Walgreens retail platform.',
    url: 'https://www.walgreens.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=walgreensretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '687',
    name: 'CVS AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the CVS retail platform.',
    url: 'https://www.cvs.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cvsretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '688',
    name: 'Home Depot AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Home Depot retail platform.',
    url: 'https://www.homedepot.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=homedepotretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '689',
    name: 'Lowe\'s AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Lowe\'s retail platform.',
    url: 'https://www.lowes.com/features/ai-retail',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lowesretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '690',
    name: 'Best Buy AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Best Buy retail platform.',
    url: 'https://www.bestbuy.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bestbuyretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '691',
    name: 'Macy\'s AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Macy\'s retail platform.',
    url: 'https://www.macys.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=macysretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '692',
    name: 'Kohl\'s AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Kohl\'s retail platform.',
    url: 'https://www.kohls.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kohlsretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '693',
    name: 'Nordstrom AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Nordstrom retail platform.',
    url: 'https://www.nordstrom.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nordstromretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '694',
    name: 'Gap AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Gap retail platform.',
    url: 'https://www.gap.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gapretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '695',
    name: 'Old Navy AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Old Navy retail platform.',
    url: 'https://oldnavy.gap.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=oldnavyretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '696',
    name: 'Banana Republic AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Banana Republic platform.',
    url: 'https://bananarepublic.gap.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bananarepublicretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '697',
    name: 'Athleta AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Athleta retail platform.',
    url: 'https://athleta.gap.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=athletaretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '698',
    name: 'Lululemon AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Lululemon retail platform.',
    url: 'https://shop.lululemon.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lululemonretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '699',
    name: 'Nike AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Nike retail platform.',
    url: 'https://www.nike.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nikeretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'cyan'
  },
  {
    id: '700',
    name: 'Adidas AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Adidas retail platform.',
    url: 'https://www.adidas.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=adidasretail',
    suggested_prompt: 'Use AI to help me find the right products and improve my shopping...',
    color: 'purple'
  },
  {
    id: '701',
    name: 'Toyota AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Toyota vehicles and services.',
    url: 'https://www.toyota.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=toyota',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'cyan'
  },
  {
    id: '702',
    name: 'Volkswagen AI',
    category: 'Automotive',
    description: 'AI-powered features integrated into Volkswagen vehicles and services.',
    url: 'https://www.volkswagen.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=volkswagen',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'purple'
  },
  {
    id: '703',
    name: 'Hyundai AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Hyundai vehicles and services.',
    url: 'https://www.hyundai.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hyundai',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'cyan'
  },
  {
    id: '704',
    name: 'GM AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into GM vehicles and services.',
    url: 'https://www.gm.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gm',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'purple'
  },
  {
    id: '705',
    name: 'Stellantis AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Stellantis vehicles and services.',
    url: 'https://www.stellantis.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=stellantis',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'cyan'
  },
  {
    id: '706',
    name: 'Honda AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Honda vehicles and services.',
    url: 'https://www.honda.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=honda',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'purple'
  },
  {
    id: '707',
    name: 'Nissan AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Nissan vehicles and services.',
    url: 'https://www.nissan-global.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nissan',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'cyan'
  },
  {
    id: '708',
    name: 'BMW AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into BMW vehicles and services.',
    url: 'https://www.bmw.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bmw',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'purple'
  },
  {
    id: '709',
    name: 'Mercedes-Benz AI',
    category: 'Automotive',
    description: 'AI-powered features integrated into Mercedes-Benz vehicles and services.',
    url: 'https://www.mercedes-benz.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mercedes',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'cyan'
  },
  {
    id: '710',
    name: 'Renault AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Renault vehicles and services.',
    url: 'https://www.renaultgroup.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=renault',
    suggested_prompt: 'Use AI to help me improve my driving experience and vehicle safety...',
    color: 'purple'
  },
  {
    id: '711',
    name: 'Netflix AI',
    category: 'Media',
    description: 'AI-powered features integrated into the Netflix streaming platform.',
    url: 'https://www.netflix.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=netflix',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'cyan'
  },
  {
    id: '712',
    name: 'Disney+ AI',
    category: 'Media',
    description: 'AI-powered features integrated into the Disney+ streaming platform.',
    url: 'https://www.disneyplus.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=disneyplus',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'purple'
  },
  {
    id: '713',
    name: 'Amazon Prime Video AI',
    category: 'Media',
    description: 'AI-powered features integrated into Amazon Prime Video.',
    url: 'https://www.primevideo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=primevideo',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'cyan'
  },
  {
    id: '714',
    name: 'Hulu AI',
    category: 'Media',
    description: 'AI-powered features integrated into the Hulu streaming platform.',
    url: 'https://www.hulu.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hulu',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'purple'
  },
  {
    id: '715',
    name: 'HBO Max AI',
    category: 'Media',
    description: 'AI-powered features integrated into the HBO Max streaming platform.',
    url: 'https://www.hbomax.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hbomax',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'cyan'
  },
  {
    id: '716',
    name: 'Paramount+ AI',
    category: 'Media',
    description: 'AI-powered features integrated into the Paramount+ streaming platform.',
    url: 'https://www.paramountplus.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=paramountplus',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'purple'
  },
  {
    id: '717',
    name: 'Apple TV+ AI',
    category: 'Media',
    description: 'AI-powered features integrated into the Apple TV+ streaming platform.',
    url: 'https://www.apple.com/apple-tv-plus/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=appletvplus',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'cyan'
  },
  {
    id: '718',
    name: 'Peacock AI',
    category: 'Media',
    description: 'AI-powered features integrated into the Peacock streaming platform.',
    url: 'https://www.peacocktv.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=peacock',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'purple'
  },
  {
    id: '719',
    name: 'YouTube AI Media',
    category: 'Media',
    description: 'AI-powered features integrated into the YouTube platform.',
    url: 'https://www.youtube.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=youtubemedia',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'cyan'
  },
  {
    id: '720',
    name: 'TikTok AI Media',
    category: 'Media',
    description: 'AI-powered features integrated into the TikTok platform.',
    url: 'https://www.tiktok.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tiktokmedia',
    suggested_prompt: 'Use AI to help me find the right content and improve my streaming...',
    color: 'purple'
  },
  {
    id: '721',
    name: 'Spotify AI Music',
    category: 'Music',
    description: 'AI-powered features integrated into the Spotify music platform.',
    url: 'https://www.spotify.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=spotifymusic',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'cyan'
  },
  {
    id: '722',
    name: 'Apple Music AI',
    category: 'Music',
    description: 'AI-powered features integrated into the Apple Music platform.',
    url: 'https://www.apple.com/apple-music/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=applemusic',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'purple'
  },
  {
    id: '723',
    name: 'Amazon Music AI',
    category: 'Music',
    description: 'AI-powered features integrated into Amazon Music.',
    url: 'https://music.amazon.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=amazonmusic',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'cyan'
  },
  {
    id: '724',
    name: 'YouTube Music AI',
    category: 'Music',
    description: 'AI-powered features integrated into YouTube Music.',
    url: 'https://music.youtube.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=youtubemusic',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'purple'
  },
  {
    id: '725',
    name: 'Tidal AI',
    category: 'Music',
    description: 'AI-powered features integrated into the Tidal music platform.',
    url: 'https://tidal.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tidal',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'cyan'
  },
  {
    id: '726',
    name: 'Deezer AI',
    category: 'Music',
    description: 'AI-powered features integrated into the Deezer music platform.',
    url: 'https://www.deezer.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=deezer',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'purple'
  },
  {
    id: '727',
    name: 'Pandora AI',
    category: 'Music',
    description: 'AI-powered features integrated into the Pandora music platform.',
    url: 'https://www.pandora.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pandora',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'cyan'
  },
  {
    id: '728',
    name: 'SoundCloud AI',
    category: 'Music',
    description: 'AI-powered features integrated into the SoundCloud platform.',
    url: 'https://soundcloud.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=soundcloud',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'purple'
  },
  {
    id: '729',
    name: 'iHeartRadio AI',
    category: 'Music',
    description: 'AI-powered features integrated into the iHeartRadio platform.',
    url: 'https://www.iheart.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=iheartradio',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'cyan'
  },
  {
    id: '730',
    name: 'TuneIn AI',
    category: 'Music',
    description: 'AI-powered features integrated into the TuneIn platform.',
    url: 'https://tunein.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tunein',
    suggested_prompt: 'Use AI to help me find the right music and improve my listening...',
    color: 'purple'
  },
  {
    id: '731',
    name: 'Facebook AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Facebook platform.',
    url: 'https://www.facebook.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=facebooksocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '732',
    name: 'Instagram AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Instagram platform.',
    url: 'https://www.instagram.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=instagramsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '733',
    name: 'WhatsApp AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the WhatsApp platform.',
    url: 'https://www.whatsapp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=whatsappsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '734',
    name: 'Messenger AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Messenger platform.',
    url: 'https://www.messenger.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=messengersocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '735',
    name: 'Twitter/X AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Twitter/X platform.',
    url: 'https://twitter.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=twittersocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '736',
    name: 'LinkedIn AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the LinkedIn platform.',
    url: 'https://www.linkedin.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=linkedinsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '737',
    name: 'Snapchat AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Snapchat platform.',
    url: 'https://www.snapchat.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=snapchatsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '738',
    name: 'Pinterest AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Pinterest platform.',
    url: 'https://www.pinterest.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pinterestsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '739',
    name: 'Reddit AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Reddit platform.',
    url: 'https://www.reddit.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=redditsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '740',
    name: 'Discord AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Discord platform.',
    url: 'https://discord.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=discordsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '741',
    name: 'Telegram AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Telegram platform.',
    url: 'https://telegram.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=telegramsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '742',
    name: 'Signal AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Signal platform.',
    url: 'https://signal.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=signalsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '743',
    name: 'Slack AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Slack platform.',
    url: 'https://slack.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=slacksocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '744',
    name: 'Microsoft Teams AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into Microsoft Teams.',
    url: 'https://www.microsoft.com/en-us/microsoft-teams/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=microsoftteamssocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '745',
    name: 'Zoom AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Zoom platform.',
    url: 'https://zoom.us/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zoomsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '746',
    name: 'Google Meet AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into Google Meet.',
    url: 'https://meet.google.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=googlemeetsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '747',
    name: 'Webex AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Webex platform.',
    url: 'https://www.webex.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=webexsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '748',
    name: 'GoToMeeting AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the GoToMeeting platform.',
    url: 'https://www.goto.com/meeting/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gotomeetingsocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '749',
    name: 'BlueJeans AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the BlueJeans platform.',
    url: 'https://www.bluejeans.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bluejeanssocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'cyan'
  },
  {
    id: '750',
    name: 'Skype AI Social',
    category: 'Social',
    description: 'AI-powered features integrated into the Skype platform.',
    url: 'https://www.skype.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=skypesocial',
    suggested_prompt: 'Use AI to help me connect with my friends and improve my social...',
    color: 'purple'
  },
  {
    id: '751',
    name: 'Notion AI Productivity',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Notion workspace.',
    url: 'https://www.notion.so/product/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=notionproductivity',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'cyan'
  },
  {
    id: '752',
    name: 'Obsidian AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Obsidian note-taking app.',
    url: 'https://obsidian.md/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=obsidian',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'purple'
  },
  {
    id: '753',
    name: 'Roam Research AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into Roam Research.',
    url: 'https://roamresearch.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=roamresearch',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'cyan'
  },
  {
    id: '754',
    name: 'Logseq AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Logseq note-taking app.',
    url: 'https://logseq.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=logseq',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'purple'
  },
  {
    id: '755',
    name: 'Evernote AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Evernote note-taking app.',
    url: 'https://evernote.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=evernote',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'cyan'
  },
  {
    id: '756',
    name: 'Todoist AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Todoist task manager.',
    url: 'https://todoist.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=todoist',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'purple'
  },
  {
    id: '757',
    name: 'TickTick AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the TickTick task manager.',
    url: 'https://ticktick.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ticktick',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'cyan'
  },
  {
    id: '758',
    name: 'Any.do AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into the Any.do task manager.',
    url: 'https://www.any.do/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=anydo',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'purple'
  },
  {
    id: '759',
    name: 'Microsoft To Do AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into Microsoft To Do.',
    url: 'https://todo.microsoft.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=microsofttodo',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'cyan'
  },
  {
    id: '760',
    name: 'Google Tasks AI',
    category: 'Productivity',
    description: 'AI-powered features integrated into Google Tasks.',
    url: 'https://tasks.google.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=googletasks',
    suggested_prompt: 'Use AI to help me organize my work and improve my productivity...',
    color: 'purple'
  },
  {
    id: '761',
    name: 'Trello AI Collaboration',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the Trello project manager.',
    url: 'https://trello.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=trellocollaboration',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '762',
    name: 'Asana AI',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the Asana project manager.',
    url: 'https://asana.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=asana',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '763',
    name: 'Monday.com AI',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the Monday.com project manager.',
    url: 'https://monday.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mondaycom',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '764',
    name: 'ClickUp AI',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the ClickUp project manager.',
    url: 'https://clickup.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=clickup',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '765',
    name: 'Wrike AI',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the Wrike project manager.',
    url: 'https://www.wrike.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wrike',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '766',
    name: 'Airtable AI',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the Airtable platform.',
    url: 'https://www.airtable.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=airtable',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '767',
    name: 'Smartsheet AI',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the Smartsheet platform.',
    url: 'https://www.smartsheet.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=smartsheet',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '768',
    name: 'Basecamp AI',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the Basecamp project manager.',
    url: 'https://basecamp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=basecamp',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '769',
    name: 'Jira AI',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the Jira project manager.',
    url: 'https://www.atlassian.com/software/jira/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=jira',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '770',
    name: 'Confluence AI',
    category: 'Collaboration',
    description: 'AI-powered features integrated into the Confluence workspace.',
    url: 'https://www.atlassian.com/software/confluence/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=confluence',
    suggested_prompt: 'Use AI to help me collaborate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '771',
    name: 'Gmail AI Communication',
    category: 'Communication',
    description: 'AI-powered features integrated into the Gmail email service.',
    url: 'https://mail.google.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gmailcommunication',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '772',
    name: 'Outlook AI',
    category: 'Communication',
    description: 'AI-powered features integrated into the Outlook email service.',
    url: 'https://outlook.microsoft.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=outlook',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '773',
    name: 'ProtonMail AI',
    category: 'Communication',
    description: 'AI-powered features integrated into the ProtonMail email service.',
    url: 'https://proton.me/mail/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=protonmail',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '774',
    name: 'Superhuman AI',
    category: 'Communication',
    description: 'AI-powered features integrated into the Superhuman email client.',
    url: 'https://superhuman.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=superhuman',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '775',
    name: 'Spark AI',
    category: 'Communication',
    description: 'AI-powered features integrated into the Spark email client.',
    url: 'https://sparkmailapp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=spark',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '776',
    name: 'Front AI',
    category: 'Communication',
    description: 'AI-powered features integrated into the Front communication platform.',
    url: 'https://front.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=front',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '777',
    name: 'Intercom AI',
    category: 'Communication',
    description: 'AI-powered features integrated into the Intercom platform.',
    url: 'https://www.intercom.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=intercom',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '778',
    name: 'Zendesk AI',
    category: 'Communication',
    description: 'AI-powered features integrated into the Zendesk platform.',
    url: 'https://www.zendesk.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zendesk',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '779',
    name: 'Salesforce AI',
    category: 'Communication',
    description: 'AI-powered features integrated into the Salesforce platform.',
    url: 'https://www.salesforce.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=salesforce',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'cyan'
  },
  {
    id: '780',
    name: 'HubSpot AI',
    category: 'Communication',
    description: 'AI-powered features integrated into the HubSpot platform.',
    url: 'https://www.hubspot.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hubspot',
    suggested_prompt: 'Use AI to help me communicate with my team and improve our work...',
    color: 'purple'
  },
  {
    id: '781',
    name: 'CrowdStrike AI Security',
    category: 'Security',
    description: 'AI-powered features integrated into the CrowdStrike platform.',
    url: 'https://www.crowdstrike.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=crowdstrikesecurity',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '782',
    name: 'SentinelOne AI',
    category: 'Security',
    description: 'AI-powered features integrated into the SentinelOne platform.',
    url: 'https://www.sentinelone.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sentinelone',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '783',
    name: 'Palo Alto Networks AI',
    category: 'Security',
    description: 'AI-powered features integrated into Palo Alto Networks.',
    url: 'https://www.paloaltonetworks.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=paloaltonetworks',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '784',
    name: 'Fortinet AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Fortinet platform.',
    url: 'https://www.fortinet.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fortinet',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '785',
    name: 'Check Point AI',
    category: 'Security',
    description: 'AI-powered features integrated into Check Point.',
    url: 'https://www.checkpoint.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=checkpoint',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '786',
    name: 'Cisco AI Security',
    category: 'Security',
    description: 'AI-powered features integrated into Cisco security products.',
    url: 'https://www.cisco.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ciscosecurity',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '787',
    name: 'Zscaler AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Zscaler platform.',
    url: 'https://www.zscaler.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zscaler',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '788',
    name: 'Okta AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Okta platform.',
    url: 'https://www.okta.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=okta',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '789',
    name: 'Cloudflare AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Cloudflare platform.',
    url: 'https://www.cloudflare.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cloudflare',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '790',
    name: 'Akamai AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Akamai platform.',
    url: 'https://www.akamai.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=akamai',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '791',
    name: 'Tenable AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Tenable platform.',
    url: 'https://www.tenable.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tenable',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '792',
    name: 'Rapid7 AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Rapid7 platform.',
    url: 'https://www.rapid7.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rapid7',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '793',
    name: 'Qualys AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Qualys platform.',
    url: 'https://www.qualys.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=qualys',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '794',
    name: 'Splunk AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Splunk platform.',
    url: 'https://www.splunk.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=splunk',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '795',
    name: 'Elastic AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Elastic platform.',
    url: 'https://www.elastic.co/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=elastic',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '796',
    name: 'Datadog AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Datadog platform.',
    url: 'https://www.datadoghq.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=datadog',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '797',
    name: 'New Relic AI',
    category: 'Security',
    description: 'AI-powered features integrated into the New Relic platform.',
    url: 'https://newrelic.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=newrelic',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '798',
    name: 'Dynatrace AI',
    category: 'Security',
    description: 'AI-powered features integrated into the Dynatrace platform.',
    url: 'https://www.dynatrace.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=dynatrace',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '799',
    name: 'AppDynamics AI',
    category: 'Security',
    description: 'AI-powered features integrated into the AppDynamics platform.',
    url: 'https://www.appdynamics.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=appdynamics',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'cyan'
  },
  {
    id: '800',
    name: 'SolarWinds AI',
    category: 'Security',
    description: 'AI-powered features integrated into the SolarWinds platform.',
    url: 'https://www.solarwinds.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=solarwinds',
    suggested_prompt: 'Use AI to help me secure my systems and improve my security...',
    color: 'purple'
  },
  {
    id: '801',
    name: 'Google Analytics AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into Google Analytics.',
    url: 'https://analytics.google.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=googleanalytics',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'cyan'
  },
  {
    id: '802',
    name: 'Mixpanel AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into the Mixpanel platform.',
    url: 'https://mixpanel.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mixpanel',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'purple'
  },
  {
    id: '803',
    name: 'Amplitude AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into the Amplitude platform.',
    url: 'https://amplitude.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=amplitude',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'cyan'
  },
  {
    id: '804',
    name: 'Segment AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into the Segment platform.',
    url: 'https://segment.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=segment',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'purple'
  },
  {
    id: '805',
    name: 'Heap AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into the Heap platform.',
    url: 'https://heap.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=heap',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'cyan'
  },
  {
    id: '806',
    name: 'FullStory AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into the FullStory platform.',
    url: 'https://www.fullstory.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fullstory',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'purple'
  },
  {
    id: '807',
    name: 'Hotjar AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into the Hotjar platform.',
    url: 'https://www.hotjar.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hotjar',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'cyan'
  },
  {
    id: '808',
    name: 'Crazy Egg AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into the Crazy Egg platform.',
    url: 'https://www.crazyegg.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=crazyegg',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'purple'
  },
  {
    id: '809',
    name: 'Optimizely AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into the Optimizely platform.',
    url: 'https://www.optimizely.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=optimizely',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'cyan'
  },
  {
    id: '810',
    name: 'VWO AI',
    category: 'Analytics',
    description: 'AI-powered features integrated into the VWO platform.',
    url: 'https://vwo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=vwo',
    suggested_prompt: 'Use AI to help me analyze my data and improve my business...',
    color: 'purple'
  },
  {
    id: '811',
    name: 'Mailchimp AI Marketing',
    category: 'Marketing',
    description: 'AI-powered features integrated into the Mailchimp platform.',
    url: 'https://mailchimp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mailchimpmarketing',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'cyan'
  },
  {
    id: '812',
    name: 'Constant Contact AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into Constant Contact.',
    url: 'https://www.constantcontact.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=constantcontact',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'purple'
  },
  {
    id: '813',
    name: 'ActiveCampaign AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into ActiveCampaign.',
    url: 'https://www.activecampaign.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=activecampaign',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'cyan'
  },
  {
    id: '814',
    name: 'SendGrid AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into the SendGrid platform.',
    url: 'https://sendgrid.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sendgrid',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'purple'
  },
  {
    id: '815',
    name: 'Twilio AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into the Twilio platform.',
    url: 'https://www.twilio.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=twilio',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'cyan'
  },
  {
    id: '816',
    name: 'Braze AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into the Braze platform.',
    url: 'https://www.braze.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=braze',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'purple'
  },
  {
    id: '817',
    name: 'Iterable AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into the Iterable platform.',
    url: 'https://iterable.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=iterable',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'cyan'
  },
  {
    id: '818',
    name: 'Klaviyo AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into the Klaviyo platform.',
    url: 'https://www.klaviyo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=klaviyo',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'purple'
  },
  {
    id: '819',
    name: 'Marketo AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into the Marketo platform.',
    url: 'https://www.marketo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=marketo',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'cyan'
  },
  {
    id: '820',
    name: 'Pardot AI',
    category: 'Marketing',
    description: 'AI-powered features integrated into the Pardot platform.',
    url: 'https://www.pardot.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pardot',
    suggested_prompt: 'Use AI to help me market my business and improve my reach...',
    color: 'purple'
  },
  {
    id: '821',
    name: 'Outreach AI Sales',
    category: 'Sales',
    description: 'AI-powered features integrated into the Outreach platform.',
    url: 'https://www.outreach.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=outreachsales',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'cyan'
  },
  {
    id: '822',
    name: 'Salesloft AI',
    category: 'Sales',
    description: 'AI-powered features integrated into the Salesloft platform.',
    url: 'https://salesloft.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=salesloft',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'purple'
  },
  {
    id: '823',
    name: 'Gong AI',
    category: 'Sales',
    description: 'AI-powered features integrated into the Gong platform.',
    url: 'https://www.gong.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gong',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'cyan'
  },
  {
    id: '824',
    name: 'Chorus.ai',
    category: 'Sales',
    description: 'AI-powered features integrated into the Chorus.ai platform.',
    url: 'https://www.chorus.ai/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=chorusai',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'purple'
  },
  {
    id: '825',
    name: 'ZoomInfo AI',
    category: 'Sales',
    description: 'AI-powered features integrated into the ZoomInfo platform.',
    url: 'https://www.zoominfo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zoominfo',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'cyan'
  },
  {
    id: '826',
    name: 'Apollo.io AI',
    category: 'Sales',
    description: 'AI-powered features integrated into the Apollo.io platform.',
    url: 'https://www.apollo.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=apolloio',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'purple'
  },
  {
    id: '827',
    name: 'Lusha AI',
    category: 'Sales',
    description: 'AI-powered features integrated into the Lusha platform.',
    url: 'https://www.lusha.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lusha',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'cyan'
  },
  {
    id: '828',
    name: 'Hunter.io AI',
    category: 'Sales',
    description: 'AI-powered features integrated into the Hunter.io platform.',
    url: 'https://hunter.io/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hunterio',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'purple'
  },
  {
    id: '829',
    name: 'Clearbit AI',
    category: 'Sales',
    description: 'AI-powered features integrated into the Clearbit platform.',
    url: 'https://clearbit.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=clearbit',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'cyan'
  },
  {
    id: '830',
    name: 'DiscoverOrg AI',
    category: 'Sales',
    description: 'AI-powered features integrated into the DiscoverOrg platform.',
    url: 'https://discoverorg.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=discoverorg',
    suggested_prompt: 'Use AI to help me sell my products and improve my reach...',
    color: 'purple'
  },
  {
    id: '831',
    name: 'LinkedIn Recruiter AI',
    category: 'HR',
    description: 'AI-powered features integrated into LinkedIn Recruiter.',
    url: 'https://www.linkedin.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=linkedinrecruiter',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '832',
    name: 'Indeed AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Indeed platform.',
    url: 'https://www.indeed.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=indeedhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '833',
    name: 'Glassdoor AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Glassdoor platform.',
    url: 'https://www.glassdoor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=glassdoorhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '834',
    name: 'ZipRecruiter AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into ZipRecruiter.',
    url: 'https://www.ziprecruiter.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ziprecruiterhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '835',
    name: 'Monster AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Monster platform.',
    url: 'https://www.monster.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=monsterhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '836',
    name: 'CareerBuilder AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into CareerBuilder.',
    url: 'https://www.careerbuilder.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=careerbuilderhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '837',
    name: 'Workday AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Workday platform.',
    url: 'https://www.workday.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=workdayhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '838',
    name: 'Oracle HCM AI',
    category: 'HR',
    description: 'AI-powered features integrated into Oracle HCM.',
    url: 'https://www.oracle.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=oraclehcm',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '839',
    name: 'SAP SuccessFactors AI',
    category: 'HR',
    description: 'AI-powered features integrated into SAP SuccessFactors.',
    url: 'https://www.sap.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sapsuccessfactors',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '840',
    name: 'ADP AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the ADP platform.',
    url: 'https://www.adp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=adphr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '841',
    name: 'BambooHR AI',
    category: 'HR',
    description: 'AI-powered features integrated into the BambooHR platform.',
    url: 'https://www.bamboohr.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bamboohr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '842',
    name: 'Gusto AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Gusto platform.',
    url: 'https://gusto.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gustohr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '843',
    name: 'Zenefits AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Zenefits platform.',
    url: 'https://www.zenefits.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zenefitshr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '844',
    name: 'Paychex AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Paychex platform.',
    url: 'https://www.paychex.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=paychexhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '845',
    name: 'Paycom AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Paycom platform.',
    url: 'https://www.paycom.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=paycomhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '846',
    name: 'Paylocity AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Paylocity platform.',
    url: 'https://www.paylocity.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=paylocityhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '847',
    name: 'Ceridian AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Ceridian platform.',
    url: 'https://www.ceridian.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ceridianhr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '848',
    name: 'Kronos AI HR',
    category: 'HR',
    description: 'AI-powered features integrated into the Kronos platform.',
    url: 'https://www.kronos.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kronoshr',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '849',
    name: 'Ultimate Software AI',
    category: 'HR',
    description: 'AI-powered features integrated into Ultimate Software.',
    url: 'https://www.ultimatesoftware.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ultimatesoftware',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'cyan'
  },
  {
    id: '850',
    name: 'Cornerstone OnDemand AI',
    category: 'HR',
    description: 'AI-powered features integrated into Cornerstone OnDemand.',
    url: 'https://www.cornerstoneondemand.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cornerstoneondemand',
    suggested_prompt: 'Use AI to help me find the right candidates and improve my HR...',
    color: 'purple'
  },
  {
    id: '851',
    name: 'LexisNexis AI Legal',
    category: 'Legal',
    description: 'AI-powered features integrated into the LexisNexis platform.',
    url: 'https://www.lexisnexis.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lexisnexislegal',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'cyan'
  },
  {
    id: '852',
    name: 'Westlaw AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Westlaw platform.',
    url: 'https://legal.thomsonreuters.com/en/products/westlaw/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=westlaw',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'purple'
  },
  {
    id: '853',
    name: 'Bloomberg Law AI',
    category: 'Legal',
    description: 'AI-powered features integrated into Bloomberg Law.',
    url: 'https://www.bloomberglaw.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bloomberglaw',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'cyan'
  },
  {
    id: '854',
    name: 'Fastcase AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Fastcase platform.',
    url: 'https://www.fastcase.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fastcase',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'purple'
  },
  {
    id: '855',
    name: 'Casetext AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Casetext platform.',
    url: 'https://casetext.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=casetext',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'cyan'
  },
  {
    id: '856',
    name: 'Ross Intelligence AI',
    category: 'Legal',
    description: 'AI-powered features integrated into Ross Intelligence.',
    url: 'https://www.rossintelligence.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rossintelligence',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'purple'
  },
  {
    id: '857',
    name: 'Luminance AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Luminance platform.',
    url: 'https://www.luminance.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=luminance',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'cyan'
  },
  {
    id: '858',
    name: 'Kira Systems AI',
    category: 'Legal',
    description: 'AI-powered features integrated into Kira Systems.',
    url: 'https://kirasystems.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kirasystems',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'purple'
  },
  {
    id: '859',
    name: 'LawGeex AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the LawGeex platform.',
    url: 'https://www.lawgeex.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lawgeex',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'cyan'
  },
  {
    id: '860',
    name: 'Ironclad AI',
    category: 'Legal',
    description: 'AI-powered features integrated into the Ironclad platform.',
    url: 'https://ironcladapp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=ironclad',
    suggested_prompt: 'Use AI to help me research legal cases and improve my work...',
    color: 'purple'
  },
  {
    id: '861',
    name: 'Bloomberg Terminal AI Finance',
    category: 'Finance',
    description: 'AI-powered features integrated into the Bloomberg Terminal.',
    url: 'https://www.bloomberg.com/professional/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bloombergterminalfinance',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'cyan'
  },
  {
    id: '862',
    name: 'FactSet AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the FactSet platform.',
    url: 'https://www.factset.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=factset',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'purple'
  },
  {
    id: '863',
    name: 'Refinitiv AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Refinitiv platform.',
    url: 'https://www.refinitiv.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=refinitiv',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'cyan'
  },
  {
    id: '864',
    name: 'Morningstar AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the Morningstar platform.',
    url: 'https://www.morningstar.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=morningstar',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'purple'
  },
  {
    id: '865',
    name: 'S&P Global AI',
    category: 'Finance',
    description: 'AI-powered features integrated into S&P Global.',
    url: 'https://www.spglobal.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=spglobal',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'cyan'
  },
  {
    id: '866',
    name: 'Moody\'s AI',
    category: 'Finance',
    description: 'AI-powered features integrated into Moody\'s.',
    url: 'https://www.moodys.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=moodys',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'purple'
  },
  {
    id: '867',
    name: 'MSCI AI',
    category: 'Finance',
    description: 'AI-powered features integrated into the MSCI platform.',
    url: 'https://www.msci.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=msci',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'cyan'
  },
  {
    id: '868',
    name: 'BlackRock Aladdin AI',
    category: 'Finance',
    description: 'AI-powered features integrated into BlackRock Aladdin.',
    url: 'https://www.blackrock.com/aladdin/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=blackrockaladdin',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'purple'
  },
  {
    id: '869',
    name: 'Goldman Sachs Marquee AI',
    category: 'Finance',
    description: 'AI-powered features integrated into Goldman Sachs Marquee.',
    url: 'https://www.goldmansachs.com/marquee/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=goldmansachsmarquee',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'cyan'
  },
  {
    id: '870',
    name: 'J.P. Morgan Athena AI',
    category: 'Finance',
    description: 'AI-powered features integrated into J.P. Morgan Athena.',
    url: 'https://www.jpmorgan.com/athena/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=jpmorganathena',
    suggested_prompt: 'Use AI to help me analyze financial data and improve my work...',
    color: 'purple'
  },
  {
    id: '871',
    name: 'Zillow AI Real Estate',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Zillow platform.',
    url: 'https://www.zillow.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=zillowrealestate',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'cyan'
  },
  {
    id: '872',
    name: 'Redfin AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Redfin platform.',
    url: 'https://www.redfin.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=redfin',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'purple'
  },
  {
    id: '873',
    name: 'Realtor.com AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into Realtor.com.',
    url: 'https://www.realtor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=realtorcom',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'cyan'
  },
  {
    id: '874',
    name: 'Trulia AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Trulia platform.',
    url: 'https://www.trulia.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=trulia',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'purple'
  },
  {
    id: '875',
    name: 'Compass AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Compass platform.',
    url: 'https://www.compass.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=compass',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'cyan'
  },
  {
    id: '876',
    name: 'Opendoor AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Opendoor platform.',
    url: 'https://www.opendoor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=opendoor',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'purple'
  },
  {
    id: '877',
    name: 'Offerpad AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Offerpad platform.',
    url: 'https://www.offerpad.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=offerpad',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'cyan'
  },
  {
    id: '878',
    name: 'CoStar AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the CoStar platform.',
    url: 'https://www.costar.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=costar',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'purple'
  },
  {
    id: '879',
    name: 'LoopNet AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the LoopNet platform.',
    url: 'https://www.loopnet.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=loopnet',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'cyan'
  },
  {
    id: '880',
    name: 'Crexi AI',
    category: 'Real Estate',
    description: 'AI-powered features integrated into the Crexi platform.',
    url: 'https://www.crexi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=crexi',
    suggested_prompt: 'Use AI to help me find the right property and improve my work...',
    color: 'purple'
  },
  {
    id: '881',
    name: 'Coursera AI Education',
    category: 'Education',
    description: 'AI-powered features integrated into the Coursera platform.',
    url: 'https://www.coursera.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=courseraeducation',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '882',
    name: 'edX AI',
    category: 'Education',
    description: 'AI-powered features integrated into the edX platform.',
    url: 'https://www.edx.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=edx',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '883',
    name: 'Udacity AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Udacity platform.',
    url: 'https://www.udacity.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=udacity',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '884',
    name: 'Pluralsight AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Pluralsight platform.',
    url: 'https://www.pluralsight.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=pluralsight',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '885',
    name: 'LinkedIn Learning AI',
    category: 'Education',
    description: 'AI-powered features integrated into LinkedIn Learning.',
    url: 'https://www.linkedin.com/learning/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=linkedinlearning',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '886',
    name: 'Khan Academy AI',
    category: 'Education',
    description: 'AI-powered features integrated into Khan Academy.',
    url: 'https://www.khanacademy.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=khanacademy',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '887',
    name: 'Duolingo AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Duolingo platform.',
    url: 'https://www.duolingo.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=duolingo',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '888',
    name: 'Babbel AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Babbel platform.',
    url: 'https://www.babbel.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=babbel',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '889',
    name: 'Rosetta Stone AI',
    category: 'Education',
    description: 'AI-powered features integrated into Rosetta Stone.',
    url: 'https://www.rosettastone.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rosettastone',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '890',
    name: 'Memrise AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Memrise platform.',
    url: 'https://www.memrise.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=memrise',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '891',
    name: 'Skillshare AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Skillshare platform.',
    url: 'https://www.skillshare.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=skillshare',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '892',
    name: 'Udemy AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Udemy platform.',
    url: 'https://www.udemy.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=udemy',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '893',
    name: 'MasterClass AI',
    category: 'Education',
    description: 'AI-powered features integrated into the MasterClass platform.',
    url: 'https://www.masterclass.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=masterclass',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '894',
    name: 'CreativeLive AI',
    category: 'Education',
    description: 'AI-powered features integrated into the CreativeLive platform.',
    url: 'https://www.creativelive.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=creativelive',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '895',
    name: 'Teachable AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Teachable platform.',
    url: 'https://teachable.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=teachable',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '896',
    name: 'Thinkific AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Thinkific platform.',
    url: 'https://www.thinkific.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=thinkific',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '897',
    name: 'Kajabi AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Kajabi platform.',
    url: 'https://kajabi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kajabi',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '898',
    name: 'Podia AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Podia platform.',
    url: 'https://www.podia.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=podia',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '899',
    name: 'Gumroad AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Gumroad platform.',
    url: 'https://gumroad.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gumroad',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'cyan'
  },
  {
    id: '900',
    name: 'Patreon AI',
    category: 'Education',
    description: 'AI-powered features integrated into the Patreon platform.',
    url: 'https://www.patreon.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=patreon',
    suggested_prompt: 'Use AI to help me learn new skills and improve my work...',
    color: 'purple'
  },
  {
    id: '901',
    name: 'Expedia AI Travel',
    category: 'Travel',
    description: 'AI-powered features integrated into the Expedia platform.',
    url: 'https://www.expedia.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=expediatravel',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'cyan'
  },
  {
    id: '902',
    name: 'Booking.com AI',
    category: 'Travel',
    description: 'AI-powered features integrated into Booking.com.',
    url: 'https://www.booking.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bookingcom',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'purple'
  },
  {
    id: '903',
    name: 'Airbnb AI Travel',
    category: 'Travel',
    description: 'AI-powered features integrated into the Airbnb platform.',
    url: 'https://www.airbnb.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=airbnbtravel',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'cyan'
  },
  {
    id: '904',
    name: 'TripAdvisor AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the TripAdvisor platform.',
    url: 'https://www.tripadvisor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=tripadvisor',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'purple'
  },
  {
    id: '905',
    name: 'Kayak AI Travel',
    category: 'Travel',
    description: 'AI-powered features integrated into the Kayak platform.',
    url: 'https://www.kayak.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kayaktravel',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'cyan'
  },
  {
    id: '906',
    name: 'Skyscanner AI',
    category: 'Travel',
    description: 'AI-powered features integrated into the Skyscanner platform.',
    url: 'https://www.skyscanner.net/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=skyscanner',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'purple'
  },
  {
    id: '907',
    name: 'Hopper AI Travel',
    category: 'Travel',
    description: 'AI-powered features integrated into the Hopper platform.',
    url: 'https://www.hopper.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hoppertravel',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'cyan'
  },
  {
    id: '908',
    name: 'Klook AI Travel',
    category: 'Travel',
    description: 'AI-powered features integrated into the Klook platform.',
    url: 'https://www.klook.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=klooktravel',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'purple'
  },
  {
    id: '909',
    name: 'GetYourGuide AI',
    category: 'Travel',
    description: 'AI-powered features integrated into GetYourGuide.',
    url: 'https://www.getyourguide.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=getyourguide',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'cyan'
  },
  {
    id: '910',
    name: 'Viator AI Travel',
    category: 'Travel',
    description: 'AI-powered features integrated into the Viator platform.',
    url: 'https://www.viator.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=viator',
    suggested_prompt: 'Use AI to help me plan my travel and improve my work...',
    color: 'purple'
  },
  {
    id: '911',
    name: 'FedEx AI Logistics',
    category: 'Logistics',
    description: 'AI-powered features integrated into the FedEx platform.',
    url: 'https://www.fedex.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fedexlogistics',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'cyan'
  },
  {
    id: '912',
    name: 'UPS AI Logistics',
    category: 'Logistics',
    description: 'AI-powered features integrated into the UPS platform.',
    url: 'https://www.ups.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=upslogistics',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'purple'
  },
  {
    id: '913',
    name: 'DHL AI Logistics',
    category: 'Logistics',
    description: 'AI-powered features integrated into the DHL platform.',
    url: 'https://www.dhl.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=dhllogistics',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'cyan'
  },
  {
    id: '914',
    name: 'Maersk AI Logistics',
    category: 'Logistics',
    description: 'AI-powered features integrated into the Maersk platform.',
    url: 'https://www.maersk.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=maersklogistics',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'purple'
  },
  {
    id: '915',
    name: 'Hapag-Lloyd AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into Hapag-Lloyd.',
    url: 'https://www.hapag-lloyd.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hapaglloyd',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'cyan'
  },
  {
    id: '916',
    name: 'MSC AI Logistics',
    category: 'Logistics',
    description: 'AI-powered features integrated into the MSC platform.',
    url: 'https://www.msc.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=msclogistics',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'purple'
  },
  {
    id: '917',
    name: 'CMA CGM AI Logistics',
    category: 'Logistics',
    description: 'AI-powered features integrated into CMA CGM.',
    url: 'https://www.cma-cgm.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cmacgm',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'cyan'
  },
  {
    id: '918',
    name: 'Kuehne + Nagel AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into Kuehne + Nagel.',
    url: 'https://www.kn-portal.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kuehnenagel',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'purple'
  },
  {
    id: '919',
    name: 'DSV AI Logistics',
    category: 'Logistics',
    description: 'AI-powered features integrated into the DSV platform.',
    url: 'https://www.dsv.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=dsvlogistics',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'cyan'
  },
  {
    id: '920',
    name: 'DB Schenker AI',
    category: 'Logistics',
    description: 'AI-powered features integrated into DB Schenker.',
    url: 'https://www.dbschenker.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=dbschenker',
    suggested_prompt: 'Use AI to help me manage my logistics and improve my work...',
    color: 'purple'
  },
  {
    id: '921',
    name: 'Shell AI Energy',
    category: 'Energy',
    description: 'AI-powered features integrated into the Shell platform.',
    url: 'https://www.shell.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=shellenergy',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'cyan'
  },
  {
    id: '922',
    name: 'BP AI Energy',
    category: 'Energy',
    description: 'AI-powered features integrated into the BP platform.',
    url: 'https://www.bp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bpenergy',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'purple'
  },
  {
    id: '923',
    name: 'ExxonMobil AI Energy',
    category: 'Energy',
    description: 'AI-powered features integrated into ExxonMobil.',
    url: 'https://www.exxonmobil.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=exxonmobil',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'cyan'
  },
  {
    id: '924',
    name: 'Chevron AI Energy',
    category: 'Energy',
    description: 'AI-powered features integrated into the Chevron platform.',
    url: 'https://www.chevron.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=chevronenergy',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'purple'
  },
  {
    id: '925',
    name: 'TotalEnergies AI',
    category: 'Energy',
    description: 'AI-powered features integrated into TotalEnergies.',
    url: 'https://totalenergies.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=totalenergies',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'cyan'
  },
  {
    id: '926',
    name: 'Eni AI Energy',
    category: 'Energy',
    description: 'AI-powered features integrated into the Eni platform.',
    url: 'https://www.eni.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=enienergy',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'purple'
  },
  {
    id: '927',
    name: 'Equinor AI Energy',
    category: 'Energy',
    description: 'AI-powered features integrated into the Equinor platform.',
    url: 'https://www.equinor.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=equinorenergy',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'cyan'
  },
  {
    id: '928',
    name: 'Repsol AI Energy',
    category: 'Energy',
    description: 'AI-powered features integrated into the Repsol platform.',
    url: 'https://www.repsol.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=repsolenergy',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'purple'
  },
  {
    id: '929',
    name: 'OMV AI Energy',
    category: 'Energy',
    description: 'AI-powered features integrated into the OMV platform.',
    url: 'https://www.omv.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=omvenergy',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'cyan'
  },
  {
    id: '930',
    name: 'Galp AI Energy',
    category: 'Energy',
    description: 'AI-powered features integrated into the Galp platform.',
    url: 'https://www.galp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=galpenergy',
    suggested_prompt: 'Use AI to help me manage my energy and improve my work...',
    color: 'purple'
  },
  {
    id: '931',
    name: 'John Deere AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into John Deere equipment.',
    url: 'https://www.deere.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=johndeere',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'cyan'
  },
  {
    id: '932',
    name: 'CNH Industrial AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into CNH Industrial equipment.',
    url: 'https://www.cnhindustrial.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cnhindustrial',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'purple'
  },
  {
    id: '933',
    name: 'AGCO AI Agriculture',
    category: 'Agriculture',
    description: 'AI-powered features integrated into AGCO equipment.',
    url: 'https://www.agcocorp.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=agcoagriculture',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'cyan'
  },
  {
    id: '934',
    name: 'Kubota AI Agriculture',
    category: 'Agriculture',
    description: 'AI-powered features integrated into Kubota equipment.',
    url: 'https://www.kubota.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kubotaagriculture',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'purple'
  },
  {
    id: '935',
    name: 'Mahindra AI Agriculture',
    category: 'Agriculture',
    description: 'AI-powered features integrated into Mahindra equipment.',
    url: 'https://www.mahindra.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mahindraagriculture',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'cyan'
  },
  {
    id: '936',
    name: 'CLAAS AI Agriculture',
    category: 'Agriculture',
    description: 'AI-powered features integrated into CLAAS equipment.',
    url: 'https://www.claas.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=claasagriculture',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'purple'
  },
  {
    id: '937',
    name: 'Deutz-Fahr AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into Deutz-Fahr equipment.',
    url: 'https://www.deutz-fahr.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=deutzfahr',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'cyan'
  },
  {
    id: '938',
    name: 'Massey Ferguson AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into Massey Ferguson equipment.',
    url: 'https://www.masseyferguson.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=masseyferguson',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'purple'
  },
  {
    id: '939',
    name: 'New Holland AI',
    category: 'Agriculture',
    description: 'AI-powered features integrated into New Holland equipment.',
    url: 'https://agriculture.newholland.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=newholland',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'cyan'
  },
  {
    id: '940',
    name: 'Fendt AI Agriculture',
    category: 'Agriculture',
    description: 'AI-powered features integrated into Fendt equipment.',
    url: 'https://www.fendt.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fendtagriculture',
    suggested_prompt: 'Use AI to help me manage my agriculture and improve my work...',
    color: 'purple'
  },
  {
    id: '941',
    name: 'Siemens AI Manufacturing',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into Siemens manufacturing solutions.',
    url: 'https://www.siemens.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=siemensmanufacturing',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'cyan'
  },
  {
    id: '942',
    name: 'GE AI Manufacturing',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into GE manufacturing solutions.',
    url: 'https://www.ge.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gemanufacturing',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'purple'
  },
  {
    id: '943',
    name: 'ABB AI Manufacturing',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into ABB manufacturing solutions.',
    url: 'https://new.abb.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=abbmanufacturing',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'cyan'
  },
  {
    id: '944',
    name: 'Schneider Electric AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into Schneider Electric solutions.',
    url: 'https://www.se.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=schneiderelectric',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'purple'
  },
  {
    id: '945',
    name: 'Honeywell AI Manufacturing',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into Honeywell solutions.',
    url: 'https://www.honeywell.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=honeywellmanufacturing',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'cyan'
  },
  {
    id: '946',
    name: 'Rockwell Automation AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into Rockwell Automation.',
    url: 'https://www.rockwellautomation.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rockwellautomation',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'purple'
  },
  {
    id: '947',
    name: 'Emerson AI Manufacturing',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into Emerson solutions.',
    url: 'https://www.emerson.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=emersonmanufacturing',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'cyan'
  },
  {
    id: '948',
    name: 'Mitsubishi Electric AI',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into Mitsubishi Electric.',
    url: 'https://www.mitsubishielectric.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mitsubishielectric',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'purple'
  },
  {
    id: '949',
    name: 'Fanuc AI Manufacturing',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into Fanuc solutions.',
    url: 'https://www.fanuc.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fanucmanufacturing',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'cyan'
  },
  {
    id: '950',
    name: 'Yaskawa AI Manufacturing',
    category: 'Manufacturing',
    description: 'AI-powered features integrated into Yaskawa solutions.',
    url: 'https://www.yaskawa.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=yaskawamanufacturing',
    suggested_prompt: 'Use AI to help me manage my manufacturing and improve my work...',
    color: 'purple'
  },
  {
    id: '951',
    name: 'Walmart AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Walmart platform.',
    url: 'https://www.walmart.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=walmartretail',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'cyan'
  },
  {
    id: '952',
    name: 'Amazon AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Amazon platform.',
    url: 'https://www.amazon.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=amazonretail',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'purple'
  },
  {
    id: '953',
    name: 'Target AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Target platform.',
    url: 'https://www.target.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=targetretail',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'cyan'
  },
  {
    id: '954',
    name: 'Costco AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Costco platform.',
    url: 'https://www.costco.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=costcoretail',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'purple'
  },
  {
    id: '955',
    name: 'Kroger AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Kroger platform.',
    url: 'https://www.kroger.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=krogerretail',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'cyan'
  },
  {
    id: '956',
    name: 'Walgreens AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the Walgreens platform.',
    url: 'https://www.walgreens.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=walgreensretail',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'purple'
  },
  {
    id: '957',
    name: 'CVS AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into the CVS platform.',
    url: 'https://www.cvs.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=cvsretail',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'cyan'
  },
  {
    id: '958',
    name: 'Home Depot AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into Home Depot.',
    url: 'https://www.homedepot.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=homedepot',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'purple'
  },
  {
    id: '959',
    name: 'Lowe\'s AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into Lowe\'s.',
    url: 'https://www.lowes.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lowesretail',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'cyan'
  },
  {
    id: '960',
    name: 'Best Buy AI Retail',
    category: 'Retail',
    description: 'AI-powered features integrated into Best Buy.',
    url: 'https://www.bestbuy.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bestbuyretail',
    suggested_prompt: 'Use AI to help me manage my retail and improve my work...',
    color: 'purple'
  },
  {
    id: '961',
    name: 'Tesla AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Tesla vehicles.',
    url: 'https://www.tesla.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=teslaautomotive',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'cyan'
  },
  {
    id: '962',
    name: 'Ford AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Ford vehicles.',
    url: 'https://www.ford.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fordautomotive',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'purple'
  },
  {
    id: '963',
    name: 'GM AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into GM vehicles.',
    url: 'https://www.gm.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=gmautomotive',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'cyan'
  },
  {
    id: '964',
    name: 'Toyota AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Toyota vehicles.',
    url: 'https://www.toyota.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=toyotaautomotive',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'purple'
  },
  {
    id: '965',
    name: 'Honda AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Honda vehicles.',
    url: 'https://www.honda.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=hondaautomotive',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'cyan'
  },
  {
    id: '966',
    name: 'Volkswagen AI',
    category: 'Automotive',
    description: 'AI-powered features integrated into Volkswagen vehicles.',
    url: 'https://www.volkswagen.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=volkswagen',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'purple'
  },
  {
    id: '967',
    name: 'BMW AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into BMW vehicles.',
    url: 'https://www.bmw.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bmwautomotive',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'cyan'
  },
  {
    id: '968',
    name: 'Mercedes-Benz AI',
    category: 'Automotive',
    description: 'AI-powered features integrated into Mercedes-Benz vehicles.',
    url: 'https://www.mercedes-benz.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=mercedesbenz',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'purple'
  },
  {
    id: '969',
    name: 'Audi AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Audi vehicles.',
    url: 'https://www.audi.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=audiautomotive',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'cyan'
  },
  {
    id: '970',
    name: 'Porsche AI Automotive',
    category: 'Automotive',
    description: 'AI-powered features integrated into Porsche vehicles.',
    url: 'https://www.porsche.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=porscheautomotive',
    suggested_prompt: 'Use AI to help me manage my automotive and improve my work...',
    color: 'purple'
  },
  {
    id: '971',
    name: 'NASA AI Space',
    category: 'Space',
    description: 'AI-powered features integrated into NASA missions.',
    url: 'https://www.nasa.gov/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nasaspace',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'cyan'
  },
  {
    id: '972',
    name: 'SpaceX AI Space',
    category: 'Space',
    description: 'AI-powered features integrated into SpaceX missions.',
    url: 'https://www.spacex.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=spacexspace',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'purple'
  },
  {
    id: '973',
    name: 'Blue Origin AI Space',
    category: 'Space',
    description: 'AI-powered features integrated into Blue Origin missions.',
    url: 'https://www.blueorigin.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=blueoriginspace',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'cyan'
  },
  {
    id: '974',
    name: 'Virgin Galactic AI',
    category: 'Space',
    description: 'AI-powered features integrated into Virgin Galactic.',
    url: 'https://www.virgingalactic.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=virgingalactic',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'purple'
  },
  {
    id: '975',
    name: 'Lockheed Martin AI',
    category: 'Space',
    description: 'AI-powered features integrated into Lockheed Martin.',
    url: 'https://www.lockheedmartin.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=lockheedmartin',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'cyan'
  },
  {
    id: '976',
    name: 'Northrop Grumman AI',
    category: 'Space',
    description: 'AI-powered features integrated into Northrop Grumman.',
    url: 'https://www.northropgrumman.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=northropgrumman',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'purple'
  },
  {
    id: '977',
    name: 'Boeing AI Space',
    category: 'Space',
    description: 'AI-powered features integrated into Boeing missions.',
    url: 'https://www.boeing.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=boeingspace',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'cyan'
  },
  {
    id: '978',
    name: 'Airbus AI Space',
    category: 'Space',
    description: 'AI-powered features integrated into Airbus missions.',
    url: 'https://www.airbus.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=airbusspace',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'purple'
  },
  {
    id: '979',
    name: 'Raytheon AI Space',
    category: 'Space',
    description: 'AI-powered features integrated into Raytheon missions.',
    url: 'https://www.rtx.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=raytheonspace',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'cyan'
  },
  {
    id: '980',
    name: 'General Dynamics AI',
    category: 'Space',
    description: 'AI-powered features integrated into General Dynamics.',
    url: 'https://www.gd.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=generaldynamics',
    suggested_prompt: 'Use AI to help me manage my space and improve my work...',
    color: 'purple'
  },
  {
    id: '981',
    name: 'Boston Dynamics AI',
    category: 'Robotics',
    description: 'AI-powered features integrated into Boston Dynamics robots.',
    url: 'https://www.bostondynamics.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=bostondynamics',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'cyan'
  },
  {
    id: '982',
    name: 'SoftBank Robotics AI',
    category: 'Robotics',
    description: 'AI-powered features integrated into SoftBank Robotics.',
    url: 'https://www.softbankrobotics.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=softbankrobotics',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'purple'
  },
  {
    id: '983',
    name: 'iRobot AI Robotics',
    category: 'Robotics',
    description: 'AI-powered features integrated into iRobot products.',
    url: 'https://www.irobot.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=irobotrobotics',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'cyan'
  },
  {
    id: '984',
    name: 'Intuitive Surgical AI',
    category: 'Robotics',
    description: 'AI-powered features integrated into Intuitive Surgical.',
    url: 'https://www.intuitive.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=intuitivesurgical',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'purple'
  },
  {
    id: '985',
    name: 'Teradyne AI Robotics',
    category: 'Robotics',
    description: 'AI-powered features integrated into Teradyne products.',
    url: 'https://www.teradyne.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=teradynerobotics',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'cyan'
  },
  {
    id: '986',
    name: 'Kuka AI Robotics',
    category: 'Robotics',
    description: 'AI-powered features integrated into Kuka robots.',
    url: 'https://www.kuka.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kukarobotics',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'purple'
  },
  {
    id: '987',
    name: 'Fanuc AI Robotics',
    category: 'Robotics',
    description: 'AI-powered features integrated into Fanuc robots.',
    url: 'https://www.fanuc.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=fanucrobotics',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'cyan'
  },
  {
    id: '988',
    name: 'Yaskawa AI Robotics',
    category: 'Robotics',
    description: 'AI-powered features integrated into Yaskawa robots.',
    url: 'https://www.yaskawa.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=yaskawarobotics',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'purple'
  },
  {
    id: '989',
    name: 'ABB AI Robotics',
    category: 'Robotics',
    description: 'AI-powered features integrated into ABB robots.',
    url: 'https://new.abb.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=abbrobotics',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'cyan'
  },
  {
    id: '990',
    name: 'Kawasaki AI Robotics',
    category: 'Robotics',
    description: 'AI-powered features integrated into Kawasaki robots.',
    url: 'https://robotics.kawasaki.com/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=kawasakirobotics',
    suggested_prompt: 'Use AI to help me manage my robotics and improve my work...',
    color: 'purple'
  },
  {
    id: '991',
    name: 'Greenpeace AI',
    category: 'Environment',
    description: 'AI-powered features integrated into Greenpeace initiatives.',
    url: 'https://www.greenpeace.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=greenpeace',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'cyan'
  },
  {
    id: '992',
    name: 'WWF AI Environment',
    category: 'Environment',
    description: 'AI-powered features integrated into WWF initiatives.',
    url: 'https://www.worldwildlife.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=wwfenvironment',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'purple'
  },
  {
    id: '993',
    name: 'Nature Conservancy AI',
    category: 'Environment',
    description: 'AI-powered features integrated into Nature Conservancy.',
    url: 'https://www.nature.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=natureconservancy',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'cyan'
  },
  {
    id: '994',
    name: 'Sierra Club AI',
    category: 'Environment',
    description: 'AI-powered features integrated into Sierra Club initiatives.',
    url: 'https://www.sierraclub.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=sierraclub',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'purple'
  },
  {
    id: '995',
    name: 'Environmental Defense',
    category: 'Environment',
    description: 'AI-powered features integrated into Environmental Defense Fund.',
    url: 'https://www.edf.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=environmentaldefense',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'cyan'
  },
  {
    id: '996',
    name: 'NRDC AI Environment',
    category: 'Environment',
    description: 'AI-powered features integrated into NRDC initiatives.',
    url: 'https://www.nrdc.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=nrdcenvironment',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'purple'
  },
  {
    id: '997',
    name: 'Ocean Conservancy AI',
    category: 'Environment',
    description: 'AI-powered features integrated into Ocean Conservancy.',
    url: 'https://oceanconservancy.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=oceanconservancy',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'cyan'
  },
  {
    id: '998',
    name: 'Conservation AI',
    category: 'Environment',
    description: 'AI-powered features integrated into Conservation International.',
    url: 'https://www.conservation.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=conservationai',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'purple'
  },
  {
    id: '999',
    name: 'Rainforest Alliance AI',
    category: 'Environment',
    description: 'AI-powered features integrated into Rainforest Alliance.',
    url: 'https://www.rainforest-alliance.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=rainforestalliance',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'cyan'
  },
  {
    id: '1000',
    name: 'Earthjustice AI',
    category: 'Environment',
    description: 'AI-powered features integrated into Earthjustice initiatives.',
    url: 'https://earthjustice.org/features/ai',
    logo_url: 'https://api.dicebear.com/7.x/shapes/svg?seed=earthjustice',
    suggested_prompt: 'Use AI to help me manage my environment and improve my work...',
    color: 'purple'
  }
];
