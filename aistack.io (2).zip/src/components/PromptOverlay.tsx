import { motion, AnimatePresence } from 'motion/react';
import { AITool } from '../data/tools';
import { X, Copy, Check, ExternalLink } from 'lucide-react';
import { useState } from 'react';

interface PromptOverlayProps {
  tool: AITool | null;
  onClose: () => void;
}

export default function PromptOverlay({ tool, onClose }: PromptOverlayProps) {
  const [copied, setCopied] = useState(false);

  if (!tool) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(tool.suggested_prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      {tool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className={`relative w-full max-w-lg glass-panel p-8 rounded-3xl overflow-hidden ${
              tool.color === 'cyan' ? 'neon-border-cyan' : 'neon-border-purple'
            }`}
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-white/40 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>

            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center">
                <img 
                  src={tool.logo_url} 
                  alt={tool.name} 
                  className="w-10 h-10 object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <h2 className="text-2xl font-bold">{tool.name}</h2>
                <p className={`text-sm font-bold uppercase tracking-widest ${
                  tool.color === 'cyan' ? 'text-neon-cyan' : 'text-neon-purple'
                }`}>
                  {tool.category}
                </p>
              </div>
            </div>

            <p className="text-white/70 mb-8 leading-relaxed">
              {tool.description}
            </p>

            <div className="space-y-4">
              <label className="text-xs font-bold uppercase tracking-widest text-white/40">
                Suggested Prompt
              </label>
              <div className="relative">
                <div className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-sm text-white/90 font-mono leading-relaxed min-h-[100px]">
                  {tool.suggested_prompt}
                </div>
                <button
                  onClick={handleCopy}
                  className="absolute top-2 right-2 p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                >
                  {copied ? <Check size={16} className="text-green-400" /> : <Copy size={16} />}
                </button>
              </div>
            </div>

            <div className="mt-8 flex gap-4">
              <a
                href={tool.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl font-bold transition-all ${
                  tool.color === 'cyan' 
                    ? 'bg-neon-cyan text-black hover:shadow-[0_0_20px_rgba(0,243,255,0.5)]' 
                    : 'bg-neon-purple text-white hover:shadow-[0_0_20px_rgba(188,19,254,0.5)]'
                }`}
              >
                Launch Tool <ExternalLink size={18} />
              </a>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
