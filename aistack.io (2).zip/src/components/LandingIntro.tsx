import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { Cpu, Shield, Zap, Rocket } from 'lucide-react';

interface LandingIntroProps {
  onComplete: () => void;
}

const steps = [
  {
    title: "AiStack.io",
    subtitle: "created by - saptak",
    description: "Curated tools. Expert prompts. One powerful hub.",
    icon: Cpu,
    color: "text-neon-cyan"
  },
  {
    title: "Community Driven",
    subtitle: "Your Voice Matters",
    description: "You ask. We create. Drop a comment, request a topic — and we'll build dedicated learning content just for you.",
    icon: Shield,
    color: "text-neon-purple"
  },
  {
    title: "Free Tools",
    subtitle: "Zero Cost. Maximum Power.",
    description: "We provide access to every major tool in the market — for free. Plus, we teach you step-by-step how each one is built.",
    icon: Zap,
    color: "text-neon-cyan"
  },
  {
    title: "Your Career",
    subtitle: "Beyond Code",
    description: "We don't just teach code... We build careers. Strong brand presence across all platforms to help you land your dream job.",
    icon: Rocket,
    color: "text-neon-purple"
  }
];

export default function LandingIntro({ onComplete }: LandingIntroProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      if (currentStep < steps.length - 1) {
        setCurrentStep(prev => prev + 1);
      } else {
        clearInterval(timer);
        setTimeout(() => setIsExiting(true), 2000);
      }
    }, 4000);

    return () => clearInterval(timer);
  }, [currentStep]);

  if (isExiting) {
    return (
      <motion.div
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ duration: 1 }}
        onAnimationComplete={onComplete}
        className="fixed inset-0 z-[100] bg-cyber-black flex items-center justify-center"
      >
        <motion.div
          initial={{ scale: 1 }}
          animate={{ scale: 20, opacity: 0 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
          className="w-32 h-32 rounded-full bg-neon-cyan/20 blur-3xl"
        />
      </motion.div>
    );
  }

  const step = steps[currentStep];
  const Icon = step.icon;

  return (
    <div className="fixed inset-0 z-[100] bg-cyber-black flex items-center justify-center overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 1.1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative max-w-2xl w-full p-8 text-center"
        >
          <motion.div
            initial={{ rotate: -10, opacity: 0 }}
            animate={{ rotate: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className={`w-20 h-20 mx-auto mb-8 rounded-2xl bg-white/5 flex items-center justify-center ${step.color} border border-white/10`}
          >
            <Icon size={40} />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-sm font-bold uppercase tracking-[0.4em] text-white/40 mb-4"
          >
            {step.title}
          </motion.h1>

          <motion.h2
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="text-4xl md:text-6xl font-black mb-6 tracking-tight"
          >
            {step.subtitle}
          </motion.h2>

          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.8, duration: 1 }}
            className={`h-1 w-32 mx-auto mb-8 rounded-full ${currentStep % 2 === 0 ? 'bg-neon-cyan' : 'bg-neon-purple'}`}
          />

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="text-lg text-white/60 leading-relaxed max-w-md mx-auto"
          >
            {step.description}
          </motion.p>
        </motion.div>
      </AnimatePresence>

      {/* Progress indicators */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex gap-3">
        {steps.map((_, i) => (
          <div
            key={i}
            className={`h-1 transition-all duration-500 rounded-full ${
              i === currentStep ? 'w-8 bg-neon-cyan' : 'w-2 bg-white/10'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
