import React, { ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCcw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    const { hasError } = this.state;
    const { children } = this.props;

    if (hasError) {
      return (
        <div className="min-h-screen bg-cyber-black flex items-center justify-center p-6 text-white">
          <div className="max-w-md w-full glass-panel p-8 rounded-3xl neon-border-purple text-center">
            <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-6 text-red-500">
              <AlertCircle size={32} />
            </div>
            <h2 className="text-2xl font-black mb-4">System Malfunction</h2>
            <p className="text-white/60 text-sm mb-8">
              An unexpected error has occurred in the AiStack.io core. Our neural networks are recalibrating.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="w-full bg-neon-purple text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 hover:shadow-[0_0_20px_rgba(191,0,255,0.4)] transition-all"
            >
              <RefreshCcw size={18} />
              Reboot System
            </button>
          </div>
        </div>
      );
    }

    return children;
  }
}

export default ErrorBoundary;
