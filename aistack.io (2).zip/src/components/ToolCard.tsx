import { motion } from 'motion/react';
import { AITool } from '../data/tools';
import { ExternalLink, Copy, Check, Star } from 'lucide-react';
import { useState, MouseEvent } from 'react';

interface ToolCardProps {
  tool: AITool;
  onSelect: (tool: AITool) => void;
  isFavorite?: boolean;
  onToggleFavorite?: () => void;
  key?: string | number;
}

export default function ToolCard({ tool, onSelect, isFavorite, onToggleFavorite }: ToolCardProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(tool.suggested_prompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggleFavorite = (e: MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite?.();
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -5 }}
      onClick={() => onSelect(tool)}
      className={`glass-panel p-6 rounded-2xl cursor-pointer transition-all duration-300 group ${
        tool.color === 'cyan' ? 'neon-border-cyan neon-glow-cyan' : 'neon-border-purple neon-glow-purple'
      }`}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center overflow-hidden group-hover:scale-110 transition-transform duration-300">
          <img 
            src={tool.logo_url} 
            alt={tool.name} 
            className="w-8 h-8 object-contain"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleToggleFavorite}
            className={`p-2 rounded-lg transition-all ${
              isFavorite 
                ? 'bg-neon-cyan/20 text-neon-cyan shadow-[0_0_10px_rgba(0,243,255,0.3)]' 
                : 'bg-white/5 text-white/20 hover:text-white/40'
            }`}
          >
            <Star size={16} fill={isFavorite ? 'currentColor' : 'none'} />
          </button>
          <span className={`text-[10px] uppercase tracking-widest font-bold px-2 py-1 rounded-md bg-white/5 ${
            tool.color === 'cyan' ? 'text-neon-cyan' : 'text-neon-purple'
          }`}>
            {tool.category}
          </span>
        </div>
      </div>

      <h3 className="text-xl font-bold mb-2 group-hover:text-neon-cyan transition-colors">
        {tool.name}
      </h3>
      <p className="text-sm text-white/60 mb-6 line-clamp-2">
        {tool.description}
      </p>

      <div className="flex items-center justify-between mt-auto">
        <button
          onClick={handleCopy}
          className="flex items-center gap-2 text-xs font-medium text-white/40 hover:text-white transition-colors"
        >
          {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
          {copied ? 'Copied!' : 'Copy Prompt'}
        </button>
        
        <a
          href={tool.url}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          className={`p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors ${
            tool.color === 'cyan' ? 'text-neon-cyan' : 'text-neon-purple'
          }`}
        >
          <ExternalLink size={18} />
        </a>
      </div>
    </motion.div>
  );
}
