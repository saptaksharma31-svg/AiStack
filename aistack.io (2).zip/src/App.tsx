import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, LayoutGrid, Cpu, Terminal, Palette, BookOpen, Dumbbell, Utensils, 
  Briefcase, ChevronRight, LogOut, Star, Share2, Gamepad2, HeartPulse, 
  Coins, Scale, Plane, Home, Users, TrendingUp, Headset, Database, 
  ShieldCheck, Settings 
} from 'lucide-react';
import { AI_TOOLS, CATEGORIES, AITool } from './data/tools';
import ToolCard from './components/ToolCard';
import PromptOverlay from './components/PromptOverlay';
import Concierge from './components/Concierge';
import NetworkBackground from './components/NetworkBackground';
import LandingIntro from './components/LandingIntro';
import AuthModal from './components/AuthModal';
import { auth, db } from './firebase';
import { onAuthStateChanged, signOut, User } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, arrayUnion, arrayRemove, onSnapshot, serverTimestamp, getDocFromServer } from 'firebase/firestore';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  // We don't throw here to avoid crashing the app, but we log it as required
}

const CATEGORY_ICONS: Record<string, any> = {
  'All': LayoutGrid,
  'Coding': Terminal,
  'Design': Palette,
  'Writing': Cpu,
  'Education': BookOpen,
  'Fitness': Dumbbell,
  'Cooking': Utensils,
  'Business': Briefcase,
  'Favorites': Star,
  'Social Media': Share2,
  'Gaming': Gamepad2,
  'Health': HeartPulse,
  'Finance': Coins,
  'Legal': Scale,
  'Travel': Plane,
  'Real Estate': Home,
  'HR': Users,
  'Sales': TrendingUp,
  'Customer Support': Headset,
  'Data Science': Database,
  'Security': ShieldCheck,
  'DevOps': Settings,
};

export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTool, setSelectedTool] = useState<AITool | null>(null);

  // Auth & Profile Sync
  useEffect(() => {
    let unsubProfile: (() => void) | null = null;

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      setIsAuthReady(true);

      // Clean up previous listener if any
      if (unsubProfile) {
        unsubProfile();
        unsubProfile = null;
      }

      if (firebaseUser) {
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        
        try {
          const userDoc = await getDoc(userDocRef);

          if (!userDoc.exists()) {
            await setDoc(userDocRef, {
              uid: firebaseUser.uid,
              email: firebaseUser.email,
              displayName: firebaseUser.displayName || 'Explorer',
              favorites: [],
              createdAt: serverTimestamp(),
            });
          }

          // Listen for profile changes (favorites)
          unsubProfile = onSnapshot(userDocRef, (doc) => {
            if (doc.exists()) {
              setFavorites(doc.data().favorites || []);
            }
          }, (error) => {
            handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
        }
      } else {
        setFavorites([]);
      }
    });

    return () => {
      unsubscribe();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  // Check if user has seen intro before
  useEffect(() => {
    const hasSeenIntro = localStorage.getItem('hasSeenIntro');
    if (hasSeenIntro) {
      // setShowIntro(false); 
    }
  }, []);

  const handleIntroComplete = () => {
    setShowIntro(false);
    localStorage.setItem('hasSeenIntro', 'true');
  };

  const toggleFavorite = async (toolId: string) => {
    if (!user) return;
    const userDocRef = doc(db, 'users', user.uid);
    const isFavorite = favorites.includes(toolId);

    try {
      await updateDoc(userDocRef, {
        favorites: isFavorite ? arrayRemove(toolId) : arrayUnion(toolId)
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const filteredTools = useMemo(() => {
    return AI_TOOLS.filter(tool => {
      const matchesCategory = selectedCategory === 'All' 
        ? true 
        : selectedCategory === 'Favorites' 
          ? favorites.includes(tool.id)
          : tool.category === selectedCategory;
          
      const matchesSearch = tool.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           tool.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery, favorites]);

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <div className="relative min-h-screen bg-cyber-black text-white font-sans selection:bg-neon-cyan/30">
      <NetworkBackground />
      
      <AnimatePresence>
        {showIntro && (
          <LandingIntro onComplete={handleIntroComplete} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {!showIntro && isAuthReady && !user && (
          <AuthModal onSuccess={() => {}} />
        )}
      </AnimatePresence>

      <div className={`flex min-h-screen transition-opacity duration-1000 ${(!showIntro && user) ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        {/* Sidebar */}
        <aside className="w-64 glass-panel border-r border-white/10 p-6 flex flex-col gap-8 hidden lg:flex sticky top-0 h-screen">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-neon-cyan flex items-center justify-center shadow-[0_0_15px_rgba(0,243,255,0.5)]">
              <Cpu className="text-black" size={24} />
            </div>
            <div className="flex flex-col gap-1">
              <div className="flex items-center">
                <span className="bg-black text-white px-2 py-0.5 text-lg font-black tracking-tighter uppercase">AiStack</span>
                <span className="bg-white text-black px-2 py-0.5 text-lg font-black tracking-tighter uppercase">.io</span>
              </div>
              <p className="text-[8px] font-bold text-white/40 uppercase tracking-[0.2em] mt-1">
                created by - saptak
              </p>
            </div>
          </div>

          <nav className="flex flex-col gap-2 overflow-y-auto pr-2">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/30 mb-2 px-2">Categories</p>
            {['All', 'Favorites', ...CATEGORIES].map((cat) => {
              const Icon = CATEGORY_ICONS[cat] || LayoutGrid;
              const isActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-300 group ${
                    isActive 
                      ? 'bg-neon-cyan/10 text-neon-cyan border border-neon-cyan/20' 
                      : 'text-white/50 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon size={18} className={isActive ? 'text-neon-cyan' : 'group-hover:text-neon-cyan transition-colors'} />
                    <span className="text-sm font-medium">{cat}</span>
                  </div>
                  {isActive && (
                    <motion.div layoutId="active-indicator">
                      <ChevronRight size={14} />
                    </motion.div>
                  )}
                </button>
              );
            })}
          </nav>

          <div className="mt-auto space-y-4">
            <div className="glass-panel p-4 rounded-2xl border-neon-purple/20 bg-neon-purple/5">
              <p className="text-xs font-bold text-neon-purple mb-1">PRO TIP</p>
              <p className="text-[10px] text-white/60 leading-relaxed">
                Use the Concierge bot in the corner for instant tool recommendations tailored to your goals.
              </p>
            </div>
            
            <button 
              onClick={handleSignOut}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/40 hover:text-white hover:bg-white/5 transition-all text-sm font-medium"
            >
              <LogOut size={18} /> Sign Out
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col">
          {/* Header */}
          <header className="p-6 lg:px-10 flex items-center justify-between gap-6 bg-black/20 backdrop-blur-md border-b border-white/5 sticky top-0 z-40">
            <div className="flex flex-col lg:hidden">
              <div className="flex items-center scale-75 origin-left">
                <span className="bg-black text-white px-2 py-0.5 text-sm font-black tracking-tighter uppercase">AiStack</span>
                <span className="bg-white text-black px-2 py-0.5 text-sm font-black tracking-tighter uppercase">.io</span>
              </div>
              <p className="text-[6px] font-bold text-white/40 uppercase tracking-widest mt-1">
                created by - saptak
              </p>
            </div>
            <div className="relative flex-1 max-w-2xl">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" size={20} />
              <input
                type="text"
                placeholder="Search AI tools, prompts, or categories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:border-neon-cyan/50 focus:bg-white/10 transition-all"
              />
            </div>

            <div className="flex items-center gap-4">
              <button className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-sm font-medium hover:bg-white/10 transition-all">
                Submit Tool
              </button>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-neon-cyan to-neon-purple p-[1px]">
                <div className="w-full h-full rounded-full bg-cyber-black flex items-center justify-center overflow-hidden">
                  <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.email || 'User'}`} alt="Avatar" className="w-8 h-8" />
                </div>
              </div>
            </div>
          </header>

          {/* Hub */}
          <div className="p-6 lg:p-10">
            <div className="max-w-7xl mx-auto">
              <div className="flex items-end justify-between mb-8">
                <div>
                  <h2 className="text-3xl font-bold mb-2">
                    {selectedCategory} <span className="text-white/20 font-light">Hub</span>
                  </h2>
                  <p className="text-white/40 text-sm">
                    Discover {filteredTools.length} curated AI tools for your next breakthrough.
                  </p>
                </div>
                
                <div className="flex gap-2">
                  <div className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-widest text-white/40">
                    Grid View
                  </div>
                </div>
              </div>

              <motion.div 
                layout
                className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6"
              >
                <AnimatePresence mode="popLayout">
                  {filteredTools.map((tool: AITool) => (
                    <ToolCard 
                      key={tool.id} 
                      tool={tool} 
                      onSelect={setSelectedTool}
                      isFavorite={favorites.includes(tool.id)}
                      onToggleFavorite={() => toggleFavorite(tool.id)}
                    />
                  ))}
                </AnimatePresence>
              </motion.div>

              {filteredTools.length === 0 && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center py-20 text-center"
                >
                  <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mb-6 text-white/20">
                    <Search size={40} />
                  </div>
                  <h3 className="text-xl font-bold mb-2">No tools found</h3>
                  <p className="text-white/40 max-w-xs">
                    We couldn't find any tools matching "{searchQuery}" in {selectedCategory}.
                  </p>
                  <button 
                    onClick={() => {setSearchQuery(''); setSelectedCategory('All');}}
                    className="mt-6 text-neon-cyan font-bold hover:underline"
                  >
                    Clear all filters
                  </button>
                </motion.div>
              )}
            </div>
          </div>
        </main>

        {/* Components */}
        <PromptOverlay tool={selectedTool} onClose={() => setSelectedTool(null)} />
        <Concierge />
      </div>
    </div>
  );
}
